// Script to recategorize existing articles
import { storage } from './server/storage.js';
import { categorizeContent } from './server/news-aggregator.js';

async function recategorizeArticles() {
  try {
    console.log('Starting article recategorization...');
    
    const allNews = await storage.getIndustryNews();
    console.log(`Found ${allNews.length} total articles`);
    
    let updatedCount = 0;
    let categoryBreakdown = {};
    
    for (const article of allNews) {
      const newCategory = categorizeContent(article.title, article.summary || '');
      
      // Count categories for breakdown
      categoryBreakdown[newCategory] = (categoryBreakdown[newCategory] || 0) + 1;
      
      // Update if category changed and not excluded
      if (newCategory !== 'excluded' && newCategory !== article.category) {
        await storage.updateIndustryNewsCategory(article.id, newCategory);
        updatedCount++;
        console.log(`Updated: "${article.title}" -> ${newCategory}`);
      }
    }
    
    console.log('\n=== CATEGORIZATION RESULTS ===');
    console.log(`Updated ${updatedCount} articles`);
    console.log('\nCategory Breakdown:');
    Object.entries(categoryBreakdown).forEach(([category, count]) => {
      console.log(`  ${category}: ${count} articles`);
    });
    
  } catch (error) {
    console.error('Error:', error);
  }
}

recategorizeArticles();