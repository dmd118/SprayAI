// Quick test to see what News API is actually returning
const newsApiKey = process.env.NEWS_API_KEY;

async function testNewsAPI() {
  console.log('Testing News API responses...\n');
  
  const queries = [
    'golf course maintenance',
    'golf superintendent',
    'turf management',
    'greenkeeper'
  ];
  
  for (const query of queries) {
    try {
      const response = await fetch(
        `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&language=en&sortBy=publishedAt&pageSize=5&apiKey=${newsApiKey}`
      );
      
      if (response.ok) {
        const data = await response.json();
        console.log(`=== QUERY: "${query}" ===`);
        console.log(`Total results: ${data.totalResults}`);
        console.log(`Articles returned: ${data.articles?.length || 0}\n`);
        
        data.articles?.slice(0, 3).forEach((article, i) => {
          console.log(`Article ${i + 1}:`);
          console.log(`Title: ${article.title}`);
          console.log(`Source: ${article.source?.name}`);
          console.log(`Content length: ${(article.content || '').length} chars`);
          console.log(`Has truncation: ${(article.content || '').includes('[+') && (article.content || '').includes('chars]')}`);
          console.log(`Description: ${(article.description || '').substring(0, 100)}...`);
          console.log('---');
        });
        console.log('\n');
      }
    } catch (error) {
      console.error(`Query "${query}" failed:`, error.message);
    }
  }
}

testNewsAPI().catch(console.error);