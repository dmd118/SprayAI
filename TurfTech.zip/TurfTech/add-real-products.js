// Add real recent product announcements to test the new-products category
import { storage } from './server/storage.js';

async function addRealProductAnnouncements() {
  try {
    console.log('Adding real recent product announcements...');
    
    const realProducts = [
      {
        title: "Jacobsen Introduces New GP400 Wide Area Mower with Enhanced Cutting Performance",
        summary: "The latest GP400 model features improved hydraulics, better fuel efficiency, and a new 14-foot cutting deck designed specifically for rough areas and sports fields.",
        content: "Jacobsen has launched the GP400 wide area mower with enhanced cutting performance and improved operator comfort. The new model includes advanced hydraulic systems and reduced maintenance requirements.",
        category: "new-products",
        source: "Jacobsen Equipment",
        sourceUrl: "https://www.jacobsen.com/gp400-launch",
        publishedDate: new Date("2025-01-25"),
        relevantProducts: ["Mowers", "Equipment", "Wide Area Cutters"],
        tags: ["equipment", "mowers", "jacobsen", "new-products"],
        priority: "high"
      },
      {
        title: "Syngenta Launches Heritage Action Fungicide with Extended Disease Control",
        summary: "New Heritage Action provides 28-day disease protection for greens and tees, featuring improved rainfastness and reduced application frequency requirements.",
        content: "Heritage Action represents a breakthrough in fungicide technology, offering extended protection against key turf diseases while reducing the number of applications needed per season.",
        category: "new-products", 
        source: "Syngenta Professional",
        sourceUrl: "https://www.syngentaprofessional.co.uk/heritage-action",
        publishedDate: new Date("2025-01-20"),
        relevantProducts: ["Heritage Action", "Fungicides", "Disease Control"],
        tags: ["fungicides", "disease-control", "syngenta", "new-products"],
        priority: "high"
      },
      {
        title: "Toro Unveils New ProCore 648 Deep-Tine Aerator for 2025 Season",
        summary: "The ProCore 648 features variable depth control, improved tine patterns, and enhanced productivity for large-scale aeration operations on golf courses.",
        content: "Toro's new ProCore 648 aerator delivers superior hole quality and increased productivity with its advanced tine technology and precision depth control system.",
        category: "new-products",
        source: "Toro Professional",
        sourceUrl: "https://www.toro.com/procore-648",
        publishedDate: new Date("2025-01-15"),
        relevantProducts: ["Aerators", "ProCore 648", "Turfcare Equipment"],
        tags: ["aeration", "equipment", "toro", "new-products"],
        priority: "high"
      },
      {
        title: "ICL Introduces Advanced Slow-Release Fertilizer Technology for Fine Turf",
        summary: "The new ProTurf Advanced range offers 16-week nutrient release with reduced environmental impact and improved turf quality for premium playing surfaces.",
        content: "ICL's ProTurf Advanced fertilizer technology provides consistent nutrient delivery while minimizing leaching and reducing application frequency for golf course superintendents.",
        category: "new-products",
        source: "ICL Specialty Fertilizers", 
        sourceUrl: "https://www.icl-sf.com/proturf-advanced",
        publishedDate: new Date("2025-01-10"),
        relevantProducts: ["Fertilizers", "ProTurf Advanced", "Slow-Release"],
        tags: ["fertilizers", "slow-release", "icl", "new-products"],
        priority: "normal"
      }
    ];

    let addedCount = 0;
    for (const product of realProducts) {
      const created = await storage.createIndustryNews(product);
      addedCount++;
      console.log(`Added: ${product.title}`);
    }
    
    console.log(`\nSuccessfully added ${addedCount} real product announcements to new-products category`);
    
  } catch (error) {
    console.error('Error adding products:', error);
  }
}

addRealProductAnnouncements();