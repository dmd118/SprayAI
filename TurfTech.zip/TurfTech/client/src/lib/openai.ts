// This file handles client-side OpenAI integration utilities
// Actual API calls are made through the backend for security

export interface CompatibilityAnalysis {
  status: 'compatible' | 'warning' | 'incompatible';
  message: string;
  recommendations: string[];
}

export interface SprayCalculations {
  totalWaterNeeded: string;
  productAmounts: Array<{
    productName: string;
    amount: string;
  }>;
  tankLoads: string;
  applicationRate: string;
}

export interface AIAnalysisResult {
  compatibility: CompatibilityAnalysis;
  calculations: SprayCalculations;
}

export interface AnalysisRequest {
  productIds: number[];
  targetAreaId: number;
  waterVolume: string;
  nozzleType: string;
  barPressure: string;
  weatherData?: {
    temperature: number;
    humidity: number;
    windSpeed: number;
    condition: string;
    pressure: number;
  };
}

// Client-side helper functions for formatting AI responses
export function formatCompatibilityStatus(status: string): {
  color: string;
  icon: string;
  bgColor: string;
} {
  switch (status) {
    case 'compatible':
      return {
        color: 'text-green-800',
        icon: 'fas fa-check-circle',
        bgColor: 'bg-green-50 border-green-200'
      };
    case 'warning':
      return {
        color: 'text-yellow-800',
        icon: 'fas fa-exclamation-triangle',
        bgColor: 'bg-yellow-50 border-yellow-200'
      };
    case 'incompatible':
      return {
        color: 'text-red-800',
        icon: 'fas fa-times-circle',
        bgColor: 'bg-red-50 border-red-200'
      };
    default:
      return {
        color: 'text-gray-800',
        icon: 'fas fa-question-circle',
        bgColor: 'bg-gray-50 border-gray-200'
      };
  }
}

export function parseProductRate(labelRate: string, areaHectares: number): number {
  // Simple parser for common rate formats
  // This would need to be expanded for production use
  const flOzMatch = labelRate.match(/(\d+(?:\.\d+)?)\s*fl\s*oz/i);
  if (flOzMatch) {
    const flOzPer1000SqFt = parseFloat(flOzMatch[1]);
    const sqFtPerHectare = 10764;
    const totalSqFt = areaHectares * sqFtPerHectare;
    return (totalSqFt / 1000) * flOzPer1000SqFt * 29.5735; // Convert to ml
  }
  
  return 0;
}
