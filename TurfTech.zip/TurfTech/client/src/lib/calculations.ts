// Agricultural calculation utilities

export interface TankMixCalculation {
  totalWaterNeeded: number; // in liters
  productAmounts: Array<{
    productName: string;
    amount: number; // in ml
    unit: string;
  }>;
  tankLoads: number;
  applicationRate: string;
}

export interface FertilizerCalculation {
  spreaderSetting: number;
  materialNeeded: number; // in lbs
  numberOfBags: number;
  walkingSpeed: string;
  coverage: string;
}

// Convert hectares to square feet
export function hectaresToSquareFeet(hectares: number): number {
  return hectares * 10764;
}

// Convert square feet to hectares
export function squareFeetToHectares(squareFeet: number): number {
  return squareFeet / 10764;
}

// Parse water volume setting
export function parseWaterVolume(waterVolumeStr: string): number {
  const match = waterVolumeStr.match(/(\d+)\s*L\/ha/);
  if (match) {
    return parseInt(match[1]);
  }
  return 200; // Default
}

// Calculate total water needed
export function calculateWaterNeeded(areaHectares: number, waterVolumePerHa: number): number {
  return areaHectares * waterVolumePerHa;
}

// Calculate number of tank loads needed
export function calculateTankLoads(totalWaterNeeded: number, tankCapacity: number = 1000): number {
  return Math.ceil(totalWaterNeeded / tankCapacity);
}

// Parse product application rate
export function parseApplicationRate(labelRate: string): {
  rate: number;
  unit: string;
  per: string;
} {
  // Handle various rate formats
  const flOzMatch = labelRate.match(/(\d+(?:\.\d+)?)\s*fl\s*oz\/(\d+)\s*sq\s*ft/i);
  if (flOzMatch) {
    return {
      rate: parseFloat(flOzMatch[1]),
      unit: 'fl oz',
      per: `${flOzMatch[2]} sq ft`
    };
  }

  const lbsMatch = labelRate.match(/(\d+(?:\.\d+)?)\s*lbs?\/(\d+)\s*sq\s*ft/i);
  if (lbsMatch) {
    return {
      rate: parseFloat(lbsMatch[1]),
      unit: 'lbs',
      per: `${lbsMatch[2]} sq ft`
    };
  }

  const mlMatch = labelRate.match(/(\d+(?:\.\d+)?)\s*ml\/ha/i);
  if (mlMatch) {
    return {
      rate: parseFloat(mlMatch[1]),
      unit: 'ml',
      per: 'ha'
    };
  }

  return { rate: 0, unit: '', per: '' };
}

// Calculate product amount needed
export function calculateProductAmount(
  areaHectares: number,
  labelRate: string
): { amount: number; unit: string } {
  const parsedRate = parseApplicationRate(labelRate);
  
  if (parsedRate.unit === 'fl oz' && parsedRate.per.includes('sq ft')) {
    const sqFtPerHa = 10764;
    const totalSqFt = areaHectares * sqFtPerHa;
    const perSqFt = parseInt(parsedRate.per.match(/\d+/)?.[0] || '1000');
    const totalFlOz = (totalSqFt / perSqFt) * parsedRate.rate;
    const totalMl = totalFlOz * 29.5735; // Convert fl oz to ml
    
    return { amount: Math.round(totalMl), unit: 'ml' };
  }
  
  if (parsedRate.unit === 'ml' && parsedRate.per === 'ha') {
    return { amount: Math.round(areaHectares * parsedRate.rate), unit: 'ml' };
  }

  if (parsedRate.unit === 'lbs' && parsedRate.per.includes('sq ft')) {
    const sqFtPerHa = 10764;
    const totalSqFt = areaHectares * sqFtPerHa;
    const perSqFt = parseInt(parsedRate.per.match(/\d+/)?.[0] || '1000');
    const totalLbs = (totalSqFt / perSqFt) * parsedRate.rate;
    
    return { amount: Math.round(totalLbs * 10) / 10, unit: 'lbs' };
  }

  return { amount: 0, unit: 'ml' };
}

// Calculate fertilizer requirements
export function calculateFertilizerRequirements(
  areaHectares: number,
  applicationRateLbsPer1000SqFt: number,
  bagSizeLbs: number = 50
): FertilizerCalculation {
  const totalSqFt = hectaresToSquareFeet(areaHectares);
  const totalMaterialNeeded = (totalSqFt / 1000) * applicationRateLbsPer1000SqFt;
  const numberOfBags = Math.ceil(totalMaterialNeeded / bagSizeLbs);
  
  return {
    spreaderSetting: 2.5, // This would be calculated based on spreader calibration
    materialNeeded: Math.round(totalMaterialNeeded * 10) / 10,
    numberOfBags,
    walkingSpeed: "3 mph",
    coverage: `${Math.round(totalSqFt)} sq ft`
  };
}

// Nozzle and pressure configurations
export const NOZZLE_TYPES = [
  "Yellow 02 - Greens/Tees (Fine turf work)",
  "White 025 - Intermediate (Versatile)",
  "Red 04 - Fairways (High volume areas)"
];

export const BAR_PRESSURES = [
  "2.0 Bar",
  "3.0 Bar",
  "4.0 Bar"
];

// Nozzle flow rates per minute (authentic Hardy sprayer data)
export const NOZZLE_FLOW_RATES = {
  "Yellow 02": {
    "2.0 Bar": 0.57,
    "3.0 Bar": 0.70,
    "4.0 Bar": 0.80
  },
  "White 025": {
    "2.0 Bar": 0.71,
    "3.0 Bar": 0.87,
    "4.0 Bar": 1.00
  },
  "Red 04": {
    "2.0 Bar": 1.14,
    "3.0 Bar": 1.36,
    "4.0 Bar": 1.60
  }
};

// Recommended spray volumes for different applications
export const SPRAY_RECOMMENDATIONS = {
  "Wetting Agent": {
    volume: "400-600 L/ha",
    nozzles: ["Yellow 02", "White 025"],
    pressure: "2-3 bar",
    notes: "Good penetration for tees and greens"
  },
  "Fungicide": {
    volume: "300-400 L/ha", 
    nozzles: ["Yellow 02"],
    pressure: "2-3 bar",
    notes: "Fine coverage for disease control"
  },
  "Growth Regulator": {
    volume: "200-400 L/ha",
    nozzles: ["Yellow 02", "White 025"], 
    pressure: "2-3 bar",
    notes: "Balanced coverage and drift control"
  },
  "Herbicide": {
    volume: "200-400 L/ha",
    nozzles: ["Yellow 02", "White 025"],
    pressure: "2-3 bar", 
    notes: "Precise application for selective control"
  },
  "Insecticide": {
    volume: "300-500 L/ha",
    nozzles: ["White 025", "Red 04"],
    pressure: "2-3 bar",
    notes: "Good coverage for pest control"
  }
};

// Drift and coverage guide
export const PRESSURE_GUIDE = {
  "2.0 Bar": {
    dropletSize: "Medium-Coarse",
    driftRisk: "Low",
    coverage: "Good, minimal drift",
    windLimit: "25 km/h"
  },
  "3.0 Bar": {
    dropletSize: "Medium", 
    driftRisk: "Moderate",
    coverage: "Excellent balance",
    windLimit: "15 km/h"
  },
  "4.0 Bar": {
    dropletSize: "Fine-Medium",
    driftRisk: "Higher",
    coverage: "Fine spray, windy day risk", 
    windLimit: "10 km/h"
  }
};

export const WATER_VOLUMES = [
  { label: "Standard (200 L/ha)", value: "200 L/ha" },
  { label: "Low Volume (100 L/ha)", value: "100 L/ha" },
  { label: "Medium Volume (300 L/ha)", value: "300 L/ha" },
  { label: "High Volume (400 L/ha)", value: "400 L/ha" },
  { label: "Very High Volume (500 L/ha)", value: "500 L/ha" },
  { label: "4 fl oz/1000 sq ft", value: "4 fl oz/1000 sq ft" },
  { label: "6 fl oz/1000 sq ft", value: "6 fl oz/1000 sq ft" },
  { label: "8 fl oz/1000 sq ft", value: "8 fl oz/1000 sq ft" },
  { label: "10 fl oz/1000 sq ft", value: "10 fl oz/1000 sq ft" }
];

export const SPREADER_TYPES = [
  "Scott's Drop Spreader",
  "Scott's Broadcast Spreader", 
  "Other Drop Spreader",
  "Other Broadcast Spreader"
];
