import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ExternalLink, Calendar, Tag, RefreshCw, ChevronRight, ArrowUpDown, Star, BookOpen, Circle, CheckCircle, Trash2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import type { IndustryNews } from "@shared/schema";

const newsCategories = [
  { id: "all", label: "All News", color: "bg-blue-500" },
  { id: "new-products", label: "New Products", color: "bg-green-500" },
  { id: "research", label: "Research", color: "bg-purple-500" },
  { id: "regulations", label: "Regulations", color: "bg-red-500" },
  { id: "events", label: "Events", color: "bg-yellow-500" },
  { id: "techniques", label: "Techniques", color: "bg-cyan-500" },
  { id: "videos", label: "YouTube", color: "bg-orange-500" },
  { id: "discussion", label: "Reddit", color: "bg-rose-500" }
];

export function IndustryNews() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState<"newest_added" | "oldest_added" | "newest_published" | "oldest_published" | "favourited" | "read" | "unread">("newest_added");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: rawNews = [], isLoading } = useQuery({
    queryKey: ["/api/industry-news"],
    queryFn: async () => {
      const response = await fetch("/api/industry-news");
      if (!response.ok) throw new Error("Failed to fetch news");
      return response.json() as Promise<IndustryNews[]>;
    }
  });

  const updateReadMutation = useMutation({
    mutationFn: async ({ id, isRead }: { id: number; isRead: boolean }) => {
      const response = await fetch(`/api/industry-news/${id}/read`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isRead })
      });
      if (!response.ok) throw new Error('Failed to update read status');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
    }
  });

  const updateFavouriteMutation = useMutation({
    mutationFn: async ({ id, isFavourited }: { id: number; isFavourited: boolean }) => {
      const response = await fetch(`/api/industry-news/${id}/favourite`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isFavourited })
      });
      if (!response.ok) throw new Error('Failed to update favourite status');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
    }
  });

  // Filter news based on selected category and sort/filter options
  const filteredNews = rawNews.filter((article) => {
    // Category filter
    let categoryMatch = true;
    if (selectedCategory === "all") {
      categoryMatch = true;
    } else if (selectedCategory === "videos") {
      categoryMatch = article.title.startsWith("[VIDEO]") || article.title.startsWith("[COMEDY]") || (article.tags?.includes("video") ?? false) || (article.tags?.includes("youtube") ?? false) || article.source?.includes("YouTube") || false;
    } else {
      categoryMatch = article.category === selectedCategory;
    }
    
    // Sort/filter specific filters
    let sortFilterMatch = true;
    if (sortBy === "favourited") {
      sortFilterMatch = Boolean(article.isFavourited);
    } else if (sortBy === "read") {
      sortFilterMatch = article.isRead === true;
    } else if (sortBy === "unread") {
      sortFilterMatch = article.isRead !== true;
    }
    
    return categoryMatch && sortFilterMatch;
  });

  // Sort news based on selected sorting option
  const news = [...filteredNews].sort((a, b) => {
    switch (sortBy) {
      case "newest_added":
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case "oldest_added":
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      case "newest_published":
        return new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime();
      case "oldest_published":
        return new Date(a.publishedDate).getTime() - new Date(b.publishedDate).getTime();
      case "favourited":
        return (b.isFavourited ? 1 : 0) - (a.isFavourited ? 1 : 0);
      case "read":
        return (b.isRead ? 1 : 0) - (a.isRead ? 1 : 0);
      case "unread":
        return (a.isRead ? 1 : 0) - (b.isRead ? 1 : 0);
      default:
        return 0;
    }
  });

  const fetchLiveNewsMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/fetch-news", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch live news");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
      toast({
        title: "Live News Updated",
        description: `Successfully fetched ${data.count} new articles from industry sources.`,
      });
    },
    onError: (error) => {
      toast({
        title: "News Fetch Failed",
        description: "Unable to fetch live news. RSS feeds may be temporarily unavailable.",
        variant: "destructive",
      });
    }
  });

  const fetchRedditMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/news/fetch-reddit", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch Reddit content");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
      toast({
        title: "Reddit Content Updated",
        description: `Successfully fetched ${data.count} high-quality discussions from greenkeeping communities.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Reddit Fetch Failed",
        description: "Unable to fetch Reddit content. Please check API credentials.",
        variant: "destructive",
      });
    }
  });

  const fetchYouTubeMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/news/fetch-youtube", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch YouTube content");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
      toast({
        title: "YouTube Content Updated",
        description: `Successfully fetched ${data.count} professional greenkeeping videos.`,
      });
    },
    onError: (error) => {
      toast({
        title: "YouTube Fetch Failed",
        description: "Unable to fetch YouTube content. Please check your API key.",
        variant: "destructive",
      });
    }
  });

  const fetchGoogleSearchMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/news/fetch-google-search", { method: "POST" });
      if (!response.ok) throw new Error("Failed to fetch Google Search content");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
      toast({
        title: "Professional Articles Updated",
        description: `Successfully fetched ${data.count} articles from industry websites.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Professional Content Fetch Failed",
        description: "Unable to fetch articles from industry websites. Please try again later.",
        variant: "destructive",
      });
    }
  });

  const deleteNewsMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/industry-news/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Failed to delete news article");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/industry-news"] });
      toast({
        title: "Article Deleted",
        description: "News article has been successfully removed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Delete Failed",
        description: "Unable to delete the article. Please try again.",
        variant: "destructive",
      });
    }
  });

  const getCategoryColor = (category: string) => {
    const categoryInfo = newsCategories.find(c => c.id === category);
    return categoryInfo?.color || "bg-gray-500";
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high": return "🔴";
      case "normal": return "🟡";
      case "low": return "🟢";
      default: return "🟡";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse" />
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded" />
                <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-5/6" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Industry News & Updates
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Latest developments in greenkeeping, turf management, and golf course maintenance
          </p>
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-2 order-2 sm:order-1">
            <ArrowUpDown className="h-4 w-4 text-gray-500" />
            <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
              <SelectTrigger className="w-full sm:w-[180px] min-w-[140px]">
                <SelectValue placeholder="Sort articles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest_added">Newest Added</SelectItem>
                <SelectItem value="oldest_added">Oldest Added</SelectItem>
                <SelectItem value="newest_published">Newest Published</SelectItem>
                <SelectItem value="oldest_published">Oldest Published</SelectItem>
                <SelectItem value="favourited">Favourited</SelectItem>
                <SelectItem value="read">Read</SelectItem>
                <SelectItem value="unread">Unread</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2 order-1 sm:order-2">
            <Button
              onClick={() => fetchRedditMutation.mutate()}
              disabled={fetchRedditMutation.isPending}
              variant="outline"
              size="sm"
              className="flex items-center justify-center gap-2 w-full sm:w-auto text-xs sm:text-sm px-3"
            >
              <RefreshCw className={`h-3 w-3 sm:h-4 sm:w-4 ${fetchRedditMutation.isPending ? 'animate-spin' : ''}`} />
              <span className="hidden xs:inline">Fetch</span> Reddit
            </Button>
            <Button
              onClick={() => fetchYouTubeMutation.mutate()}
              disabled={fetchYouTubeMutation.isPending}
              variant="outline"
              size="sm"
              className="flex items-center justify-center gap-2 w-full sm:w-auto text-xs sm:text-sm px-3"
            >
              <RefreshCw className={`h-3 w-3 sm:h-4 sm:w-4 ${fetchYouTubeMutation.isPending ? 'animate-spin' : ''}`} />
              <span className="hidden xs:inline">Fetch</span> YouTube
            </Button>
            <Button
              onClick={() => fetchGoogleSearchMutation.mutate()}
              disabled={fetchGoogleSearchMutation.isPending}
              variant="outline"
              size="sm"
              className="flex items-center justify-center gap-2 w-full sm:w-auto text-xs sm:text-sm px-3"
            >
              <RefreshCw className={`h-3 w-3 sm:h-4 sm:w-4 ${fetchGoogleSearchMutation.isPending ? 'animate-spin' : ''}`} />
              <span className="hidden xs:inline">Fetch</span> Professional
            </Button>
            <Button
              onClick={() => fetchLiveNewsMutation.mutate()}
              disabled={fetchLiveNewsMutation.isPending}
              variant="outline"
              size="sm"
              className="flex items-center justify-center gap-2 w-full sm:w-auto text-xs sm:text-sm px-3"
            >
              <RefreshCw className={`h-3 w-3 sm:h-4 sm:w-4 ${fetchLiveNewsMutation.isPending ? 'animate-spin' : ''}`} />
              <span className="hidden xs:inline">{fetchLiveNewsMutation.isPending ? 'Fetching...' : 'Fetch'}</span>
              <span className="hidden xs:inline">Live</span> News
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <div className="overflow-x-auto pb-2">
          <TabsList className="flex w-max gap-1 h-auto p-1">
            {newsCategories.map((category) => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="text-xs md:text-sm whitespace-nowrap px-4 py-2 flex-shrink-0"
              >
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {newsCategories.map((category) => (
          <TabsContent key={category.id} value={category.id} className="space-y-4">
            {news.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-gray-500 dark:text-gray-400">
                    No news available for this category yet.
                  </p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                    News updates will appear here as they become available from industry sources.
                  </p>
                </CardContent>
              </Card>
            ) : category.id === 'reddit' || category.id === 'youtube' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
                {news.map((item) => (
                  <div key={item.id} className="group cursor-pointer">
                    {/* Thumbnail Container */}
                    <div className="relative aspect-video bg-gray-100 dark:bg-gray-800 rounded-xl overflow-hidden mb-3">
                      {category.id === 'youtube' && item.sourceUrl?.includes('youtube.com') ? (
                        <>
                          <img 
                            src={`https://img.youtube.com/vi/${item.sourceUrl.split('v=')[1]?.split('&')[0]}/maxresdefault.jpg`}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                            onError={(e) => {
                              // Try medium quality if max fails
                              const target = e.currentTarget;
                              if (target.src.includes('maxresdefault')) {
                                target.src = `https://img.youtube.com/vi/${item.sourceUrl.split('v=')[1]?.split('&')[0]}/hqdefault.jpg`;
                              } else {
                                target.style.display = 'none';
                                const fallback = target.parentElement?.querySelector('.fallback-icon') as HTMLElement;
                                if (fallback) fallback.style.display = 'flex';
                              }
                            }}
                          />
                          {/* YouTube Play Button Overlay */}
                          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                            <div className="bg-red-600 rounded-full p-3 shadow-lg">
                              <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M8 5v14l11-7z"/>
                              </svg>
                            </div>
                          </div>
                        </>
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-400 to-red-500">
                          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.09 4.56c-.7-1.33-2.74-1.56-5.09-1.56s-4.39.23-5.09 1.56c-.28.53-.28 1.06-.28 1.56v10.76c0 .5 0 1.03.28 1.56.7 1.33 2.74 1.56 5.09 1.56s4.39-.23 5.09-1.56c.28-.53.28-1.06.28-1.56V6.12c0-.5 0-1.03-.28-1.56zM12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z"/>
                          </svg>
                        </div>
                      )}
                      
                      {/* Fallback for failed YouTube thumbnails */}
                      <div className="fallback-icon hidden w-full h-full flex items-center justify-center bg-gradient-to-br from-red-500 to-red-600">
                        <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M10 16.5l6-4.5-6-4.5v9zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                        </svg>
                      </div>
                      
                      {/* Content Badge */}
                      <div className="absolute top-2 left-2">
                        <Badge className={`${getCategoryColor(item.category)} text-white text-xs`}>
                          {category.id === 'reddit' ? 'Reddit' : 'YouTube'}
                        </Badge>
                      </div>
                      
                      {/* Duration for YouTube (if available) */}
                      {category.id === 'youtube' && (
                        <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                          Video
                        </div>
                      )}
                    </div>
                    
                    {/* Video Info */}
                    <div className="space-y-2 px-1">
                      <h3 className="font-medium text-sm sm:text-base leading-tight line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        {item.title}
                      </h3>
                      
                      <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                        {item.summary}
                      </p>
                      
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pt-1">
                        <span className="text-xs text-gray-500 truncate">
                          {formatDate(item.publishedDate)}
                        </span>
                        
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {item.sourceUrl && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              asChild
                              className="text-xs h-7 px-3 hover:bg-blue-50 dark:hover:bg-blue-950 flex-1 sm:flex-initial"
                            >
                              <a 
                                href={item.sourceUrl} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-1"
                              >
                                {category.id === 'youtube' ? 'Watch' : 'View'}
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            </Button>
                          )}
                          
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950 h-7 px-2"
                            onClick={() => deleteNewsMutation.mutate(item.id)}
                            disabled={deleteNewsMutation.isPending}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              news.map((item) => (
                <Card key={item.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge 
                            className={`${getCategoryColor(item.category)} text-white`}
                          >
                            {newsCategories.find(c => c.id === item.category)?.label || item.category}
                          </Badge>
                          <span className="text-sm">
                            {getPriorityIcon(item.priority)}
                          </span>
                          {item.tags && item.tags.length > 0 && (
                            <div className="flex items-center gap-1">
                              <Tag className="h-3 w-3 text-gray-400" />
                              <span className="text-xs text-gray-500">
                                {item.tags.slice(0, 2).join(", ")}
                              </span>
                            </div>
                          )}
                        </div>
                        <CardTitle className="text-lg leading-tight">{item.title}</CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <Calendar className="h-4 w-4" />
                          <span className="text-sm">
                            Published: {formatDate(item.publishedDate)}
                          </span>
                          <span>•</span>
                          <span className="text-sm">
                            Added: {formatDate(item.createdAt)}
                          </span>
                          <span>•</span>
                          <span>{item.source}</span>
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateFavouriteMutation.mutate({ id: item.id, isFavourited: !item.isFavourited })}
                          className={`p-2 ${item.isFavourited ? 'text-yellow-500 hover:text-yellow-600' : 'text-gray-400 hover:text-yellow-500'}`}
                        >
                          <Star className={`h-4 w-4 ${item.isFavourited ? 'fill-current' : ''}`} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateReadMutation.mutate({ id: item.id, isRead: !item.isRead })}
                          className={`p-2 ${item.isRead ? 'text-green-500 hover:text-green-600' : 'text-gray-400 hover:text-green-500'}`}
                        >
                          {item.isRead ? <CheckCircle className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 dark:text-gray-300 mb-4">
                      {item.summary}
                    </p>
                    
                    {item.relevantProducts && item.relevantProducts.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">
                          Relevant Products:
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {item.relevantProducts.map((product, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {product}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="default" 
                            size="sm"
                            className="flex items-center gap-2"
                          >
                            Read Full Article
                            <ChevronRight className="h-3 w-3" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[80vh]">
                          <DialogHeader>
                            <DialogTitle className="text-left">{item.title}</DialogTitle>
                            <DialogDescription className="text-left">
                              Published {formatDate(item.publishedDate)} by {item.source}
                            </DialogDescription>
                          </DialogHeader>
                          <ScrollArea className="max-h-[60vh] pr-4">
                            <div className="space-y-4">
                              <div className="flex items-center gap-2">
                                <Badge className={`${getCategoryColor(item.category)} text-white`}>
                                  {newsCategories.find(c => c.id === item.category)?.label || item.category}
                                </Badge>
                                <span className="text-sm">
                                  {getPriorityIcon(item.priority)}
                                </span>
                              </div>
                              
                              <div className="prose prose-sm dark:prose-invert max-w-none">
                                <p className="text-base leading-relaxed">
                                  {item.content || item.summary}
                                </p>
                              </div>
                              
                              {item.relevantProducts && item.relevantProducts.length > 0 && (
                                <div>
                                  <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                                    Relevant Products:
                                  </h4>
                                  <div className="flex flex-wrap gap-1">
                                    {item.relevantProducts.map((product, index) => (
                                      <Badge key={index} variant="outline" className="text-xs">
                                        {product}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              {item.tags && item.tags.length > 0 && (
                                <div>
                                  <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                                    Tags:
                                  </h4>
                                  <div className="flex flex-wrap gap-1">
                                    {item.tags.map((tag, index) => (
                                      <Badge key={index} variant="secondary" className="text-xs">
                                        {tag}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              {item.sourceUrl && (
                                <div className="pt-4 border-t">
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    asChild
                                  >
                                    <a 
                                      href={item.sourceUrl} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="flex items-center gap-2"
                                    >
                                      View Original Source
                                      <ExternalLink className="h-3 w-3" />
                                    </a>
                                  </Button>
                                </div>
                              )}
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>
                      
                      {item.title.startsWith("[VIDEO]") && item.sourceUrl && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white border-red-600"
                          onClick={() => item.sourceUrl && window.open(item.sourceUrl as string, '_blank')}
                        >
                          Watch Now
                          <ExternalLink className="h-3 w-3" />
                        </Button>
                      )}
                      
                      {!item.title.startsWith("[VIDEO]") && item.sourceUrl && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          asChild
                        >
                          <a 
                            href={item.sourceUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center gap-2"
                          >
                            View Source
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </Button>
                      )}
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="flex items-center gap-2 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950"
                        onClick={() => deleteNewsMutation.mutate(item.id)}
                        disabled={deleteNewsMutation.isPending}
                      >
                        <Trash2 className="h-3 w-3" />
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}