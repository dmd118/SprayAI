import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Eye,
  Edit,
  Printer,
  Calendar,
  CalendarDays,
  SprayCan,
  Sprout,
  Sun,
  Cloud,
  CloudRain,
  Upload,
  Camera,
  Trash2,
  BarChart3,
  Target,
  RefreshCw,
} from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import {
  insertApplicationRecordSchema,
  type ApplicationRecord,
  type TurfArea,
} from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { TankMixCalculator } from "./tank-mix-calculator";

const formSchema = z.object({
  date: z.string().optional(),
  dateOption: z.enum(["today-morning", "today-afternoon", "manual"]).optional(),
  manualDateTime: z.string().optional(),
  type: z.string(),
  products: z.string().min(1, "Products are required"),
  productDetails: z.string().min(1, "Product details are required"),
  areaId: z.number().min(1, "Please select a target area"),
  areaName: z.string().min(1, "Area name is required"),
  rate: z.string().min(1, "Rate is required"),
  weather: z.string().min(1, "Weather is required"),
  waterVolume: z.string().optional(),
  spreaderSetting: z.string().optional(),
  notes: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

export function ApplicationRecords() {
  const { toast } = useToast();
  const [typeFilter, setTypeFilter] = useState("all");
  const [timeFilter, setTimeFilter] = useState("last-30-days");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<ApplicationRecord | null>(
    null,
  );
  const [viewingRecord, setViewingRecord] = useState<ApplicationRecord | null>(
    null,
  );
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [hasEditedTime, setHasEditedTime] = useState(false);
  const [hasSelectedArea, setHasSelectedArea] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: (() => {
        const today = new Date();
        const dateStr = today.toLocaleDateString("en-GB");
        return `${dateStr} 07:00-10:00am`;
      })(),
      dateOption: "today-morning" as const,
      manualDateTime: "",
      type: "SprayCan",
      products: "",
      productDetails: "",
      areaId: 1,
      areaName: "",
      rate: "",
      weather: (() => {
        // This will be overridden by the weather data when it loads
        return "";
      })(),
      waterVolume: "",
      spreaderSetting: "",
      notes: "",
    },
  });

  const { data: records = [], isLoading } = useQuery<ApplicationRecord[]>({
    queryKey: ["/api/application-records"],
  });

  const { data: areas = [] } = useQuery<TurfArea[]>({
    queryKey: ["/api/turf-areas"],
  });

  const { data: products = [] } = useQuery<any[]>({
    queryKey: ["/api/spray-products"],
  });

  // Calculate actual costs from application records
  const calculateApplicationCost = (record: ApplicationRecord) => {
    // First try to extract cost from existing cost summary in product details
    if (record.productDetails) {
      try {
        const parsed = JSON.parse(record.productDetails);
        if (parsed.costSummary && parsed.costSummary.totalJobCost) {
          return parsed.costSummary.totalJobCost;
        }
      } catch {
        // If not JSON, fall back to manual calculation
      }
    }

    // Fallback: calculate cost from product quantities
    const area = areas.find((a) => a.id === record.areaId);
    if (!area) return 0;

    let totalCost = 0;

    // Parse product details to extract quantities and calculate costs
    if (record.productDetails) {
      const items = record.productDetails.split(",").map((item) => item.trim());

      items.forEach((item) => {
        // Match patterns like "20L Elevate Fe Iron", "2L Primo Maxx II", etc.
        const match = item.match(/^(\d+(?:\.\d+)?)(L|kg|ml|g)\s+(.+)$/i);
        if (match) {
          const quantity = parseFloat(match[1]);
          const unit = match[2].toLowerCase();
          const productName = match[3].trim();

          // Find product in our database
          const product = products.find(
            (p) =>
              p.name.toLowerCase().includes(productName.toLowerCase()) ||
              productName.toLowerCase().includes(p.name.toLowerCase()),
          );

          if (product && product.costPerUnit) {
            let adjustedQuantity = quantity;

            // Convert units if needed
            if (unit === "ml" && product.unit === "L") {
              adjustedQuantity = quantity / 1000;
            } else if (unit === "g" && product.unit === "kg") {
              adjustedQuantity = quantity / 1000;
            }

            totalCost += adjustedQuantity * product.costPerUnit;
          }
        }
      });
    }

    return totalCost;
  };

  const sprayAppsCost = records
    .filter((r) => r.type === "Spray" || r.type === "SprayCan")
    .reduce((total, record) => total + calculateApplicationCost(record), 0);

  const fertilizerAppsCost = records
    .filter((r) => r.type === "Fertilizer")
    .reduce((total, record) => total + calculateApplicationCost(record), 0);

  // Fetch weather data for the dropdown
  const { data: weatherData } = useQuery({
    queryKey: ["/api/weather"],
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const createMutation = useMutation({
    mutationFn: (data: any) =>
      apiRequest("POST", "/api/application-records", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/application-records"] });
      setIsDialogOpen(false);
      form.reset();
      setEditingRecord(null);
      setUploadedImage(null);
      setHasEditedTime(false);
      setHasSelectedArea(false);
      toast({ title: "Application record created successfully" });
    },
    onError: () => {
      toast({
        title: "Failed to create application record",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) =>
      apiRequest("PATCH", `/api/application-records/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/application-records"] });
      setIsDialogOpen(false);
      form.reset();
      setEditingRecord(null);
      setUploadedImage(null);
      setHasEditedTime(false);
      setHasSelectedArea(false);
      toast({ title: "Application record updated successfully" });
    },
    onError: () => {
      toast({
        title: "Failed to update application record",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) =>
      apiRequest("DELETE", `/api/application-records/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/application-records"] });
      toast({ title: "Application record deleted successfully" });
    },
    onError: () => {
      toast({
        title: "Failed to delete application record",
        variant: "destructive",
      });
    },
  });

  // Function to format product details in a readable way
  const formatProductDetails = (productDetails: string) => {
    try {
      // Try to parse as JSON first (from Tank Mix Calculator saves)
      const parsed = JSON.parse(productDetails);
      if (parsed.products && Array.isArray(parsed.products)) {
        return parsed.products
          .map(
            (product: any) =>
              `${product.amount}${product.unit} ${product.name}`,
          )
          .join(", ");
      }
    } catch {
      // If not JSON, return as is (manual entries)
      return productDetails;
    }
    return productDetails;
  };

  // Function to get AI analysis of spray application
  const getAiSprayAnalysis = async (record: ApplicationRecord) => {
    if (!record) return;

    setIsLoadingAnalysis(true);
    try {
      const applicationDate = new Date(record.date);
      const season = getSeason(applicationDate);

      let productDetails = "";
      try {
        const parsed = JSON.parse(record.productDetails);
        if (parsed.products) {
          productDetails = parsed.products
            .map((p: any) => `${p.amount}${p.unit} ${p.name} (${p.type})`)
            .join(", ");
        }
      } catch {
        productDetails = record.productDetails;
      }

      const response = await fetch("/api/analyze-spray-application", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          products: record.products,
          productDetails: productDetails,
          applicationDate: applicationDate.toISOString(),
          season: season,
          weather: record.weather,
          areaType: record.areaName,
          rate: record.rate,
        }),
      });

      const data = await response.json();
      setAiAnalysis(data.analysis);

      // Save the analysis to the record permanently
      try {
        await fetch(`/api/application-records/${record.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ expertAnalysis: data.analysis }),
        });

        // Update the local record state
        setViewingRecord((prev) =>
          prev ? { ...prev, expertAnalysis: data.analysis } : null,
        );
        queryClient.invalidateQueries({
          queryKey: ["/api/application-records"],
        });

        console.log("Expert analysis saved to record");
      } catch (saveError) {
        console.error("Failed to save analysis to record:", saveError);
      }
    } catch (error) {
      console.error("Failed to get AI analysis:", error);
      toast({ title: "Failed to get AI analysis", variant: "destructive" });
    } finally {
      setIsLoadingAnalysis(false);
    }
  };

  // Helper function to determine season
  const getSeason = (date: Date) => {
    const month = date.getMonth();
    if (month >= 2 && month <= 4) return "Spring";
    if (month >= 5 && month <= 7) return "Summer";
    if (month >= 8 && month <= 10) return "Autumn";
    return "Winter";
  };

  const analyzeApplicationPhotoMutation = useMutation({
    mutationFn: async (imageBase64: string) => {
      const response = await apiRequest(
        "POST",
        "/api/analyze-application-photo",
        {
          imageBase64: imageBase64.split(",")[1],
        },
      );
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Multi-product photo analysis result:", data);

      // Auto-fill form fields with multi-product analysis results
      if (data.products) form.setValue("products", data.products);
      if (data.productDetails)
        form.setValue("productDetails", data.productDetails);
      if (data.applicationType) form.setValue("type", data.applicationType);
      if (data.applicationRate) form.setValue("rate", data.applicationRate);
      if (data.waterVolume) form.setValue("waterVolume", data.waterVolume);
      if (data.spreaderSetting)
        form.setValue("spreaderSetting", data.spreaderSetting);

      setIsAnalyzing(false);

      // Enhanced feedback for multi-product detection
      const productCount = data.productCount || "multiple";
      const confidenceLevel = data.confidence || "medium";

      toast({
        title: `Photo analyzed - ${productCount} products detected`,
        description: `Application details auto-filled with ${confidenceLevel} confidence`,
      });
    },
    onError: () => {
      setIsAnalyzing(false);
      toast({ title: "Failed to analyze photo", variant: "destructive" });
    },
  });

  const handleSubmit = (data: FormData) => {
    console.log("handleSubmit called with data:", data);
    console.log("hasSelectedArea:", hasSelectedArea);

    // Validate that user has actively selected target area
    if (!hasSelectedArea) {
      console.log("Blocking submission - no area selected");
      toast({
        title: "Please select target area",
        description:
          "You must choose the correct target area before creating a record.",
        variant: "destructive",
      });
      return;
    }

    // Generate the proper date string based on selection or use current date
    let finalDate = "";
    const today = new Date();
    const dateStr = today.toLocaleDateString("en-GB");

    if (data.dateOption === "today-morning") {
      finalDate = `${dateStr} 07:00-10:00am`;
    } else if (data.dateOption === "today-afternoon") {
      finalDate = `${dateStr} 11:00-2:30pm`;
    } else if (data.dateOption === "manual" && data.manualDateTime) {
      finalDate = data.manualDateTime;
    } else {
      // If no date option selected, use current date and time
      finalDate = `${dateStr} ${today.toLocaleTimeString("en-GB")}`;
    }

    console.log("Form data being submitted:", data);

    // Ensure all required fields are present and date is properly formatted as string
    const submissionData = {
      ...data,
      date: finalDate,
      spreaderSetting: data.spreaderSetting || "",
      notes: data.notes || "",
      waterVolume: data.waterVolume || "",
    };

    console.log("Processed submission data:", submissionData);

    if (editingRecord) {
      updateMutation.mutate({ id: editingRecord.id, data: submissionData });
    } else {
      createMutation.mutate(submissionData);
    }
  };

  const handleAreaChange = (areaId: string) => {
    const selectedArea = areas.find((a) => a.id === parseInt(areaId));
    if (selectedArea) {
      form.setValue("areaId", selectedArea.id);
      form.setValue("areaName", selectedArea.name);
      setHasSelectedArea(true);
    }
  };

  const handleDateOptionChange = (
    option: "today-morning" | "today-afternoon" | "manual",
  ) => {
    form.setValue("dateOption", option);
    setHasEditedTime(true);

    // Auto-generate date for preset options
    if (option === "today-morning" || option === "today-afternoon") {
      const today = new Date();
      const dateStr = today.toLocaleDateString("en-GB");
      const timeRange =
        option === "today-morning" ? "07:00-10:00am" : "11:00-2:30pm";
      form.setValue("date", `${dateStr} ${timeRange}`);

      // Auto-fill weather conditions based on time period
      if (
        weatherData &&
        typeof weatherData === "object" &&
        weatherData !== null
      ) {
        const weather = weatherData as any;
        if (weather.temperature && weather.humidity && weather.description) {
          const currentConditions = `${weather.temperature}°C, ${weather.humidity}% humidity, ${weather.description}`;
          form.setValue("weather", currentConditions);
        }
      }
    }
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "spray":
        return "bg-blue-100 text-blue-800";
      case "fertilizer":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "spray":
        return <SprayCan size={16} />;
      case "fertilizer":
        return <Sprout size={16} />;
      default:
        return <SprayCan size={16} />;
    }
  };

  const getWeatherIcon = (weather: string) => {
    const weatherLower = weather.toLowerCase();
    if (weatherLower.includes("clear") || weatherLower.includes("sunny")) {
      return <Sun className="text-yellow-500" size={16} />;
    } else if (
      weatherLower.includes("cloud") ||
      weatherLower.includes("overcast")
    ) {
      return <Cloud className="text-slate-400" size={16} />;
    } else if (weatherLower.includes("rain")) {
      return <CloudRain className="text-blue-500" size={16} />;
    }
    return <Sun className="text-yellow-500" size={16} />;
  };

  const getRecordStats = () => {
    const now = new Date();
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const thisWeek = records.filter(
      (r) => new Date(r.date) >= oneWeekAgo,
    ).length;
    const thisMonth = records.filter(
      (r) => new Date(r.date) >= oneMonthAgo,
    ).length;
    const sprayApps = records.filter(
      (r) => r.type.toLowerCase() === "spray",
    ).length;
    const fertilizerApps = records.filter(
      (r) => r.type.toLowerCase() === "fertilizer",
    ).length;

    return { thisWeek, thisMonth, sprayApps, fertilizerApps };
  };

  const filteredRecords = records.filter((record) => {
    const matchesType =
      typeFilter === "all" ||
      record.type.toLowerCase() === typeFilter.toLowerCase();

    const now = new Date();
    let matchesTime = true;

    if (timeFilter === "last-7-days") {
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      matchesTime = new Date(record.date) >= oneWeekAgo;
    } else if (timeFilter === "last-30-days") {
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      matchesTime = new Date(record.date) >= oneMonthAgo;
    } else if (timeFilter === "last-90-days") {
      const threeMonthsAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      matchesTime = new Date(record.date) >= threeMonthsAgo;
    } else if (timeFilter === "this-year") {
      const startOfYear = new Date(now.getFullYear(), 0, 1);
      matchesTime = new Date(record.date) >= startOfYear;
    }

    return matchesType && matchesTime;
  });

  if (isLoading) {
    return <div className="p-6">Loading application records...</div>;
  }

  const stats = getRecordStats();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">
            Application Records
          </h2>
          <p className="text-slate-600 mt-1">
            Track all spray and fertilizer applications with detailed records
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <TankMixCalculator />
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="mr-2" size={16} />
                New Record
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingRecord
                    ? "Edit Application Record"
                    : "Add New Application Record"}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form
                  onSubmit={(e) => {
                    console.log("Form submit event triggered");
                    console.log("Form errors:", form.formState.errors);
                    console.log("Form values:", form.getValues());
                    form.handleSubmit(handleSubmit)(e);
                  }}
                  className="space-y-4"
                >
                  {/* Photo Upload Section */}
                  <div className="border rounded-lg p-4 bg-slate-50">
                    <div className="flex items-center gap-2 mb-3">
                      <Camera className="text-blue-600" size={20} />
                      <h3 className="font-medium">Upload Application Photo</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">
                      Upload a photo showing your spray application details
                      (products, rates, water volume) to auto-fill the form
                    </p>

                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (e) => {
                                const result = e.target?.result as string;
                                setUploadedImage(result);
                                setIsAnalyzing(true);
                                analyzeApplicationPhotoMutation.mutate(result);
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                          className="hidden"
                          id="photo-upload"
                        />
                        <label
                          htmlFor="photo-upload"
                          className="cursor-pointer"
                        >
                          <Button
                            type="button"
                            variant="outline"
                            className="flex items-center gap-2"
                            asChild
                          >
                            <span>
                              <Upload size={16} />
                              Choose Photo
                            </span>
                          </Button>
                        </label>
                        {isAnalyzing && (
                          <div className="flex items-center gap-2 text-blue-600">
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                            <span className="text-sm">Analyzing photo...</span>
                          </div>
                        )}
                      </div>

                      {uploadedImage && (
                        <div className="mt-3">
                          <img
                            src={uploadedImage}
                            alt="Application photo"
                            className="max-w-full h-32 object-contain border rounded"
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Application Time Selection */}
                  <FormField
                    control={form.control}
                    name="dateOption"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Application Time</FormLabel>
                        <FormControl>
                          <RadioGroup
                            value={field.value}
                            onValueChange={(value) => {
                              field.onChange(value);
                              handleDateOptionChange(
                                value as
                                  | "today-morning"
                                  | "today-afternoon"
                                  | "manual",
                              );
                            }}
                            className="grid grid-cols-1 gap-3"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem
                                value="today-morning"
                                id="today-morning"
                              />
                              <Label
                                htmlFor="today-morning"
                                className="font-normal"
                              >
                                Today Morning (30/05/2025 07:00-10:00am)
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem
                                value="today-afternoon"
                                id="today-afternoon"
                              />
                              <Label
                                htmlFor="today-afternoon"
                                className="font-normal"
                              >
                                Today Afternoon (30/05/2025 11:00-2:30pm)
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="manual" id="manual" />
                              <Label htmlFor="manual" className="font-normal">
                                Manual Entry
                              </Label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Manual DateTime Input - only show when manual is selected */}
                  {form.watch("dateOption") === "manual" && (
                    <FormField
                      control={form.control}
                      name="manualDateTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Enter Date and Time</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="30/05/2025 14:30 or similar format"
                              onChange={(e) => {
                                field.onChange(e.target.value);
                                form.setValue("date", e.target.value);
                                setHasEditedTime(true);
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Application Type</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="SprayCan">
                                SprayCan Application
                              </SelectItem>
                              <SelectItem value="Fertilizer">
                                Fertilizer Application
                              </SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="products"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Products Used</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Heritage Maxx + Primo Maxx"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="productDetails"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Details</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Fungicide + Growth Regulator"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="areaId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Area</FormLabel>
                          <Select
                            onValueChange={handleAreaChange}
                            value={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select area" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {areas.map((area) => (
                                <SelectItem
                                  key={area.id}
                                  value={area.id.toString()}
                                >
                                  {area.name} ({area.hectares} ha)
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="rate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Application Rate</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="200 L/ha" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="weather"
                    render={({ field }) => {
                      const currentWeather = weatherData as any;

                      // Auto-fill weather when data loads and field is empty
                      useEffect(() => {
                        if (currentWeather && !field.value) {
                          const weatherString = `${currentWeather.temperature}°C, ${currentWeather.condition}, ${currentWeather.windSpeed} km/h wind, ${currentWeather.humidity}% humidity`;
                          field.onChange(weatherString);
                        }
                      }, [currentWeather, field.value, field.onChange]);

                      return (
                        <FormItem>
                          <FormLabel>Weather Conditions</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue
                                  placeholder={
                                    currentWeather
                                      ? "Weather conditions loaded"
                                      : "Loading weather..."
                                  }
                                />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {currentWeather && (
                                <SelectItem
                                  value={`${currentWeather.temperature}°C, ${currentWeather.condition}, ${currentWeather.windSpeed} km/h wind, ${currentWeather.humidity}% humidity`}
                                >
                                  {currentWeather.temperature}°C,{" "}
                                  {currentWeather.condition},{" "}
                                  {currentWeather.windSpeed} km/h wind,{" "}
                                  {currentWeather.humidity}% humidity
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      );
                    }}
                  />

                  {/* Cost Calculation Section */}
                  <div className="border rounded-lg p-4 bg-slate-50">
                    <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center gap-2">
                      <span className="text-green-600">£</span>
                      Application Cost
                    </h3>
                    {(() => {
                      const areaId = form.watch("areaId");
                      const products = form.watch("products");
                      const productDetails = form.watch("productDetails");
                      const waterVolume = form.watch("waterVolume");

                      // Find selected area
                      const selectedArea = areas?.find(
                        (area) => area.id === areaId,
                      );
                      const areaSize = selectedArea?.hectares || 0;

                      if (!products || !selectedArea || areaSize === 0) {
                        return (
                          <div className="text-sm text-slate-600">
                            Select target area and products to calculate costs
                          </div>
                        );
                      }

                      // UK Professional Golf Course Pricing (Scotland 2025) - Research Verified
                      const productPricing = {
                        // Iron Products & Liquid Feeds
                        "Elevate Fe Iron": {
                          price: 7.5,
                          unit: "L",
                          density: 1.2,
                        }, // £375/50L = £7.50/L
                        "Elevate Fe": { price: 7.5, unit: "L", density: 1.2 }, // £375/50L = £7.50/L
                        "Liquid Turf Hardener": {
                          price: 4.5,
                          unit: "L",
                          density: 1.0,
                        }, // £45/10L = £4.50/L
                        "Symbio Liquid Fertiliser": {
                          price: 2.5,
                          unit: "L",
                          density: 1.0,
                        }, // £49.90/20L = £2.50/L
                        Turfcomplex: { price: 9.0, unit: "L", density: 1.0 }, // £90/10L = £9.00/L

                        // Fertilizers & Granular Products
                        "Ammonium Sulphate": {
                          price: 1.2,
                          unit: "kg",
                          density: 1.0,
                        }, // £30/25kg = £1.20/kg
                        "Ammonium Sulphate (AMS)": {
                          price: 1.2,
                          unit: "kg",
                          density: 1.0,
                        }, // £30/25kg = £1.20/kg
                        AMS: { price: 1.2, unit: "kg", density: 1.0 }, // £30/25kg = £1.20/kg
                        Urea: { price: 0.8, unit: "kg", density: 1.0 }, // £20/25kg = £0.80/kg
                        NPK: { price: 1.12, unit: "kg", density: 1.0 }, // Standard fertilizer pricing
                        "Headland C-Complex": {
                          price: 1.85,
                          unit: "kg",
                          density: 1.0,
                        }, // £37/20kg = £1.85/kg
                        "Fine Turf Hardener": {
                          price: 1.65,
                          unit: "kg",
                          density: 1.0,
                        }, // £33/20kg = £1.65/kg
                        "Foltec SG Minors": {
                          price: 27.5,
                          unit: "kg",
                          density: 1.0,
                        }, // £275/10kg = £27.50/kg
                        "Lawn Sand": { price: 0.85, unit: "kg", density: 1.0 }, // £17/20kg = £0.85/kg

                        // Growth Regulators (Operational Record Pricing)
                        Primo: { price: 52.5, unit: "L", density: 1.0 }, // £105/2L = £52.50/L (operational record)
                        "Primo Maxx": { price: 52.5, unit: "L", density: 1.0 }, // £105/2L = £52.50/L (operational record)
                        "Primo Maxx II": {
                          price: 52.5,
                          unit: "L",
                          density: 1.0,
                        }, // £105/2L = £52.50/L (operational record)
                        Attraxor: { price: 211.1, unit: "kg", density: 1.0 }, // £316.65/1.5kg = £211.10/kg

                        // Fungicides (Professional)
                        "Medallion TL": {
                          price: 286.67,
                          unit: "L",
                          density: 1.1,
                        }, // £860/3L = £286.67/L
                        Fighter: { price: 70.0, unit: "L", density: 1.0 }, // £350/5L = £70/L
                        Heritage: { price: 95.0, unit: "L", density: 1.0 }, // Professional estimate
                        "Banner Maxx": { price: 78.0, unit: "L", density: 1.0 }, // Professional estimate

                        // Wetting Agents & Additives
                        "TriCure AD": { price: 27.5, unit: "L", density: 1.0 }, // £275/10L = £27.50/L
                        Qualibra: { price: 12.8, unit: "L", density: 1.0 }, // Estimated professional rate
                        Primer: { price: 11.5, unit: "L", density: 1.0 }, // Estimated professional rate
                        Foamcheck: { price: 27.0, unit: "L", density: 1.0 }, // £27/L defoamer
                        Photon: { price: 46.5, unit: "L", density: 1.0 }, // £46.50/L turf paint

                        // Herbicides (Professional)
                        Diamond: { price: 47.5, unit: "L", density: 1.0 }, // £47.50/L glyphosate mix
                        Celadon: { price: 52.5, unit: "L", density: 1.0 }, // £105/2L = £52.50/L
                        Junction: { price: 50.16, unit: "L", density: 1.0 }, // £250.80/5L = £50.16/L

                        // Insecticides (Professional)
                        Acelepryn: { price: 975.0, unit: "L", density: 1.0 }, // £585/0.6L = £975/L

                        // Biostimulants (Professional)
                        "Symbio Endo Mycorrhizae": {
                          price: 638.45,
                          unit: "L",
                          density: 1.0,
                        }, // £127.69/0.2L = £638.45/L
                        "Symbio ThatchEater": {
                          price: 145.95,
                          unit: "treatment",
                          density: 1.0,
                        }, // Per treatment pack
                      };

                      let totalCost = 0;
                      const costBreakdown = [];

                      // Parse product details to extract quantities
                      if (productDetails) {
                        const productItems = productDetails
                          .split(",")
                          .map((item) => item.trim());

                        productItems.forEach((item) => {
                          // Extract quantity and product name (e.g., "20L Elevate Fe Iron", "10kg Ammonium Sulphate")
                          const match = item.match(
                            /^(\d+(?:\.\d+)?)(L|kg|ml)\s+(.+)$/i,
                          );
                          if (match) {
                            const quantity = parseFloat(match[1]);
                            const unit = match[2].toLowerCase();
                            const productName = match[3].trim();

                            // Find pricing data
                            const pricing =
                              productPricing[
                                productName as keyof typeof productPricing
                              ] ||
                              Object.entries(productPricing).find(([key]) =>
                                productName
                                  .toLowerCase()
                                  .includes(key.toLowerCase()),
                              )?.[1];

                            if (pricing) {
                              // Convert units if needed
                              let adjustedQuantity = quantity;
                              if (unit === "ml" && pricing.unit === "L") {
                                adjustedQuantity = quantity / 1000;
                              }

                              const itemCost = adjustedQuantity * pricing.price;
                              totalCost += itemCost;

                              costBreakdown.push({
                                product: productName,
                                quantity: `${quantity}${unit}`,
                                unitPrice: `£${pricing.price.toFixed(2)}/${pricing.unit}`,
                                totalCost: itemCost,
                              });
                            }
                          }
                        });
                      }

                      // Add water cost (Scottish commercial rate for golf course irrigation: £0.98/1000L)
                      if (waterVolume) {
                        const waterMatch = waterVolume.match(
                          /^(\d+(?:\.\d+)?)(L|l)$/,
                        );
                        if (waterMatch) {
                          const waterQuantity = parseFloat(waterMatch[1]);
                          const waterCost =
                            (waterQuantity / 1000) * 0.98 * areaSize; // Scale by area
                          totalCost += waterCost;

                          costBreakdown.push({
                            product: "Mains Water (Scottish Commercial)",
                            quantity: `${(waterQuantity * areaSize).toFixed(0)}L`,
                            unitPrice: "£0.98/1000L",
                            totalCost: waterCost,
                          });
                        }
                      }

                      const costPerHectare = totalCost / areaSize;

                      return (
                        <div className="space-y-3">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-slate-600">Area:</span>
                              <span className="ml-2 font-medium">
                                {selectedArea.name} ({areaSize} ha)
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-600">
                                Total Material Cost:
                              </span>
                              <span className="ml-2 font-medium">
                                £{totalCost.toFixed(2)}
                              </span>
                            </div>
                          </div>

                          {costBreakdown.length > 0 && (
                            <div className="bg-white rounded border p-3">
                              <div className="text-sm font-medium text-slate-700 mb-2">
                                Cost Breakdown:
                              </div>
                              {costBreakdown.map((item, index) => (
                                <div
                                  key={index}
                                  className="flex justify-between text-xs py-1"
                                >
                                  <span className="text-slate-600">
                                    {item.product} ({item.quantity})
                                  </span>
                                  <span className="font-medium">
                                    £{item.totalCost.toFixed(2)}
                                  </span>
                                </div>
                              ))}
                              <div className="border-t pt-2 mt-2 flex justify-between font-semibold">
                                <span>Total Application Cost:</span>
                                <span className="text-green-600">
                                  £{totalCost.toFixed(2)}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>

                  {form.watch("type") === "SprayCan" && (
                    <FormField
                      control={form.control}
                      name="waterVolume"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Water Volume</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="200 L/ha" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  {form.watch("type") === "Fertilizer" && (
                    <FormField
                      control={form.control}
                      name="spreaderSetting"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Spreader Setting</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="2.5" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Additional notes..."
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsDialogOpen(false);
                        form.reset();
                        setHasEditedTime(false);
                        setHasSelectedArea(false);
                        setUploadedImage(null);
                      }}
                    >
                      Cancel
                    </Button>
                    {editingRecord && (
                      <Button
                        type="button"
                        variant="destructive"
                        onClick={() => {
                          if (
                            window.confirm(
                              "Are you sure you want to delete this record?",
                            )
                          ) {
                            deleteMutation.mutate(editingRecord.id);
                          }
                        }}
                        disabled={deleteMutation.isPending}
                      >
                        Delete Record
                      </Button>
                    )}
                    <Button
                      type="submit"
                      disabled={
                        createMutation.isPending ||
                        updateMutation.isPending ||
                        !hasSelectedArea
                      }
                    >
                      {!hasSelectedArea
                        ? "Please select target area"
                        : editingRecord
                          ? "Update Record"
                          : "Create Record"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <Calendar className="text-green-600" size={16} />
              </div>
              <div>
                <div className="text-sm text-slate-600">This Week</div>
                <div className="text-xl font-bold text-slate-900">
                  {stats.thisWeek}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <CalendarDays className="text-blue-600" size={16} />
              </div>
              <div>
                <div className="text-sm text-slate-600">This Month</div>
                <div className="text-xl font-bold text-slate-900">
                  {stats.thisMonth}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <SprayCan className="text-yellow-600" size={16} />
                </div>
                <div>
                  <div className="text-sm text-slate-600">Spray Apps</div>
                  <div className="text-xl font-bold text-slate-900">
                    {stats.sprayApps}
                  </div>
                  <div className="text-xs text-green-600 font-medium">
                    Total: £{sprayAppsCost.toFixed(2)}
                  </div>
                </div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Eye className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Spray Applications Cost Breakdown</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    {records
                      .filter(
                        (r) => r.type === "Spray" || r.type === "SprayCan",
                      )
                      .map((record) => {
                        const area = areas.find((a) => a.id === record.areaId);
                        if (!area) return null;

                        const recordCost = calculateApplicationCost(record);

                        return (
                          <div
                            key={record.id}
                            className="border rounded-lg p-4"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <div className="font-medium">
                                  {new Date(record.date).toLocaleDateString()}
                                </div>
                                <div className="text-sm text-slate-600">
                                  {area.name} ({area.hectares} ha)
                                </div>
                                <div className="text-sm text-slate-500">
                                  {record.products}
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-bold text-green-600">
                                  £{recordCost.toFixed(2)}
                                </div>
                                <div className="text-xs text-slate-500">
                                  £{(recordCost / area.hectares).toFixed(2)}/ha
                                </div>
                              </div>
                            </div>
                            <div className="text-sm text-slate-600">
                              Product Details: {record.productDetails}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Sprout className="text-purple-600" size={16} />
                </div>
                <div>
                  <div className="text-sm text-slate-600">Fertilizer Apps</div>
                  <div className="text-xl font-bold text-slate-900">
                    {stats.fertilizerApps}
                  </div>
                  <div className="text-xs text-green-600 font-medium">
                    Total: £{fertilizerAppsCost.toFixed(2)}
                  </div>
                </div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <Eye className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>
                      Fertilizer Applications Cost Breakdown
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    {records
                      .filter((r) => r.type === "Fertilizer")
                      .map((record) => {
                        const area = areas.find((a) => a.id === record.areaId);
                        if (!area) return null;

                        const recordCost = calculateApplicationCost(record);

                        return (
                          <div
                            key={record.id}
                            className="border rounded-lg p-4"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <div className="font-medium">
                                  {new Date(record.date).toLocaleDateString()}
                                </div>
                                <div className="text-sm text-slate-600">
                                  {area.name} ({area.hectares} ha)
                                </div>
                                <div className="text-sm text-slate-500">
                                  {record.products}
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-bold text-green-600">
                                  £{recordCost.toFixed(2)}
                                </div>
                                <div className="text-xs text-slate-500">
                                  £{(recordCost / area.hectares).toFixed(2)}/ha
                                </div>
                              </div>
                            </div>
                            <div className="text-sm text-slate-600">
                              Product Details: {record.productDetails}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Records Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Applications</CardTitle>
            <div className="flex space-x-3">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="spray">SprayCan Applications</SelectItem>
                  <SelectItem value="fertilizer">
                    Fertilizer Applications
                  </SelectItem>
                </SelectContent>
              </Select>
              <Select value={timeFilter} onValueChange={setTimeFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last-7-days">Last 7 Days</SelectItem>
                  <SelectItem value="last-30-days">Last 30 Days</SelectItem>
                  <SelectItem value="last-90-days">Last 90 Days</SelectItem>
                  <SelectItem value="this-year">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Mobile Card Layout */}
          <div className="block md:hidden space-y-4">
            {filteredRecords.length === 0 ? (
              <div className="py-8 px-4 text-center text-slate-500">
                No application records found for the selected filters.
              </div>
            ) : (
              filteredRecords.map((record) => (
                <Card key={record.id} className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium text-slate-900">
                          {new Date(record.date).toLocaleDateString("en-GB")}
                        </div>
                        <div className="text-xs text-slate-500">
                          {new Date(record.date).toLocaleTimeString("en-GB", {
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: true,
                          })}
                        </div>
                      </div>
                      <Badge
                        className={getTypeColor(record.type)}
                        variant="secondary"
                      >
                        <div className="flex items-center space-x-1">
                          {getTypeIcon(record.type)}
                          <span className="text-xs">{record.type}</span>
                        </div>
                      </Badge>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-slate-900 mb-1">
                        {record.products}
                      </div>
                      <div className="text-xs text-slate-500 mb-2">
                        {formatProductDetails(record.productDetails)}
                      </div>
                      <div className="flex flex-wrap gap-2 text-xs">
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          📍 {record.areaName}
                        </span>
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded">
                          💧 {record.rate}
                        </span>
                        <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded">
                          {getWeatherIcon(record.weather)} {record.weather}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2 justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setViewingRecord(record);
                          setIsViewDialogOpen(true);
                        }}
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingRecord(record);
                          setIsDialogOpen(true);
                        }}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>

          {/* Desktop Table Layout */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left py-3 px-4 font-medium text-slate-700 min-w-[100px]">
                    Date
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700 min-w-[80px]">
                    Type
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700 min-w-[200px]">
                    Product(s)
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700 min-w-[100px]">
                    Area
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700 min-w-[80px]">
                    Rate
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700 min-w-[100px]">
                    Weather
                  </th>
                  <th className="text-right py-3 px-4 font-medium text-slate-700 min-w-[100px]">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td
                      colSpan={7}
                      className="py-8 px-4 text-center text-slate-500"
                    >
                      No application records found for the selected filters.
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map((record) => (
                    <tr
                      key={record.id}
                      className="hover:bg-slate-50 transition-colors"
                    >
                      <td className="py-4 px-4 text-slate-900">
                        <div className="text-sm">
                          {new Date(record.date).toLocaleDateString("en-GB")}
                        </div>
                        <div className="text-xs text-slate-500">
                          {new Date(record.date).toLocaleTimeString("en-GB", {
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: true,
                          })}
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Badge
                          className={getTypeColor(record.type)}
                          variant="secondary"
                        >
                          <div className="flex items-center space-x-1">
                            {getTypeIcon(record.type)}
                            <span>{record.type}</span>
                          </div>
                        </Badge>
                      </td>
                      <td className="py-4 px-4 min-w-0 w-1/3">
                        <div className="text-slate-900 font-medium text-sm break-words leading-tight">
                          {record.products}
                        </div>
                        <div className="text-xs text-slate-500 break-words leading-tight mt-1">
                          {formatProductDetails(record.productDetails)}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-slate-900 text-sm">
                        {record.areaName}
                      </td>
                      <td className="py-3 px-3 text-slate-900 text-sm">
                        {record.rate}
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center">
                          {getWeatherIcon(record.weather)}
                          <span className="text-sm text-slate-600 ml-2">
                            {record.weather}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="grid grid-cols-2 gap-1 w-fit ml-auto">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setViewingRecord(record);
                              setIsViewDialogOpen(true);
                            }}
                            className="h-8 w-8 p-0"
                          >
                            <Eye size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setEditingRecord(record);
                              // Reset form with record data
                              const recordDate = new Date(record.date);
                              const formattedDateTime = recordDate
                                .toISOString()
                                .slice(0, 16);
                              form.reset({
                                type: record.type,
                                products: record.products,
                                productDetails: record.productDetails,
                                areaId: record.areaId,
                                areaName: record.areaName,
                                rate: record.rate,
                                spreaderSetting: record.spreaderSetting || "",
                                waterVolume: record.waterVolume || "",
                                notes: record.notes || "",
                                weather: record.weather,
                                dateOption: "manual",
                                manualDateTime: formattedDateTime,
                                date:
                                  recordDate.toLocaleDateString("en-GB") +
                                  " " +
                                  recordDate.toLocaleTimeString("en-GB"),
                              });
                              setHasSelectedArea(true);
                              setIsDialogOpen(true);
                            }}
                            className="h-8 w-8 p-0"
                          >
                            <Edit size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.print()}
                            className="h-8 w-8 p-0"
                          >
                            <Printer size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              if (
                                confirm(
                                  "Are you sure you want to delete this application record?",
                                )
                              ) {
                                deleteMutation.mutate(record.id);
                              }
                            }}
                            className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* View Application Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BarChart3 className="text-blue-600" size={24} />
              Application Analysis & Statistics
            </DialogTitle>
          </DialogHeader>

          {viewingRecord && (
            <div className="space-y-6">
              {/* Header Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {new Date(viewingRecord.date).toLocaleDateString("en-GB")}
                  </div>
                  <div className="text-sm text-slate-600">Application Date</div>
                  <div className="text-xs text-slate-500">
                    {new Date(viewingRecord.date).toLocaleTimeString("en-GB", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {viewingRecord.rate}
                  </div>
                  <div className="text-sm text-slate-600">Application Rate</div>
                  <div className="text-xs text-slate-500">
                    {viewingRecord.areaName}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {getSeason(new Date(viewingRecord.date))}
                  </div>
                  <div className="text-sm text-slate-600">Season Applied</div>
                  <div className="text-xs text-slate-500">
                    Dullatur Golf Club
                  </div>
                </div>
              </div>

              {/* Weather Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cloud className="text-blue-500" size={20} />
                    Weather Conditions (Dullatur Golf Club)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div className="font-medium text-blue-800">
                          Application Day Weather
                        </div>
                        {(viewingRecord.weather === "Recorded from system" ||
                          !viewingRecord.weather) && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={async () => {
                              try {
                                const response = await fetch(
                                  `/api/application-records/${viewingRecord.id}/refresh-weather`,
                                  {
                                    method: "POST",
                                  },
                                );
                                if (response.ok) {
                                  const updatedRecord = await response.json();
                                  setViewingRecord(updatedRecord);
                                  queryClient.invalidateQueries({
                                    queryKey: ["/api/application-records"],
                                  });
                                  toast({
                                    title:
                                      "Weather data refreshed successfully",
                                  });
                                } else {
                                  toast({
                                    title: "Failed to refresh weather data",
                                    variant: "destructive",
                                  });
                                }
                              } catch (error) {
                                toast({
                                  title: "Failed to refresh weather data",
                                  variant: "destructive",
                                });
                              }
                            }}
                            className="text-xs"
                          >
                            <RefreshCw size={12} className="mr-1" />
                            Refresh
                          </Button>
                        )}
                      </div>
                      <div className="text-sm text-blue-600 mt-1">
                        {viewingRecord.weather === "Recorded from system" ||
                        !viewingRecord.weather
                          ? "Weather data not captured for this record"
                          : viewingRecord.weather}
                      </div>
                      <div className="text-xs text-blue-500 mt-1">
                        {new Date(viewingRecord.date).toLocaleDateString(
                          "en-GB",
                        )}{" "}
                        at{" "}
                        {new Date(viewingRecord.date).toLocaleTimeString(
                          "en-GB",
                          {
                            hour: "2-digit",
                            minute: "2-digit",
                          },
                        )}
                      </div>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg">
                      <div className="font-medium text-green-800">
                        Weather Impact
                      </div>
                      <div className="text-sm text-green-600 mt-1">
                        {viewingRecord.weather === "Recorded from system" ||
                        !viewingRecord.weather
                          ? "Historical weather data needed for effectiveness analysis"
                          : "Conditions analyzed for spray effectiveness and timing suitability"}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Product Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <SprayCan className="text-green-500" size={20} />
                    Products Applied
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="font-medium">{viewingRecord.products}</div>
                    <div className="text-sm text-slate-600 p-3 bg-slate-50 rounded">
                      {formatProductDetails(viewingRecord.productDetails)}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* AI Expert Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Target className="text-orange-500" size={20} />
                      Professional Greenkeeping Analysis
                    </div>
                    <Button
                      onClick={() => getAiSprayAnalysis(viewingRecord)}
                      disabled={isLoadingAnalysis}
                      size="sm"
                      className="bg-orange-600 hover:bg-orange-700"
                    >
                      {isLoadingAnalysis
                        ? "Analyzing..."
                        : viewingRecord.expertAnalysis
                          ? "Refresh Analysis"
                          : "Get Expert Analysis"}
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoadingAnalysis && (
                    <div className="flex items-center justify-center py-8">
                      <div className="text-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600 mx-auto mb-4"></div>
                        <div className="text-sm text-slate-600">
                          Analyzing spray combination with expert knowledge...
                        </div>
                      </div>
                    </div>
                  )}
                  {(aiAnalysis || viewingRecord.expertAnalysis) &&
                    !isLoadingAnalysis && (
                      <div className="prose prose-sm max-w-none">
                        <div className="whitespace-pre-wrap text-sm text-slate-700 leading-relaxed">
                          {aiAnalysis || viewingRecord.expertAnalysis}
                        </div>
                      </div>
                    )}
                  {!aiAnalysis &&
                    !viewingRecord.expertAnalysis &&
                    !isLoadingAnalysis && (
                      <div className="text-center py-8 text-slate-500">
                        <Target
                          size={48}
                          className="mx-auto mb-4 text-slate-300"
                        />
                        <div className="text-sm">
                          Click "Get Expert Analysis" to receive professional
                          insights about this spray application, including
                          product synergy, seasonal timing, and expected turf
                          benefits.
                        </div>
                      </div>
                    )}
                </CardContent>
              </Card>

              {/* Application Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="text-indigo-500" size={20} />
                    Application Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Application Type:
                        </span>
                        <Badge
                          className={getTypeColor(viewingRecord.type)}
                          variant="secondary"
                        >
                          {viewingRecord.type}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Target Area:
                        </span>
                        <span className="text-sm font-medium">
                          {viewingRecord.areaName}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">Season:</span>
                        <span className="text-sm font-medium">
                          {getSeason(new Date(viewingRecord.date))}
                        </span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Application Rate:
                        </span>
                        <span className="text-sm font-medium">
                          {viewingRecord.rate}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Record Created:
                        </span>
                        <span className="text-sm font-medium">
                          {new Date(
                            viewingRecord.createdAt || viewingRecord.date,
                          ).toLocaleDateString("en-GB")}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Weather Recorded:
                        </span>
                        <span className="text-sm font-medium">Yes</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
