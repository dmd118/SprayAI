import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Calendar, Clock, Users, AlertTriangle, TrendingUp, CheckCircle, Leaf, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { StaffCalendar } from "@/components/staff-calendar";
import type { StaffMember } from "@shared/schema";

interface RotaGenerationParams {
  totalStaff: number;
  annualHours: number;
  weekendStartTime: string;
  weekendEndTime: string;
  christmasStartDate: string;
  christmasEndDate: string;
  minimumStaffOnDuty: number;
}

interface FairnessReport {
  staffId: number;
  name: string;
  weekendsAssigned: number;
  hoursWorked: number;
  timeOffOwed: number;
}

export function StaffRota() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [rotaParams, setRotaParams] = useState<RotaGenerationParams>({
    totalStaff: 6,
    annualHours: 2080,
    weekendStartTime: "08:00",
    weekendEndTime: "16:00",
    christmasStartDate: "2024-12-20",
    christmasEndDate: "2025-01-03",
    minimumStaffOnDuty: 1
  });

  const [generatedRota, setGeneratedRota] = useState<any>(null);
  const [selectedStaffMember, setSelectedStaffMember] = useState<StaffMember | null>(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const handleStaffMemberClick = (staffMember: StaffMember) => {
    setSelectedStaffMember(staffMember);
    setIsCalendarOpen(true);
  };

  const handleCloseCalendar = () => {
    setIsCalendarOpen(false);
    setSelectedStaffMember(null);
  };

  // Fetch staff members
  const { data: staffMembers = [], isLoading: staffLoading } = useQuery({
    queryKey: ['/api/staff-members'],
  });

  // Fetch current rota
  const currentRotaQuery = useQuery({
    queryKey: ['/api/staff-rota'],
  });

  const currentRota = currentRotaQuery.data || [];
  const rotaLoading = currentRotaQuery.isLoading;
  
  // Check if we have an active rota - handle both array and object responses
  const hasActiveRota = currentRota && Array.isArray(currentRota) && currentRota.length > 0;

  // Generate AI-optimized rota
  const generateRotaMutation = useMutation({
    mutationFn: async (params: RotaGenerationParams) => {
      const response = await fetch('/api/staff-rota/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate rota');
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      setGeneratedRota(data);
      // Invalidate and refetch the rota query to show the saved data immediately
      queryClient.invalidateQueries({ queryKey: ['/api/staff-rota'] });
      queryClient.refetchQueries({ queryKey: ['/api/staff-rota'] });
      toast({
        title: "Rota Generated Successfully",
        description: `Generated fair weekend schedule with ${data.rota?.length || 0} shifts automatically saved to database.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate the staff rota. Please check your parameters.",
        variant: "destructive",
      });
    }
  });

  // Replace existing rota (clear and regenerate)
  const replaceRotaMutation = useMutation({
    mutationFn: async (params: RotaGenerationParams) => {
      // First clear the existing rota
      await fetch('/api/staff-rota/clear', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      // Then generate new rota
      const response = await fetch('/api/staff-rota/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      });
      
      if (!response.ok) {
        throw new Error('Failed to replace rota');
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      setGeneratedRota(data);
      queryClient.invalidateQueries({ queryKey: ['/api/staff-rota'] });
      toast({
        title: "Rota Replaced Successfully",
        description: `Replaced existing rota with new schedule containing ${data.rota?.length || 0} shifts.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Replace Failed",
        description: error.message || "Failed to replace the staff rota.",
        variant: "destructive",
      });
    }
  });

  // Delete rota mutation
  const deleteRotaMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/staff-rota/clear', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete rota');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff-rota'] });
      toast({
        title: "Rota Deleted",
        description: "All weekend shifts have been cleared from the database.",
      });
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete the rota from database.",
        variant: "destructive",
      });
    }
  });

  const handleGenerateRota = () => {
    if (hasActiveRota) {
      const confirmed = window.confirm(
        "⚠️ WARNING: A rota is already active!\n\n" +
        "Generating a new rota will overwrite the current weekend schedule that your staff are already planning around.\n\n" +
        "Are you sure you want to proceed? This action cannot be undone."
      );
      if (!confirmed) {
        return;
      }
    }
    generateRotaMutation.mutate(rotaParams);
  };

  // Save functionality removed - rota is auto-saved during generation

  const updateParam = (key: keyof RotaGenerationParams, value: string | number) => {
    setRotaParams(prev => ({ ...prev, [key]: value }));
  };

  if (staffLoading || rotaLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading staff rota system...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Navigation Header */}
      <div className="flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-green-600 hover:text-green-700 transition-colors">
          <Leaf className="h-5 w-5" />
          <span className="font-medium">Back to Dashboard</span>
        </Link>
      </div>

      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Staff Rota Management</h1>
        <p className="text-gray-600">Intelligent weekend scheduling with fair workload distribution</p>
      </div>

      {/* Staff Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Staff Members ({staffMembers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {staffMembers.map((staff: StaffMember) => (
              <div 
                key={staff.id} 
                className="flex items-center justify-between p-4 bg-white border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 cursor-pointer transition-all duration-200 shadow-sm hover:shadow-md"
                onClick={() => handleStaffMemberClick(staff)}
              >
                <div>
                  <p className="font-semibold text-gray-900 text-lg">{staff.name}</p>
                  <p className="text-sm text-gray-600">{staff.staffType}</p>
                  <p className="text-xs text-green-600 font-medium mt-1">📅 Click to view calendar</p>
                </div>
                <Badge variant={staff.isActive ? "default" : "secondary"}>
                  {staff.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Rota Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Rota Configuration
          </CardTitle>
          <CardDescription>
            Configure parameters for AI-powered fair scheduling
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weekendStart">Weekend Start Time</Label>
              <Input
                id="weekendStart"
                type="time"
                value={rotaParams.weekendStartTime}
                onChange={(e) => updateParam('weekendStartTime', e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="weekendEnd">Weekend End Time</Label>
              <Input
                id="weekendEnd"
                type="time"
                value={rotaParams.weekendEndTime}
                onChange={(e) => updateParam('weekendEndTime', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="christmasStart">Christmas Period Start</Label>
              <Input
                id="christmasStart"
                type="date"
                value={rotaParams.christmasStartDate}
                onChange={(e) => updateParam('christmasStartDate', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="christmasEnd">Christmas Period End</Label>
              <Input
                id="christmasEnd"
                type="date"
                value={rotaParams.christmasEndDate}
                onChange={(e) => updateParam('christmasEndDate', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="minStaff">Minimum Staff on Duty</Label>
              <Input
                id="minStaff"
                type="number"
                min="1"
                value={rotaParams.minimumStaffOnDuty}
                onChange={(e) => updateParam('minimumStaffOnDuty', parseInt(e.target.value))}
              />
            </div>
          </div>

          {hasActiveRota ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-700">Current rota is active with {Array.isArray(currentRota) ? currentRota.length : 0} shifts</span>
              </div>
              <Button 
                onClick={() => {
                  if (confirm('This will replace your current active rota. Continue?')) {
                    replaceRotaMutation.mutate(rotaParams);
                  }
                }}
                disabled={replaceRotaMutation.isPending}
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                {replaceRotaMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Replacing Rota...
                  </>
                ) : (
                  <>
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Replace Existing Rota
                  </>
                )}
              </Button>
            </div>
          ) : (
            <Button 
              onClick={handleGenerateRota}
              disabled={generateRotaMutation.isPending}
              className="w-full"
            >
              {generateRotaMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Generating AI-Optimized Rota...
                </>
              ) : (
                <>
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Generate New Rota
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Generated Rota Preview */}
      {generatedRota && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              Generated Rota Preview
            </CardTitle>
            <CardDescription>
              AI-optimized weekend schedule with fair workload distribution
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Fairness Report */}
            <div>
              <h3 className="text-lg font-semibold mb-3">Fairness Analysis</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {generatedRota.fairnessReport?.map((report: FairnessReport) => (
                  <div key={report.staffId} className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900">{report.name}</h4>
                    <div className="mt-2 space-y-1 text-sm">
                      <p><span className="font-medium">Weekends:</span> {report.weekendsAssigned}</p>
                      <p><span className="font-medium">Hours:</span> {report.hoursWorked}</p>
                      {report.timeOffOwed > 0 && (
                        <p className="text-orange-600">
                          <span className="font-medium">Time Off Owed:</span> {report.timeOffOwed}h
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Rota Summary */}
            <div>
              <h3 className="text-lg font-semibold mb-3">Rota Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="p-4 bg-green-50 rounded-lg text-center">
                  <div className="text-2xl font-bold text-green-700">{generatedRota.rota?.length || 0}</div>
                  <div className="text-sm text-green-600">Total Shifts</div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg text-center">
                  <div className="text-2xl font-bold text-blue-700">{generatedRota.christmasCoverage?.length || 0}</div>
                  <div className="text-sm text-blue-600">Christmas Shifts</div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg text-center">
                  <div className="text-2xl font-bold text-purple-700">
                    {Math.round((generatedRota.rota?.reduce((sum: number, shift: any) => sum + shift.hoursWorked, 0) || 0) / (generatedRota.rota?.length || 1) * 10) / 10}
                  </div>
                  <div className="text-sm text-purple-600">Avg Hours/Shift</div>
                </div>
              </div>

              <Button 
                onClick={() => {
                  setGeneratedRota(null);
                  queryClient.invalidateQueries({ queryKey: ['/api/staff-rota'] });
                  toast({
                    title: "Rota Activated",
                    description: "The weekend rota is now active and ready for use.",
                  });
                }}
                className="w-full"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Activate Rota Schedule
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Next Weekends Highlight Box */}
      {hasActiveRota && (
        <Card className="border-l-4 border-l-green-500 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/10 dark:to-blue-900/10">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="flex items-center gap-2 text-green-700 dark:text-green-300">
                  <Calendar className="h-5 w-5" />
                  NEXT WEEKENDS - WHO'S WORKING
                </CardTitle>
                <p className="text-sm font-medium text-green-600 dark:text-green-400">
                  Auto-updates when weekends pass • PERMANENTLY SAVED TO DATABASE ✓
                </p>
              </div>
              
              <Button 
                onClick={() => {
                  const confirmed = window.confirm(
                    "Are you sure you want to delete the entire rota? This will clear all weekend shifts from the database and allow you to generate a new schedule."
                  );
                  if (confirmed) {
                    deleteRotaMutation.mutate();
                  }
                }}
                disabled={deleteRotaMutation.isPending}
                variant="destructive"
                size="sm"
              >
                {deleteRotaMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Rota
                  </>
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {(() => {
                const today = new Date();
                const nextSaturday = new Date();
                nextSaturday.setDate(today.getDate() + (6 - today.getDay() + 7) % 7);
                if (nextSaturday <= today) {
                  nextSaturday.setDate(nextSaturday.getDate() + 7);
                }

                // Get next 4 weekends
                const nextWeekends = [];
                for (let i = 0; i < 4; i++) {
                  const weekendDate = new Date(nextSaturday);
                  weekendDate.setDate(weekendDate.getDate() + (i * 7));
                  
                  const saturdayShifts = (currentRota as any[]).filter(shift => {
                    const shiftDate = new Date(shift.date);
                    return shiftDate.getDay() === 6 && 
                           Math.abs(shiftDate.getTime() - weekendDate.getTime()) < 24 * 60 * 60 * 1000;
                  });
                  
                  const sundayDate = new Date(weekendDate);
                  sundayDate.setDate(sundayDate.getDate() + 1);
                  const sundayShifts = (currentRota as any[]).filter(shift => {
                    const shiftDate = new Date(shift.date);
                    return shiftDate.getDay() === 0 && 
                           Math.abs(shiftDate.getTime() - sundayDate.getTime()) < 24 * 60 * 60 * 1000;
                  });
                  
                  if (saturdayShifts.length > 0 || sundayShifts.length > 0) {
                    nextWeekends.push({
                      date: weekendDate,
                      saturday: saturdayShifts,
                      sunday: sundayShifts
                    });
                  }
                }

                return nextWeekends.map((weekend, index) => (
                  <div key={index} className={`p-4 rounded-lg border-2 ${
                    index === 0 ? 'border-yellow-400 bg-yellow-50 dark:bg-yellow-900/20' : 
                    'border-blue-200 bg-white dark:bg-gray-800'
                  }`}>
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-bold text-lg">
                        {index === 0 ? '🔥 THIS WEEKEND' : `Weekend ${index + 1}`} - {weekend.date.toLocaleDateString('en-GB', { 
                          day: 'numeric', 
                          month: 'short',
                          year: 'numeric'
                        })}
                      </h4>
                      <span className="px-3 py-1 bg-blue-500 text-white rounded-full text-sm font-medium">
                        {(weekend.saturday.length + weekend.sunday.length) / 2} Staff Each Day
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded">
                        <div className="font-semibold text-green-800 dark:text-green-200 mb-2">
                          Saturday 05:00-09:00
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {weekend.saturday.map(shift => (
                            <span 
                              key={shift.id}
                              className="px-3 py-1 bg-green-600 text-white rounded-full text-sm font-bold"
                            >
                              {shift.staffMember?.name || `Staff ${shift.staffMemberId}`}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded">
                        <div className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                          Sunday 05:00-09:00
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {weekend.sunday.map(shift => (
                            <span 
                              key={shift.id}
                              className="px-3 py-1 bg-blue-600 text-white rounded-full text-sm font-bold"
                            >
                              {shift.staffMember?.name || `Staff ${shift.staffMemberId}`}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ));
              })()}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Next 3 Weekends - Prominent Display */}
      {hasActiveRota && Array.isArray(currentRota) && (
        <Card className="border-green-500 border-2 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Calendar className="h-6 w-6" />
              Next 3 Weekends Schedule
            </CardTitle>
            <p className="text-sm text-green-700 font-medium">
              Upcoming weekend assignments - click any staff name to view their calendar
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {(() => {
                const today = new Date();
                const weekendGroups: { [key: string]: any[] } = {};
                
                (currentRota as any[]).forEach((shift: any) => {
                  const shiftDate = new Date(shift.date);
                  if (shiftDate >= today) {
                    const weekendKey = shiftDate.toISOString().substring(0, 10);
                    if (!weekendGroups[weekendKey]) {
                      weekendGroups[weekendKey] = [];
                    }
                    // Map the saved rota structure to match display expectations
                    weekendGroups[weekendKey].push({
                      ...shift,
                      staffMemberId: shift.staffId,
                      staffName: shift.staffName
                    });
                  }
                });
                
                const weekendPairs = [];
                const sortedDates = Object.keys(weekendGroups).sort();
                
                for (let i = 0; i < sortedDates.length; i += 2) {
                  const saturdayDate = sortedDates[i];
                  const sundayDate = sortedDates[i + 1];
                  
                  if (saturdayDate && sundayDate) {
                    const saturdayShifts = weekendGroups[saturdayDate] || [];
                    const sundayShifts = weekendGroups[sundayDate] || [];
                    
                    weekendPairs.push({
                      weekend: new Date(saturdayDate),
                      saturday: saturdayShifts,
                      sunday: sundayShifts
                    });
                  }
                }
                
                return weekendPairs.slice(0, 3).map((weekend, index) => (
                  <div key={index} className="bg-white rounded-lg p-6 border border-green-200 shadow-md">
                    <div className="text-center mb-4">
                      <div className="font-bold text-lg text-gray-900">
                        Weekend {index + 1}
                      </div>
                      <div className="text-sm text-gray-600">
                        {weekend.weekend.toLocaleDateString('en-GB', { 
                          weekday: 'long',
                          day: 'numeric', 
                          month: 'long',
                          year: 'numeric'
                        })}
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="text-sm font-semibold text-blue-800 mb-2 text-center">SATURDAY</div>
                        <div className="space-y-1">
                          {weekend.saturday.map((shift: any, idx: number) => {
                            const staffMember = (staffMembers as StaffMember[]).find((s: StaffMember) => s.id === (shift.staffMemberId || shift.staffId));
                            return (
                              <div 
                                key={idx} 
                                className="text-center bg-blue-100 text-blue-800 py-2 px-3 rounded-lg cursor-pointer hover:bg-blue-200 transition-colors font-medium"
                                onClick={() => staffMember && handleStaffMemberClick(staffMember)}
                              >
                                {shift.staffName}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-sm font-semibold text-green-800 mb-2 text-center">SUNDAY</div>
                        <div className="space-y-1">
                          {weekend.sunday.map((shift: any, idx: number) => {
                            const staffMember = (staffMembers as StaffMember[]).find((s: StaffMember) => s.id === (shift.staffMemberId || shift.staffId));
                            return (
                              <div 
                                key={idx} 
                                className="text-center bg-green-100 text-green-800 py-2 px-3 rounded-lg cursor-pointer hover:bg-green-200 transition-colors font-medium"
                                onClick={() => staffMember && handleStaffMemberClick(staffMember)}
                              >
                                {shift.staffName}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      
                      <div className="text-center text-xs text-gray-500 mt-3">
                        {weekend.saturday[0]?.startTime} - {weekend.saturday[0]?.endTime}
                      </div>
                    </div>
                  </div>
                ));
              })()}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Full Weekend Assignment Overview */}
      {hasActiveRota && Array.isArray(currentRota) && (
        <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Weekend Assignment Overview
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Quick view of upcoming weekend assignments - click any staff name to open their calendar
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {(() => {
                  const today = new Date();
                  const weekendGroups: { [key: string]: any[] } = {};
                  
                  (currentRota as any[]).forEach((shift: any) => {
                    const shiftDate = new Date(shift.date);
                    if (shiftDate >= today) {
                      const weekendKey = shiftDate.toISOString().substring(0, 10);
                      if (!weekendGroups[weekendKey]) {
                        weekendGroups[weekendKey] = [];
                      }
                      weekendGroups[weekendKey].push(shift);
                    }
                  });
                  
                  const weekendPairs = [];
                  const sortedDates = Object.keys(weekendGroups).sort();
                  
                  for (let i = 0; i < sortedDates.length; i += 2) {
                    const saturdayDate = sortedDates[i];
                    const sundayDate = sortedDates[i + 1];
                    
                    if (saturdayDate && sundayDate) {
                      const saturdayShifts = weekendGroups[saturdayDate] || [];
                      const sundayShifts = weekendGroups[sundayDate] || [];
                      
                      weekendPairs.push({
                        weekend: new Date(saturdayDate),
                        saturday: saturdayShifts,
                        sunday: sundayShifts
                      });
                    }
                  }
                  
                  return weekendPairs.slice(0, 8).map((weekend, index) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-4">
                      <div className="font-semibold text-gray-900 mb-3">
                        {weekend.weekend.toLocaleDateString('en-GB', { 
                          day: 'numeric', 
                          month: 'short',
                          year: 'numeric'
                        })}
                      </div>
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-blue-700 mb-1">Saturday</div>
                        {weekend.saturday.map((shift: any, idx: number) => {
                          const staffMember = (staffMembers as StaffMember[]).find((s: StaffMember) => s.id === shift.staffMemberId);
                          return (
                            <div 
                              key={idx} 
                              className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded cursor-pointer hover:bg-blue-200 transition-colors"
                              onClick={() => staffMember && handleStaffMemberClick(staffMember)}
                            >
                              {shift.staffName}
                            </div>
                          );
                        })}
                        <div className="text-sm font-medium text-green-700 mb-1 mt-3">Sunday</div>
                        {weekend.sunday.map((shift: any, idx: number) => {
                          const staffMember = (staffMembers as StaffMember[]).find((s: StaffMember) => s.id === shift.staffMemberId);
                          return (
                            <div 
                              key={idx} 
                              className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded cursor-pointer hover:bg-green-200 transition-colors"
                              onClick={() => staffMember && handleStaffMemberClick(staffMember)}
                            >
                              {shift.staffName}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}
              </div>
            </CardContent>
        </Card>
      )}

      {/* Complete Weekend Schedule Table */}
      {hasActiveRota && Array.isArray(currentRota) && (
        <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Complete Weekend Schedule Table
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Detailed schedule overview - click staff names to open individual calendars
              </p>
            </CardHeader>
            <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left p-3 font-semibold">Weekend Date</th>
                    <th className="text-left p-3 font-semibold">Saturday Staff</th>
                    <th className="text-left p-3 font-semibold">Sunday Staff</th>
                    <th className="text-left p-3 font-semibold">Shift Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const today = new Date();
                    
                    // Group shifts by weekend
                    const weekendGroups: { [key: string]: any[] } = {};
                    (currentRota as any[]).forEach((shift: any) => {
                      const shiftDate = new Date(shift.date);
                      if (shiftDate >= today) {
                        const weekendKey = shiftDate.toISOString().substring(0, 10);
                        if (!weekendGroups[weekendKey]) {
                          weekendGroups[weekendKey] = [];
                        }
                        weekendGroups[weekendKey].push(shift);
                      }
                    });
                    
                    // Convert to weekend pairs and sort
                    const weekendPairs = [];
                    const sortedDates = Object.keys(weekendGroups).sort();
                    
                    for (let i = 0; i < sortedDates.length; i += 2) {
                      const saturdayDate = sortedDates[i];
                      const sundayDate = sortedDates[i + 1];
                      
                      if (saturdayDate && sundayDate) {
                        const saturdayShifts = weekendGroups[saturdayDate] || [];
                        const sundayShifts = weekendGroups[sundayDate] || [];
                        
                        weekendPairs.push({
                          weekend: new Date(saturdayDate),
                          saturday: saturdayShifts,
                          sunday: sundayShifts
                        });
                      }
                    }
                    
                    // Show next 8 weekends
                    return weekendPairs.slice(0, 8).map((weekend, index) => (
                      <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="p-3">
                          <div className="font-medium">
                            {weekend.weekend.toLocaleDateString('en-GB', { 
                              day: 'numeric', 
                              month: 'short',
                              year: 'numeric'
                            })}
                          </div>
                          <div className="text-sm text-gray-500">
                            Weekend {index + 1}
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="space-y-1">
                            {weekend.saturday.map((shift: any, idx: number) => {
                              const staffMember = staffMembers.find((s: StaffMember) => s.id === shift.staffMemberId);
                              return (
                                <div 
                                  key={idx} 
                                  className="text-sm font-medium text-blue-700 bg-blue-50 px-2 py-1 rounded cursor-pointer hover:bg-blue-100 transition-colors"
                                  onClick={() => staffMember && handleStaffMemberClick(staffMember)}
                                >
                                  {shift.staffName}
                                </div>
                              );
                            })}
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="space-y-1">
                            {weekend.sunday.map((shift: any, idx: number) => {
                              const staffMember = staffMembers.find((s: StaffMember) => s.id === shift.staffMemberId);
                              return (
                                <div 
                                  key={idx} 
                                  className="text-sm font-medium text-green-700 bg-green-50 px-2 py-1 rounded cursor-pointer hover:bg-green-100 transition-colors"
                                  onClick={() => staffMember && handleStaffMemberClick(staffMember)}
                                >
                                  {shift.staffName}
                                </div>
                              );
                            })}
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="text-sm text-gray-600">
                            {weekend.saturday[0]?.startTime} - {weekend.saturday[0]?.endTime}
                          </div>
                        </td>
                      </tr>
                    ));
                  })()}
                </tbody>
              </table>
              
              {currentRota.filter((shift: any) => new Date(shift.date) >= new Date()).length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No upcoming weekend shifts scheduled
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Individual Staff Calendar Modal */}
      {selectedStaffMember && (
        <StaffCalendar
          staffMember={selectedStaffMember}
          isOpen={isCalendarOpen}
          onClose={handleCloseCalendar}
        />
      )}
    </div>
  );
}