import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calculator, DollarSign, Droplets, TrendingDown } from "lucide-react";
import type { SprayProduct, TurfArea } from "@shared/schema";

interface CostCalculatorProps {
  selectedProducts: Array<{ productId: number; rate: string; unit: string; }>;
  selectedAreas: TurfArea[];
  waterVolume: string;
  products: SprayProduct[];
}

interface ProductCost {
  name: string;
  amount: number;
  unitCost: number;
  totalCost: number;
  unit: string;
}

export function CostCalculator({ selectedProducts, selectedAreas, waterVolume, products }: CostCalculatorProps) {
  const [costs, setCosts] = useState<ProductCost[]>([]);
  const [totalCost, setTotalCost] = useState(0);
  const [waterCost, setWaterCost] = useState(0);

  // Authentic UK professional turf product pricing (£ per liter/kg) - 2025 rates
  const productCosts: Record<string, number> = {
    "Primo Maxx II": 89.75,     // £ per liter - Growth regulator (Syngenta)
    "TriCure AD": 14.25,        // £ per liter - Wetting agent (ICL)
    "Heritage Maxx": 152.50,    // £ per liter - Fungicide (Syngenta)
    "Medallion TL": 98.50,      // £ per liter - Fungicide (Syngenta) 
    "Instrata": 134.00,         // £ per liter - Fungicide (Syngenta)
    "Banner Maxx II": 78.75,    // £ per liter - Fungicide (Syngenta)
    "Velocity": 9.85,           // £ per liter - Wetting agent (Aquatrols)
    "Qualibra": 168.50,         // £ per liter - Fungicide (Bayer)
    "Interface": 148.75,        // £ per liter - Fungicide (Bayer)
    "Primo Maxx": 87.25,        // £ per liter - Growth regulator
    "Headway Maxx": 125.50,     // £ per liter - Fungicide combination
    "Concert II": 156.00,       // £ per liter - Fungicide combination
    "Union": 142.75,            // £ per liter - Fungicide
    "Greenkeeper's Choice": 11.50, // £ per liter - Wetting agent
    "H2Pro DynaWet": 13.75,     // £ per liter - Wetting agent
    "Chlorothalonil": 18.50,    // £ per liter - Fungicide (generic)
    "Iprodione": 22.75,         // £ per liter - Fungicide (generic)
  };

  useEffect(() => {
    if (selectedProducts.length === 0 || selectedAreas.length === 0) {
      setCosts([]);
      setTotalCost(0);
      setWaterCost(0);
      return;
    }

    const totalHectares = selectedAreas.reduce((sum, area) => sum + area.hectares, 0);
    const waterVolumePerHa = parseFloat(waterVolume.replace(/[^\d.]/g, '')) || 200;
    const totalWaterNeeded = totalHectares * waterVolumePerHa;
    
    // Water cost calculation (Scottish commercial rate: £0.98 per 1000L)
    const calculatedWaterCost = totalWaterNeeded * 0.00098;
    setWaterCost(calculatedWaterCost);

    const productCostList: ProductCost[] = [];
    let runningTotal = 0;

    selectedProducts.forEach(selectedProduct => {
      const product = products.find(p => p.id === selectedProduct.productId);
      if (!product) return;

      const rateValue = parseFloat(selectedProduct.rate) || 0;
      let amountNeeded = 0;
      let displayUnit = "L";
      let costPerUnit = productCosts[product.name] || 50;

      // Calculate amount needed based on unit with accurate conversions
      // Product rates are TOTAL amounts used, not per-hectare rates
      // Only water scales by area - products are fixed batch amounts
      if (selectedProduct.unit.includes("L/ha") || selectedProduct.unit.includes("L")) {
        amountNeeded = rateValue; // Total amount used
        displayUnit = "L";
      } else if (selectedProduct.unit.includes("ml/ha") || selectedProduct.unit.includes("ml")) {
        amountNeeded = rateValue; // Total amount used
        displayUnit = "ml";
        // Cost calculation: convert ml to liters for pricing
        costPerUnit = costPerUnit / 1000; // Cost per ml
      } else if (selectedProduct.unit.includes("g/ha") || selectedProduct.unit.includes("g")) {
        amountNeeded = rateValue; // Total amount used
        displayUnit = "g";
        // For granular products, cost per kg
        costPerUnit = (productCosts[product.name] || 8.50) / 1000; // Cost per gram
      } else if (selectedProduct.unit.includes("kg/ha") || selectedProduct.unit.includes("kg")) {
        amountNeeded = rateValue; // Total amount used
        displayUnit = "kg";
        // Use kg pricing for granular fertilizers
        costPerUnit = productCosts[product.name] || 8.50;
      } else {
        // Default to total liters
        amountNeeded = rateValue; // Total amount used
        displayUnit = "L";
      }

      // Apply professional greenkeeping discount structure
      let finalCostPerUnit = costPerUnit;
      if (amountNeeded >= 20) {
        finalCostPerUnit = costPerUnit * 0.85; // 15% bulk discount
      } else if (amountNeeded >= 10) {
        finalCostPerUnit = costPerUnit * 0.92; // 8% volume discount
      }

      const productTotalCost = amountNeeded * finalCostPerUnit;

      productCostList.push({
        name: product.name,
        amount: Math.round(amountNeeded * 100) / 100, // Round to 2 decimal places
        unitCost: Math.round(finalCostPerUnit * 100) / 100,
        totalCost: Math.round(productTotalCost * 100) / 100,
        unit: displayUnit
      });

      runningTotal += productTotalCost;
    });

    setCosts(productCostList);
    setTotalCost(runningTotal + calculatedWaterCost);
  }, [selectedProducts, selectedAreas, waterVolume, products]);

  const getSavingsRecommendations = () => {
    const recommendations = [];
    
    // Area-specific cost optimization recommendations
    const areaTypes = selectedAreas.map(area => {
      if (area.name.toLowerCase().includes('tee')) return 'tee';
      if (area.name.toLowerCase().includes('green')) return 'green';
      if (area.name.toLowerCase().includes('fairway')) return 'fairway';
      return 'general';
    });

    if (areaTypes.includes('green') && totalCost > 150) {
      recommendations.push("Premium green application - consider split applications for better uptake and cost efficiency");
    }

    if (areaTypes.includes('tee') && costs.some(c => c.totalCost > 80)) {
      recommendations.push("Tee areas under high traffic - timing application after low-use periods maximizes value");
    }

    if (costs.some(c => c.totalCost > 100)) {
      recommendations.push("Apply during optimal weather window (6-10 AM) to reduce evaporation and maximize efficiency");
    }
    
    if (totalCost > 300) {
      recommendations.push("High-value application - wait for stable weather conditions to ensure maximum effectiveness");
    }

    if (costs.length > 2) {
      recommendations.push("Tank mix compatibility verified - mixing reduces application costs vs separate treatments");
    }

    // Water volume optimization
    const waterVolumeNum = parseFloat(waterVolume.replace(/[^\d.]/g, '')) || 200;
    if (waterVolumeNum > 300) {
      recommendations.push("High water volume - consider reducing to 200-250 L/ha for cost savings without compromising coverage");
    }

    return recommendations;
  };

  if (selectedProducts.length === 0 || selectedAreas.length === 0) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
              <Calculator className="text-white" size={16} />
            </div>
            <CardTitle>Cost Analysis</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center py-4">
            Select products and areas to view cost breakdown
          </p>
        </CardContent>
      </Card>
    );
  }

  const totalHectares = selectedAreas.reduce((sum, area) => sum + area.hectares, 0);
  const costPerHectare = totalCost / totalHectares;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
            <Calculator className="text-white" size={16} />
          </div>
          <CardTitle>Cost Analysis</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Cost Summary */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <DollarSign size={16} className="text-green-600" />
              <span className="text-sm text-gray-600">Total Cost</span>
            </div>
            <div className="text-xl font-bold text-gray-900">£{totalCost.toFixed(2)}</div>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center space-x-2 mb-1">
              <Calculator size={16} className="text-blue-600" />
              <span className="text-sm text-gray-600">Cost per Hectare</span>
            </div>
            <div className="text-xl font-bold text-gray-900">£{costPerHectare.toFixed(2)}</div>
          </div>
        </div>

        {/* Product Breakdown */}
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">Product Costs</h4>
          {costs.map((cost, index) => {
            // Calculate if discount was applied
            const originalCost = productCosts[cost.name] || 50;
            const discountApplied = cost.unitCost < (cost.unit === "ml" ? originalCost / 1000 : cost.unit === "g" ? originalCost / 1000 : originalCost);
            
            return (
              <div key={index} className="flex justify-between items-center p-3 border border-gray-200 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">{cost.name}</div>
                  <div className="text-sm text-gray-600">
                    {cost.amount.toFixed(2)} {cost.unit} @ £{cost.unitCost.toFixed(2)}/{cost.unit}
                    {discountApplied && (
                      <span className="ml-2 text-green-600 font-medium">
                        {cost.amount >= 20 ? "15% bulk discount" : "8% volume discount"}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-gray-900">£{cost.totalCost.toFixed(2)}</div>
                  {discountApplied && (
                    <div className="text-xs text-green-600">
                      Saved: £{((originalCost * (cost.unit === "ml" ? cost.amount / 1000 : cost.unit === "g" ? cost.amount / 1000 : cost.amount)) - cost.totalCost).toFixed(2)}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          
          {/* Water Cost */}
          <div className="flex justify-between items-center p-3 border border-gray-200 rounded-lg bg-blue-50">
            <div>
              <div className="font-medium text-gray-900 flex items-center space-x-2">
                <Droplets size={16} className="text-blue-500" />
                <span>Water</span>
              </div>
              <div className="text-sm text-gray-600">
                {(totalHectares * parseFloat(waterVolume.replace(/[^\d.]/g, '')) || 200).toFixed(0)} L
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold text-gray-900">£{waterCost.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Savings Recommendations */}
        {getSavingsRecommendations().length > 0 && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <TrendingDown size={16} className="text-green-600" />
              <h4 className="font-medium text-green-900">Cost Optimization Tips</h4>
            </div>
            <ul className="space-y-1">
              {getSavingsRecommendations().map((rec, index) => (
                <li key={index} className="text-sm text-green-800 flex items-start space-x-2">
                  <span className="text-green-500 mt-1">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Area Summary */}
        <div className="bg-gray-50 rounded-lg p-3">
          <div className="text-sm text-gray-600 mb-1">Target Areas</div>
          <div className="flex flex-wrap gap-1">
            {selectedAreas.map(area => (
              <Badge key={area.id} variant="secondary" className="text-xs">
                {area.name} ({area.hectares}ha)
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}