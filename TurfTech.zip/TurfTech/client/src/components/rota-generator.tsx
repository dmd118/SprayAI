import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Users, AlertCircle, CheckCircle2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SavedRota {
  id: number;
  name: string;
  startDate: string;
  endDate: string;
  status: string;
  notes?: string;
  generatedAt: string;
}

interface RotaShift {
  id: number;
  rotaId: number;
  staffId: number;
  staffName: string;
  date: string;
  dayOfWeek: string;
  shiftType: string;
  startTime: string | null;
  endTime: string | null;
  hoursWorked: number;
  isHoliday: boolean;
  isMonday: boolean;
  notes?: string;
}

export default function RotaGenerator() {
  const { toast } = useToast();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [rotaName, setRotaName] = useState("");
  const [notes, setNotes] = useState("");
  const [selectedRotaId, setSelectedRotaId] = useState<number | null>(null);

  // Fetch saved rotas
  const { data: savedRotas, isLoading: rotasLoading } = useQuery({
    queryKey: ['/api/saved-rotas'],
    queryFn: () => apiRequest('/api/saved-rotas').then(res => res.json())
  });

  // Fetch shifts for selected rota
  const { data: shifts, isLoading: shiftsLoading } = useQuery({
    queryKey: ['/api/rota-shifts', selectedRotaId],
    queryFn: () => selectedRotaId ? apiRequest(`/api/rota-shifts/${selectedRotaId}`).then(res => res.json()) : [],
    enabled: !!selectedRotaId
  });

  // Generate rota mutation
  const generateMutation = useMutation({
    mutationFn: (data: any) => 
      fetch('/api/generate-rota', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { 'Content-Type': 'application/json' }
      }).then(res => res.json()),
    onSuccess: (result) => {
      toast({
        title: "Rota Generated Successfully",
        description: `Created rota "${rotaName}" with ${result.shifts?.length || 0} shifts`,
      });
      setSelectedRotaId(result.rotaId);
      queryClient.invalidateQueries({ queryKey: ['/api/saved-rotas'] });
      queryClient.invalidateQueries({ queryKey: ['/api/rota-shifts'] });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate rota. Please check your inputs.",
        variant: "destructive",
      });
    }
  });

  // Delete rota mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/saved-rotas/${id}`, {
        method: 'DELETE'
      }).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "Rota Deleted",
        description: "Rota has been removed successfully",
      });
      setSelectedRotaId(null);
      queryClient.invalidateQueries({ queryKey: ['/api/saved-rotas'] });
    }
  });

  const handleGenerate = () => {
    if (!startDate || !endDate || !rotaName) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate({
      startDate,
      endDate,
      rotaName,
      notes
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  const getShiftTypeColor = (shiftType: string) => {
    switch (shiftType) {
      case 'weekend': return 'bg-blue-100 text-blue-800';
      case 'weekday': return 'bg-green-100 text-green-800';
      case 'holiday': return 'bg-purple-100 text-purple-800';
      case 'monday_off': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const groupShiftsByDate = (shifts: RotaShift[]) => {
    if (!shifts) return {};
    
    return shifts.reduce((groups: any, shift) => {
      const date = shift.date.split('T')[0];
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(shift);
      return groups;
    }, {});
  };

  const groupedShifts = groupShiftsByDate(shifts);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Staff Rota Generator</h1>
          <p className="text-gray-600 mt-1">Generate intelligent staff rotas following Scottish employment rules</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Generation Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Generate New Rota
            </CardTitle>
            <CardDescription>
              Create a new staff rota with automatic scheduling following your business rules
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="endDate">End Date</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="rotaName">Rota Name</Label>
              <Input
                id="rotaName"
                placeholder="e.g., June 2025 Rota"
                value={rotaName}
                onChange={(e) => setRotaName(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes about this rota..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
              />
            </div>

            <Button 
              onClick={handleGenerate}
              disabled={generateMutation.isPending}
              className="w-full"
            >
              {generateMutation.isPending ? "Generating..." : "Generate Rota"}
            </Button>

            <div className="text-sm text-gray-600 space-y-1">
              <p className="font-medium">Scheduling Rules Applied:</p>
              <ul className="text-xs space-y-1 ml-4">
                <li>• Summer: 4 staff (2F + 2S), Winter: 2F only</li>
                <li>• Weekend hours: 05:00-09:00 (4 hours)</li>
                <li>• Monday offs after weekend work</li>
                <li>• Seasonal staff finish 09:30 Fridays</li>
                <li>• Holiday booking integration</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Saved Rotas */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Saved Rotas
            </CardTitle>
            <CardDescription>
              View and manage previously generated rotas
            </CardDescription>
          </CardHeader>
          <CardContent>
            {rotasLoading ? (
              <div className="text-center py-4">Loading rotas...</div>
            ) : savedRotas?.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No saved rotas yet</p>
                <p className="text-sm">Generate your first rota above</p>
              </div>
            ) : (
              <div className="space-y-3">
                {savedRotas?.map((rota: SavedRota) => (
                  <div
                    key={rota.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedRotaId === rota.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedRotaId(rota.id)}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-medium">{rota.name}</h3>
                        <p className="text-sm text-gray-600">
                          {formatDate(rota.startDate)} - {formatDate(rota.endDate)}
                        </p>
                        {rota.notes && (
                          <p className="text-xs text-gray-500 mt-1">{rota.notes}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={rota.status === 'active' ? 'default' : 'secondary'}>
                          {rota.status}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteMutation.mutate(rota.id);
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Rota Details */}
      {selectedRotaId && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Rota Schedule
            </CardTitle>
            <CardDescription>
              Detailed view of shifts for the selected rota
            </CardDescription>
          </CardHeader>
          <CardContent>
            {shiftsLoading ? (
              <div className="text-center py-4">Loading schedule...</div>
            ) : Object.keys(groupedShifts).length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No shifts found for this rota</p>
              </div>
            ) : (
              <div className="space-y-4">
                {Object.entries(groupedShifts)
                  .sort(([a], [b]) => a.localeCompare(b))
                  .map(([date, shifts]: [string, any]) => (
                    <div key={date} className="border rounded-lg p-4">
                      <div className="flex justify-between items-center mb-3">
                        <h3 className="font-medium">
                          {new Date(date).toLocaleDateString('en-GB', { 
                            weekday: 'long', 
                            day: 'numeric', 
                            month: 'long' 
                          })}
                        </h3>
                        <Badge variant="outline">
                          {shifts.length} {shifts.length === 1 ? 'shift' : 'shifts'}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {shifts.map((shift: RotaShift) => (
                          <div key={shift.id} className="border rounded p-3 bg-gray-50">
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium">{shift.staffName}</span>
                              <Badge className={getShiftTypeColor(shift.shiftType)} variant="secondary">
                                {shift.shiftType}
                              </Badge>
                            </div>
                            
                            {shift.startTime && shift.endTime ? (
                              <div className="text-sm text-gray-600">
                                <p>{shift.startTime} - {shift.endTime}</p>
                                <p>{shift.hoursWorked}h</p>
                              </div>
                            ) : (
                              <div className="text-sm text-gray-500">
                                {shift.isMonday ? 'Day Off' : 'No hours'}
                              </div>
                            )}
                            
                            {shift.notes && (
                              <p className="text-xs text-gray-500 mt-2">{shift.notes}</p>
                            )}
                            
                            {shift.isHoliday && (
                              <div className="flex items-center gap-1 mt-2">
                                <CheckCircle2 className="w-3 h-3 text-purple-600" />
                                <span className="text-xs text-purple-600">Bank Holiday</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}