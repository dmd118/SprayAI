import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator, Trash2, AlertTriangle, CheckCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { SprayProduct, TurfArea } from "@shared/schema";

interface SelectedProduct {
  id: string;
  product: SprayProduct;
  recommendedRate: number; // ml per L
  calculatedAmount: number; // amount per tank
  totalAmount?: number; // total amount for entire job
  unit?: string; // L or kg
}

interface CompatibilityWarning {
  severity: "high" | "medium" | "low";
  message: string;
  considerations: string[];
}

interface CalculationValidation {
  isValid: boolean;
  severity: "error" | "warning" | "caution";
  message: string;
  corrections: string[];
  aiSummary: string;
}

interface CalculationResult {
  tankSize: number;
  waterVolume: number;
  totalArea: number;
  products: SelectedProduct[];
  applicationRate: number; // L per hectare
  compatibilityWarnings: CompatibilityWarning[];
  calculationValidation: CalculationValidation | null;
  tanksNeeded: number;
  totalWaterNeeded: number;
  totalJobSummary: {
    productName: string;
    totalAmount: number;
    perTankAmount: number;
    unit: string;
  }[];
  operationalConstraints?: {
    recommendedNozzleType: string;
    tractorSpeedKmh: number;
    sprayWidthMeters: number;
    maxNozzleCapacityLHa: number;
    applicationRateFeasible: boolean;
    nozzleCapacityWarning?: string;
    effectiveApplicationRate: number;
    sprayTimePerTankMinutes: number;
    totalSprayTimeMinutes: number;
  };
  costAnalysis?: {
    totalProductCost: number;
    waterCost: number;
    totalJobCost: number;
    costPerHa: number;
  };
  costOptimization?: {
    warning: string;
    suggestions: string[];
  };
}

export function TankMixCalculator() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState<SelectedProduct[]>([]);
  const [tankSize, setTankSize] = useState<number>(1000);
  const [customTankSize, setCustomTankSize] = useState<string>("");
  const [selectedTurfArea, setSelectedTurfArea] = useState<string>("");
  const [calculation, setCalculation] = useState<CalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  const [manualTankCount, setManualTankCount] = useState<number | null>(null);
  const [tractorSpeed, setTractorSpeed] = useState<number>(7); // Default 7 km/h
  const [nozzleType, setNozzleType] = useState<string>("white"); // Default white nozzles

  const { data: sprayProducts = [] } = useQuery<SprayProduct[]>({
    queryKey: ["/api/spray-products"],
  });

  const { data: turfAreas = [] } = useQuery<TurfArea[]>({
    queryKey: ["/api/turf-areas"],
  });

  // AI-powered compatibility analysis
  const analyzeCompatibility = async (products: SelectedProduct[]): Promise<CompatibilityWarning[]> => {
    if (products.length < 2) return [];

    try {
      const productDetails = products.map(p => ({
        name: p.product.name,
        type: p.product.type,
        activeIngredient: p.product.activeIngredient,
        labelRate: p.product.labelRate
      }));

      const response = await fetch('/api/analyze-compatibility', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ products: productDetails })
      });

      if (response.ok) {
        const analysis = await response.json();
        return analysis.warnings || [];
      }
    } catch (error) {
      console.error('Compatibility analysis failed:', error);
    }

    return [];
  };

  // AI-powered calculation validation
  const validateCalculations = async (calculation: Omit<CalculationResult, 'calculationValidation'>): Promise<CalculationValidation | null> => {
    try {
      const calculationData = {
        tankSize: calculation.tankSize,
        waterVolume: calculation.waterVolume,
        totalArea: calculation.totalArea,
        applicationRate: calculation.applicationRate,
        products: calculation.products.map(p => ({
          name: p.product.name,
          type: p.product.type,
          rate: p.recommendedRate,
          amount: p.calculatedAmount,
          activeIngredient: p.product.activeIngredient
        }))
      };

      const response = await fetch('/api/validate-calculations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ calculation: calculationData })
      });

      if (response.ok) {
        const validation = await response.json();
        return validation;
      }
    } catch (error) {
      console.error('Calculation validation failed:', error);
    }

    return null;
  };

  // AI-powered calculation logic
  const calculateMixture = async () => {
    if (selectedProducts.length === 0 || !selectedTurfArea) return;

    setIsCalculating(true);
    setManualTankCount(null); // Reset manual override for fresh calculations
    
    const area = turfAreas.find(a => a.id.toString() === selectedTurfArea);
    if (!area) {
      setIsCalculating(false);
      return;
    }

    const areaInHectares = area.hectares;
    const actualTankSize = tankSize === 0 ? parseFloat(customTankSize) || 1000 : tankSize;

    // Real greenkeeper water rates (L/ha) based on application type
    let waterRatePerHa = 300; // Standard fairway rate
    
    // Adjust water rate based on product types and area type
    const hasIron = selectedProducts.some(p => 
      p.product.name?.toLowerCase().includes('elevate') || 
      p.product.name?.toLowerCase().includes('iron')
    );
    const hasGrowthRegulator = selectedProducts.some(p => 
      p.product.type?.toLowerCase().includes('growth') || 
      p.product.name?.toLowerCase().includes('primo')
    );
    
    // Match real greenkeeper practice
    if (area.type?.toLowerCase().includes('green')) {
      waterRatePerHa = 500; // Higher water for greens
    } else if (area.type?.toLowerCase().includes('fairway')) {
      waterRatePerHa = 300; // Standard fairway rate
    } else if (area.type?.toLowerCase().includes('tee')) {
      waterRatePerHa = 400; // Medium rate for tees
    }

    // Calculate total job requirements (greenkeeper method)
    const totalWaterNeeded = areaInHectares * waterRatePerHa;
    const tanksNeeded = Math.ceil(totalWaterNeeded / actualTankSize);
    const waterPerTank = Math.min(totalWaterNeeded / tanksNeeded, actualTankSize);

    // Real per-hectare product rates (field-tested)
    const updatedProducts = selectedProducts.map(selected => {
      let ratePerHa = 0;
      let unit = 'L';

      // Real greenkeeper rates per hectare
      if (selected.product.name?.toLowerCase().includes('primo')) {
        ratePerHa = 1.5; // L/ha - standard PGR rate
        unit = 'L';
      } else if (selected.product.name?.toLowerCase().includes('elevate') || selected.product.name?.toLowerCase().includes('iron')) {
        ratePerHa = 20; // L/ha - iron supplement
        unit = 'L';
      } else if (selected.product.name?.toLowerCase().includes('urea')) {
        ratePerHa = 10; // kg/ha - nitrogen boost
        unit = 'kg';
      } else if (selected.product.name?.toLowerCase().includes('ammonium')) {
        ratePerHa = 10; // kg/ha - AMS adjuvant
        unit = 'kg';
      } else if (selected.product.type?.toLowerCase().includes('fungicide')) {
        ratePerHa = 0.5; // L/ha for liquid fungicides
        unit = 'L';
      } else {
        // Extract rate from label
        const rateMatch = selected.product.labelRate?.match(/(\d+(?:\.\d+)?)/);
        ratePerHa = rateMatch ? parseFloat(rateMatch[1]) : 1.0;
        unit = selected.product.labelRate?.includes('kg') ? 'kg' : 'L';
      }

      // Total product needed for entire job
      const totalProductNeeded = ratePerHa * areaInHectares;
      // Product per tank
      const productPerTank = totalProductNeeded / tanksNeeded;
      // Rate per liter for display
      const ratePerLiter = productPerTank / waterPerTank;

      return {
        ...selected,
        recommendedRate: ratePerLiter,
        calculatedAmount: productPerTank,
        totalAmount: totalProductNeeded,
        unit
      };
    });

    // Create job summary
    const totalJobSummary = updatedProducts.map(p => ({
      productName: p.product.name,
      totalAmount: p.totalAmount,
      perTankAmount: p.calculatedAmount,
      unit: p.unit
    }));

    // Analyze compatibility warnings
    const compatibilityWarnings = await analyzeCompatibility(selectedProducts);

    // Use backend calculation with user-selected parameters
    try {
      const response = await fetch("/api/calculate-tank-mix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          area: { hectares: areaInHectares, type: area.type },
          tankSize: actualTankSize,
          tractorSpeed,
          nozzleType,
          products: selectedProducts.map(p => ({
            name: p.product.name,
            type: p.product.type
          }))
        })
      });

      if (response.ok) {
        const result = await response.json();
        
        // Add AI analysis components
        const compatibilityWarnings = await analyzeCompatibility(selectedProducts);
        const calculationValidation = await validateCalculations(result);
        
        const enhancedResult = {
          ...result,
          compatibilityWarnings,
          calculationValidation,
          products: selectedProducts.map((p, index) => {
            const jobSummary = result.totalJobSummary[index];
            const waterPerTank = result.waterVolume;
            
            const amountPerTank = jobSummary?.perTankAmount || 0;
            // Convert L to ml, then divide by water volume in L to get ml/L
            const rateInMlPerL = waterPerTank > 0 ? (amountPerTank * 1000) / waterPerTank : 0;
            
            return {
              ...p,
              calculatedAmount: amountPerTank,
              totalAmount: jobSummary?.totalAmount || 0,
              recommendedRate: Math.round(rateInMlPerL * 10) / 10, // Round to 1 decimal place
              unit: jobSummary?.unit || 'L'
            };
          })
        };
        
        setCalculation(enhancedResult);
        setSelectedProducts(enhancedResult.products);
      }
    } catch (error) {
      console.error("Calculation failed:", error);
    }

    setSelectedProducts(updatedProducts);
    setIsCalculating(false);
  };

  // Manual calculation only - no automatic recalculation to prevent product removal

  const addProduct = (productId: string) => {
    if (!productId) return;
    
    const product = sprayProducts.find(p => p.id.toString() === productId);
    if (!product) return;

    const newSelection: SelectedProduct = {
      id: Date.now().toString(),
      product,
      recommendedRate: 0,
      calculatedAmount: 0
    };

    setSelectedProducts([...selectedProducts, newSelection]);
  };

  const removeProduct = (id: string) => {
    setSelectedProducts(selectedProducts.filter(p => p.id !== id));
  };

  const saveApplicationRecord = async () => {
    if (!calculation || !selectedTurfArea) return;

    const area = turfAreas.find(a => a.id.toString() === selectedTurfArea);
    if (!area) return;

    try {
      const now = new Date();
      const day = String(now.getDate()).padStart(2, '0');
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const year = now.getFullYear();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      
      // Format: "30/05/2025 07:00-10:00am"
      const dateTimeStr = `${day}/${month}/${year} ${hours}:${minutes}-${hours}:${minutes}am`;

      const productNames = selectedProducts.map(p => p.product.name).join(', ');
      
      const productDetails = JSON.stringify({
        products: selectedProducts.map(p => ({
          name: p.product.name,
          type: p.product.type,
          activeIngredient: p.product.activeIngredient,
          amount: p.calculatedAmount,
          unit: p.unit,
          totalAmount: p.totalAmount
        })),
        tankMixSummary: {
          waterPerTank: calculation.waterVolume,
          tanksUsed: calculation.tanksNeeded,
          totalWater: calculation.totalWaterNeeded,
          applicationRate: calculation.applicationRate,
          tractorSpeed: tractorSpeed,
          nozzleType: nozzleType
        },
        costSummary: calculation.costAnalysis || null
      });

      const response = await fetch("/api/application-records", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date: dateTimeStr,
          type: "Spray",
          products: productNames,
          productDetails: productDetails,
          areaId: parseInt(selectedTurfArea),
          areaName: area.name,
          rate: `${calculation.applicationRate}L/ha`,
          weather: "Recorded from system",
          waterVolume: `${calculation.waterVolume}L per tank, ${calculation.tanksNeeded} tanks`,
          notes: `Tank mix calculation: ${calculation.tanksNeeded} tanks @ ${calculation.waterVolume}L each. Speed: ${tractorSpeed}km/h, Nozzles: ${nozzleType}`
        })
      });

      if (response.ok) {
        console.log("Application record saved successfully");
        // Show success message
        alert("Save successful! Redirecting to Application Records...");
        // Close the dialog and redirect to Application Records
        setIsOpen(false);
        // Brief delay before redirect to show the message
        setTimeout(() => {
          window.location.href = '/';
        }, 1000);
      } else {
        const errorData = await response.json();
        console.error("Failed to save application record:", errorData);
      }
    } catch (error) {
      console.error("Error saving application record:", error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="bg-green-600 hover:bg-green-700 text-white border-green-600 hover:border-green-700"
        >
          <Calculator className="w-4 h-4 mr-2" />
          Calc
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Tank Mix Calculator</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Input Controls */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label>Tank Size</Label>
              <Select value={tankSize.toString()} onValueChange={(v) => setTankSize(parseInt(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1000">1000L (Standard)</SelectItem>
                  <SelectItem value="0">Custom Size</SelectItem>
                </SelectContent>
              </Select>
              {tankSize === 0 && (
                <Input
                  type="number"
                  placeholder="Enter custom tank size (L)"
                  value={customTankSize}
                  onChange={(e) => setCustomTankSize(e.target.value)}
                />
              )}
            </div>

            <div className="space-y-2">
              <Label>Turf Area</Label>
              <Select value={selectedTurfArea} onValueChange={setSelectedTurfArea}>
                <SelectTrigger>
                  <SelectValue placeholder="Select area to spray" />
                </SelectTrigger>
                <SelectContent>
                  {turfAreas.map((area) => (
                    <SelectItem key={area.id} value={area.id.toString()}>
                      {area.name} ({area.hectares} ha)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Speed</Label>
              <Select value={tractorSpeed.toString()} onValueChange={(v) => setTractorSpeed(parseFloat(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 km/h (Standard)</SelectItem>
                  <SelectItem value="5">5 km/h (Slow)</SelectItem>
                  <SelectItem value="6">6 km/h</SelectItem>
                  <SelectItem value="8">8 km/h</SelectItem>
                  <SelectItem value="9">9 km/h (Fast)</SelectItem>
                  <SelectItem value="10">10 km/h (Custom)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Nozzles</Label>
              <Select value={nozzleType} onValueChange={setNozzleType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="white">White (Standard)</SelectItem>
                  <SelectItem value="red">Red (Fine)</SelectItem>
                  <SelectItem value="yellow">Yellow (Medium)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Add Product</Label>
              <div className="flex gap-2">
                <Select onValueChange={addProduct} value="">
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select spray product" />
                  </SelectTrigger>
                  <SelectContent>
                    {sprayProducts.map((product) => (
                      <SelectItem key={product.id} value={product.id.toString()}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  onClick={calculateMixture}
                  disabled={selectedProducts.length === 0 || !selectedTurfArea || isCalculating}
                  className="bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50"
                >
                  {isCalculating ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Calculating...
                    </div>
                  ) : (
                    "Calculate"
                  )}
                </Button>
              </div>
            </div>
          </div>

          {/* Selected Products Table */}
          {selectedProducts.length > 0 && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Selected Products</CardTitle>
                {calculation && (
                  <Button
                    onClick={saveApplicationRecord}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    Save
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-slate-300">
                    <thead>
                      <tr className="bg-slate-50">
                        <th className="border border-slate-300 p-3 text-left">Product</th>
                        <th className="border border-slate-300 p-3 text-center">Type</th>
                        <th className="border border-slate-300 p-3 text-center">Amount Needed</th>
                        <th className="border border-slate-300 p-3 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedProducts.map((selected) => (
                        <tr key={selected.id}>
                          <td className="border border-slate-300 p-3 font-medium">
                            {selected.product.name}
                          </td>
                          <td className="border border-slate-300 p-3 text-center">
                            {selected.product.type}
                          </td>
                          <td className="border border-slate-300 p-3 text-center font-mono text-green-600 font-bold">
                            {selected.calculatedAmount.toFixed(1)} {selected.unit}
                          </td>
                          <td className="border border-slate-300 p-3 text-center">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeProduct(selected.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Calculation Results */}
          {calculation && (
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800">Tank Mix Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {calculation.waterVolume.toFixed(0)}L
                    </div>
                    <div className="text-sm text-slate-600">Water Per Tank</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {calculation.totalArea.toFixed(2)} ha
                    </div>
                    <div className="text-sm text-slate-600">Total Area</div>
                  </div>
                  <div className="text-center">
                    <Select
                      value={manualTankCount?.toString() || calculation.tanksNeeded.toString()}
                      onValueChange={async (value) => {
                        const newCount = parseFloat(value);
                        setManualTankCount(newCount);
                        
                        // Recalculate entire tank mix with new count
                        if (calculation && selectedTurfArea) {
                          setIsCalculating(true);
                          
                          try {
                            const response = await fetch("/api/calculate-tank-mix", {
                              method: "POST",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({
                                area: {
                                  hectares: calculation.totalArea,
                                  type: selectedTurfArea
                                },
                                tankSize: tankSize,
                                products: selectedProducts.map(p => ({
                                  name: p.product.name,
                                  type: p.product.type
                                })),
                                manualTankCount: newCount // Override calculation
                              })
                            });

                            if (response.ok) {
                              const result = await response.json();
                              
                              // Add missing AI analysis components for manual tank overrides
                              const compatibilityWarnings = await analyzeCompatibility(selectedProducts);
                              const calculationValidation = await validateCalculations(result);
                              
                              const enhancedResult = {
                                ...result,
                                compatibilityWarnings,
                                calculationValidation,
                                products: selectedProducts.map((p, index) => {
                                  const jobSummary = result.totalJobSummary[index];
                                  const waterPerTank = result.waterVolume;
                                  
                                  const amountPerTank = jobSummary?.perTankAmount || 0;
                                  // Convert L to ml, then divide by water volume in L to get ml/L
                                  const rateInMlPerL = waterPerTank > 0 ? (amountPerTank * 1000) / waterPerTank : 0;
                                  
                                  return {
                                    ...p,
                                    calculatedAmount: amountPerTank,
                                    totalAmount: jobSummary?.totalAmount || 0,
                                    recommendedRate: Math.round(rateInMlPerL * 10) / 10, // Round to 1 decimal place
                                    unit: jobSummary?.unit || 'L'
                                  };
                                }),
                                // Ensure cost analysis is preserved from backend
                                costAnalysis: result.costAnalysis,
                                costOptimization: result.costOptimization
                              };
                              
                              setCalculation(enhancedResult);
                            }
                          } catch (error) {
                            console.error("Error recalculating:", error);
                          } finally {
                            setIsCalculating(false);
                          }
                        }
                      }}
                    >
                      <SelectTrigger className="w-20 h-12 border-2 border-purple-300">
                        <SelectValue>
                          <div className="text-2xl font-bold text-purple-600">
                            {manualTankCount || calculation.tanksNeeded}
                          </div>
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="1.5">1.5</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="2.5">2.5</SelectItem>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="3.5">3.5</SelectItem>
                        <SelectItem value="4">4</SelectItem>
                        <SelectItem value="4.5">4.5</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                        <SelectItem value="6">6</SelectItem>
                        <SelectItem value="7">7</SelectItem>
                        <SelectItem value="8">8</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="text-sm text-slate-600 mt-1">Tanks (Click to adjust)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {calculation.applicationRate}L/ha
                    </div>
                    <div className="text-sm text-slate-600">Water Rate</div>
                  </div>
                </div>

                {/* Total Job Summary */}
                {calculation.totalJobSummary && calculation.totalJobSummary.length > 0 && (
                  <div className="mt-4 p-4 bg-blue-50 rounded border border-blue-200">
                    <h4 className="font-semibold text-blue-800 mb-3">Total Job Requirements</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm font-medium text-blue-700 mb-2">Products Needed (Total):</div>
                        {calculation.totalJobSummary.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span>{item.productName}:</span>
                            <span className="font-mono font-semibold">
                              {item.totalAmount.toFixed(1)} {item.unit}
                            </span>
                          </div>
                        ))}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-blue-700 mb-2">Per Tank Mix:</div>
                        {calculation.totalJobSummary.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span>{item.productName}:</span>
                            <span className="font-mono font-semibold">
                              {item.perTankAmount.toFixed(1)} {item.unit}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Operational Constraints Display */}
                {calculation.operationalConstraints && (
                  <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-3">Spray Equipment Settings</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      <div>
                        <span className="font-medium text-blue-700">Nozzle Type:</span>
                        <div className="text-blue-600 capitalize font-semibold">{calculation.operationalConstraints.recommendedNozzleType}</div>
                      </div>
                      <div>
                        <span className="font-medium text-blue-700">Spray Width:</span>
                        <div className="text-blue-600 font-semibold">{calculation.operationalConstraints.sprayWidthMeters}m</div>
                      </div>
                      <div>
                        <span className="font-medium text-blue-700">Max Capacity:</span>
                        <div className="text-blue-600 font-semibold">{calculation.operationalConstraints.maxNozzleCapacityLHa}L/ha</div>
                      </div>
                      <div>
                        <span className="font-medium text-blue-700">Total Time:</span>
                        <div className="text-blue-600 font-semibold">{Math.round(calculation.operationalConstraints.totalSprayTimeMinutes)}min</div>
                      </div>
                    </div>
                    
                    {calculation.operationalConstraints.nozzleCapacityWarning && (
                      <div className="mt-3 p-3 bg-orange-100 border border-orange-300 rounded text-orange-800 text-sm">
                        <div className="flex items-start gap-2">
                          <span className="font-semibold text-orange-900">⚠️ Equipment Warning:</span>
                          <span>{calculation.operationalConstraints.nozzleCapacityWarning}</span>
                        </div>
                      </div>
                    )}

                    {calculation.operationalConstraints.applicationRateFeasible === false && (
                      <div className="mt-2 p-3 bg-red-100 border border-red-300 rounded text-red-800 text-sm">
                        <div className="flex items-start gap-2">
                          <span className="font-semibold text-red-900">🚫 Rate Exceeded:</span>
                          <span>Application rate reduced to {calculation.operationalConstraints.effectiveApplicationRate}L/ha (nozzle limit reached)</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Cost Analysis Display */}
                {calculation.costAnalysis && (
                  <div className="mt-4 p-4 bg-green-50 rounded border border-green-200">
                    <h4 className="font-semibold text-green-800 mb-3">Cost Analysis</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="font-medium text-green-700 mb-1">Job Costs:</div>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span>Products:</span>
                            <span className="font-mono">£{calculation.costAnalysis.totalProductCost}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Water:</span>
                            <span className="font-mono">£{calculation.costAnalysis.waterCost}</span>
                          </div>
                          <div className="flex justify-between font-semibold border-t pt-1">
                            <span>Total:</span>
                            <span className="font-mono">£{calculation.costAnalysis.totalJobCost}</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <div className="font-medium text-green-700 mb-1">Per Hectare:</div>
                        <div className="text-lg font-bold text-green-800">
                          £{calculation.costAnalysis.costPerHa}/ha
                        </div>
                        <div className="text-xs text-green-600">
                          {calculation.costAnalysis.costPerHa > 150 ? 'High cost application' : 'Standard cost range'}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Cost Optimization Warnings */}
                {calculation.costOptimization && (
                  <div className="mt-4 p-4 bg-amber-50 rounded border border-amber-200">
                    <h4 className="font-semibold text-amber-800 mb-2">Cost Optimization</h4>
                    <div className="text-amber-700 font-medium mb-2">{calculation.costOptimization.warning}</div>
                    <ul className="text-sm text-amber-600 space-y-1">
                      {calculation.costOptimization.suggestions.map((suggestion, index) => (
                        <li key={index} className="flex items-start">
                          <span className="mr-2">•</span>
                          <span>{suggestion}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="mt-4 p-3 bg-white rounded border">
                  <h4 className="font-semibold text-slate-800 mb-2">Greenkeeper Method Instructions:</h4>
                  <ol className="list-decimal list-inside text-sm text-slate-600 space-y-1">
                    <li>Total water needed: {calculation.totalWaterNeeded}L for {calculation.totalArea} ha</li>
                    <li>Fill each tank with {calculation.waterVolume.toFixed(0)}L of clean water</li>
                    {calculation.totalJobSummary.map((item, index) => (
                      <li key={index}>
                        Add {item.perTankAmount < 0.1 && item.unit === 'L' ? 
                          `${Math.round(item.perTankAmount * 1000)} mL` : 
                          `${item.perTankAmount.toFixed(1)} ${item.unit}`} of {item.productName} per tank
                      </li>
                    ))}
                    <li>Repeat for {calculation.tanksNeeded} tank{calculation.tanksNeeded > 1 ? 's' : ''} to complete application</li>
                    <li>Apply immediately after mixing each tank</li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Compatibility Warnings with Safety Color Coding */}
          {calculation && calculation.compatibilityWarnings && calculation.compatibilityWarnings.length > 0 && (
            <div className="space-y-3">
              {calculation.compatibilityWarnings.map((warning, index) => (
                <Card key={index} className={`border-2 ${
                  warning.severity === 'high' ? 'border-red-400 bg-red-50' :
                  warning.severity === 'medium' ? 'border-orange-400 bg-orange-50' :
                  'border-yellow-400 bg-yellow-50'
                }`}>
                  <CardHeader className="pb-3">
                    <CardTitle className={`flex items-center gap-2 text-lg ${
                      warning.severity === 'high' ? 'text-red-800' :
                      warning.severity === 'medium' ? 'text-orange-800' :
                      'text-yellow-800'
                    }`}>
                      <AlertTriangle className={`w-6 h-6 ${
                        warning.severity === 'high' ? 'text-red-600' :
                        warning.severity === 'medium' ? 'text-orange-600' :
                        'text-yellow-600'
                      }`} />
                      {warning.severity === 'high' ? 'DANGER - WILL KILL GRASS' :
                       warning.severity === 'medium' ? 'CAUTION - Important Considerations' :
                       'ADVISORY - Good Practice Notes'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className={`p-3 rounded-lg border-l-4 ${
                        warning.severity === 'high' ? 'border-l-red-600 bg-red-100' :
                        warning.severity === 'medium' ? 'border-l-orange-600 bg-orange-100' :
                        'border-l-yellow-600 bg-yellow-100'
                      }`}>
                        <div className={`font-semibold text-sm ${
                          warning.severity === 'high' ? 'text-red-900' :
                          warning.severity === 'medium' ? 'text-orange-900' :
                          'text-yellow-900'
                        }`}>
                          {warning.message}
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded border">
                        <div className="text-sm font-semibold text-slate-700 mb-2">Expert Greenkeeping Advice:</div>
                        <ul className="space-y-1.5">
                          {warning.considerations.map((consideration, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                              <span className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                                warning.severity === 'high' ? 'bg-red-500' :
                                warning.severity === 'medium' ? 'bg-orange-500' :
                                'bg-yellow-500'
                              }`}></span>
                              {consideration}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Calculation Validation */}
          {calculation && calculation.calculationValidation && (
            <Card className={`border-2 ${
              calculation.calculationValidation.severity === 'error' ? 'border-red-300 bg-red-50' :
              calculation.calculationValidation.severity === 'warning' ? 'border-orange-300 bg-orange-50' :
              'border-yellow-300 bg-yellow-50'
            }`}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-2 ${
                  calculation.calculationValidation.severity === 'error' ? 'text-red-800' :
                  calculation.calculationValidation.severity === 'warning' ? 'text-orange-800' :
                  'text-yellow-800'
                }`}>
                  <AlertTriangle className="w-5 h-5" />
                  AI Calculation Validation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className={`font-semibold ${
                    calculation.calculationValidation.severity === 'error' ? 'text-red-800' :
                    calculation.calculationValidation.severity === 'warning' ? 'text-orange-800' :
                    'text-yellow-800'
                  }`}>
                    {calculation.calculationValidation.severity.toUpperCase()}: {calculation.calculationValidation.message}
                  </div>
                  
                  <div className="bg-white p-3 rounded border">
                    <div className="text-sm font-medium text-slate-700 mb-2">AI Expert Analysis:</div>
                    <p className="text-sm text-slate-600">{calculation.calculationValidation.aiSummary}</p>
                  </div>

                  {calculation.calculationValidation.corrections.length > 0 && (
                    <div>
                      <div className="text-sm font-medium text-slate-700 mb-2">Recommended Corrections:</div>
                      <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                        {calculation.calculationValidation.corrections.map((correction, idx) => (
                          <li key={idx}>{correction}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Safe Mix Confirmation - Green for Safe */}
          {calculation && calculation.compatibilityWarnings && calculation.compatibilityWarnings.length === 0 && calculation.products && calculation.products.length > 1 && 
           (!calculation.calculationValidation || calculation.calculationValidation.isValid) && (
            <Card className="border-green-300 bg-green-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">SAFE: Tank Mix Compatible & Validated</span>
                </div>
                <p className="text-sm text-green-600 mt-1">
                  <strong>Expert Analysis:</strong> AI confirms these products are compatible and calculations are accurate for safe application on fine turf. No negative interactions expected.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}