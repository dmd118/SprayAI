import { useState, useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Sparkles, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProductSuggestion {
  name: string;
  type: string;
  activeIngredient: string;
  commonRate: string;
  brand: string;
  compatibilityNotes?: string;
}

interface ProductSuggestionInputProps {
  value: string;
  onChange: (value: string) => void;
  onSuggestionSelect?: (suggestion: ProductSuggestion) => void;
  productType?: string;
  placeholder?: string;
  className?: string;
}

export function ProductSuggestionInput({
  value,
  onChange,
  onSuggestionSelect,
  productType,
  placeholder = "Start typing product name...",
  className = "",
}: ProductSuggestionInputProps) {
  const { toast } = useToast();
  const [suggestions, setSuggestions] = useState<ProductSuggestion[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  const suggestionMutation = useMutation({
    mutationFn: async (query: string) => {
      const response = await apiRequest("POST", "/api/suggest-products", {
        query,
        productType,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSuggestions(data.suggestions || []);
      setIsOpen(data.suggestions?.length > 0);
      setSelectedIndex(-1);
    },
    onError: (error) => {
      console.error("Failed to get suggestions:", error);
      setSuggestions([]);
      setIsOpen(false);
    },
  });

  // Debounced suggestion fetching
  useEffect(() => {
    if (value.length >= 3) {
      const timeoutId = setTimeout(() => {
        suggestionMutation.mutate(value);
      }, 500);
      return () => clearTimeout(timeoutId);
    } else {
      setSuggestions([]);
      setIsOpen(false);
    }
  }, [value, productType]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
  };

  const handleSuggestionClick = (suggestion: ProductSuggestion) => {
    console.log("Clicking suggestion:", suggestion);
    onChange(suggestion.name);
    setIsOpen(false);
    if (onSuggestionSelect) {
      console.log("Calling onSuggestionSelect with:", suggestion);
      onSuggestionSelect(suggestion);
    } else {
      console.log("No onSuggestionSelect callback provided");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || suggestions.length === 0) return;

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : 0
        );
        break;
      case "ArrowUp":
        e.preventDefault();
        setSelectedIndex(prev => 
          prev > 0 ? prev - 1 : suggestions.length - 1
        );
        break;
      case "Enter":
        e.preventDefault();
        if (selectedIndex >= 0) {
          handleSuggestionClick(suggestions[selectedIndex]);
        }
        break;
      case "Escape":
        e.preventDefault();
        setIsOpen(false);
        setSelectedIndex(-1);
        break;
    }
  };

  const handleBlur = () => {
    // Delay hiding to allow for click events
    setTimeout(() => setIsOpen(false), 300);
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "fungicide": return "bg-blue-100 text-blue-800";
      case "herbicide": return "bg-yellow-100 text-yellow-800";
      case "insecticide": return "bg-red-100 text-red-800";
      case "growth regulator": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="relative">
      <div className="relative">
        <Input
          ref={inputRef}
          value={value}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          placeholder={placeholder}
          className={`pr-10 ${className}`}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          {suggestionMutation.isPending ? (
            <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
          ) : value.length >= 2 ? (
            <Sparkles className="w-4 h-4 text-primary" />
          ) : null}
        </div>
      </div>

      {/* Suggestions Dropdown */}
      {isOpen && suggestions.length > 0 && (
        <div
          ref={suggestionsRef}
          className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-lg shadow-lg max-h-80 overflow-y-auto"
        >
          <div className="p-2 border-b border-slate-100 bg-slate-50">
            <div className="flex items-center text-xs text-slate-600">
              <Sparkles className="w-3 h-3 mr-1" />
              AI-powered UK market suggestions
            </div>
          </div>
          
          {suggestions.map((suggestion, index) => (
            <button
              key={index}
              className={`w-full text-left p-3 hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-b-0 ${
                index === selectedIndex ? "bg-primary/5" : ""
              }`}
              onMouseDown={(e) => {
                e.preventDefault();
                handleSuggestionClick(suggestion);
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-medium text-slate-900 truncate">
                      {suggestion.name}
                    </span>
                    <Badge className={`${getTypeColor(suggestion.type)} text-xs`} variant="secondary">
                      {suggestion.type}
                    </Badge>
                  </div>
                  <div className="text-sm text-slate-600 mb-1">
                    {suggestion.activeIngredient}
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{suggestion.brand}</span>
                    <span>{suggestion.commonRate}</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 ml-2 flex-shrink-0" />
              </div>
            </button>
          ))}
          
          <div className="p-2 bg-slate-50 text-xs text-slate-500 text-center">
            Use ↑↓ to navigate, Enter to select, Esc to close
          </div>
        </div>
      )}
    </div>
  );
}