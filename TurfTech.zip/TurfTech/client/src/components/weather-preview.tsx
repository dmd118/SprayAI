import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Cloud, Thermometer, Wind, Droplets, Settings } from "lucide-react";
import { AdvancedGreenkeeperIntelligence } from "./advanced-greenkeeper-intelligence";

interface WeatherData {
  weather: {
    temperature: number;
    humidity: number;
    windSpeed: number;
    description: string;
    condition: string;
    pressure: number;
    precipitation?: number;
    totalRainfall?: number;
    feelsLike?: number;
    visibility?: number;
    dewPoint?: number;
    uvIndex?: number;
    forecast?: Array<{
      time: string;
      temperature: number;
      humidity: number;
      windSpeed: number;
      precipitation: number;
      description: string;
    }>;
    forecastDay?: string;
    ukTime?: string;
    currentHour?: number;
    greenkeepingCommentary?: string;
  };
  recommendations: string[];
}

interface WeatherPreviewProps {
  location?: string;
  className?: string;
}

export function WeatherPreview({ location = "Dullatur, Cumbernauld, UK", className = "" }: WeatherPreviewProps) {
  const { data: weatherData, isLoading, error } = useQuery<WeatherData>({
    queryKey: ["/api/weather", location],
    queryFn: () => fetch(`/api/weather?location=${encodeURIComponent(location)}`).then(res => res.json()),
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes to reduce server load
  });

  const { data: annualStats, isLoading: annualLoading } = useQuery({
    queryKey: ["/api/weather/annual-stats", location],
    queryFn: () => fetch(`/api/weather/annual-stats?location=${encodeURIComponent(location)}`).then(res => res.json()),
    refetchInterval: 60 * 60 * 1000, // Refresh every hour for annual data
  });

  if (isLoading) {
    return (
      <Button
        variant="outline"
        size="sm"
        className={`flex items-center space-x-2 ${className}`}
        disabled
      >
        <Cloud className="animate-pulse" size={16} />
        <span>Loading...</span>
      </Button>
    );
  }

  if (error || !weatherData?.weather) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className={`flex items-center space-x-1 px-3 py-1.5 h-8 text-gray-600 hover:bg-gray-50 border-gray-200 ${className}`}
          >
            <span className="text-sm">☀️ Weather Setup</span>
            <span className="text-xs text-gray-400">▸</span>
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">Weather Details — Dullatur Cumbernauld Golf Club</DialogTitle>
            <p className="text-sm text-gray-500">Setting up weather integration...</p>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Status Card */}
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-orange-400 rounded-full animate-pulse"></div>
                  <div>
                    <h3 className="font-medium text-orange-900">API Activation in Progress</h3>
                    <p className="text-sm text-orange-700">OpenWeatherMap key activating (1-2 hours from email confirmation)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Preview of Features */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Current Conditions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Temp</span>
                      <span className="font-medium text-gray-400">--°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Humidity</span>
                      <span className="font-medium text-gray-400">--%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Wind Speed</span>
                      <span className="font-medium text-gray-400">-- km/h</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Spray Window</span>
                      <span className="text-gray-400">--</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">6-Hour Forecast</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {['2 PM', '5 PM', '8 PM'].map((time) => (
                      <div key={time} className="flex justify-between items-center py-1">
                        <span className="text-gray-600">{time}</span>
                        <span className="text-gray-400">--°C | -- km/h | --%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* AI Integration */}
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4">
                <h3 className="font-medium text-green-900 mb-2">AI Integration Ready</h3>
                <div className="space-y-1 text-sm text-green-800">
                  <p>✅ AI analysis will use live weather data</p>
                  <p>✅ Automatic alerts for unsuitable spray conditions</p>
                  <p>✅ Weather-adjusted application rate recommendations</p>
                </div>
              </CardContent>
            </Card>

            {/* API Key Status */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-medium mb-3">API Configuration</h3>
                <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Key:</span>
                    <span className="text-gray-900">1a2f...4dc</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Status:</span>
                    <span className="text-orange-600">Pending activation</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const { weather } = weatherData;

  return (
    <Dialog>
      <DialogTrigger asChild>
        {/* Desktop weather button with full details and icons */}
        <Button
          variant="outline"
          size="sm"
          className={`hidden sm:flex items-center space-x-1 px-2 py-1.5 h-8 text-gray-700 hover:bg-gray-50 border-gray-200 overflow-hidden ${className}`}
          style={{ maxWidth: 'calc(100vw - 200px)' }}
        >
          <span className="text-xs truncate">☀️ {weather.temperature}°C</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs truncate">🌧 {weather.precipitation || 0}%</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs truncate">💧 {weather.humidity}%</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs truncate">🌬 {weather.windSpeed} km/h</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs truncate">📍 Dullatur</span>
          <span className="text-xs text-gray-400 ml-1">▸</span>
        </Button>
      </DialogTrigger>
      
      {/* Mobile compact weather button - no icons, just data */}
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={`sm:hidden flex items-center space-x-1 px-2 py-1 h-7 text-gray-700 hover:bg-gray-50 border-gray-200 overflow-hidden ${className}`}
          style={{ maxWidth: 'calc(100vw - 80px)' }}
        >
          <span className="text-xs">{weather.temperature}°C</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs">{weather.precipitation || 0}%</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs">{weather.humidity}%</span>
          <span className="text-xs text-gray-500">|</span>
          <span className="text-xs">{weather.windSpeed}km/h</span>
          <span className="text-xs text-gray-400 ml-1">▸</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-[95vw] sm:max-w-3xl max-h-[90vh] overflow-y-auto overflow-x-hidden">
        <DialogHeader>
          <DialogTitle className="text-lg sm:text-xl font-semibold leading-tight">Weather Details — Dullatur Cumbernauld Golf Club</DialogTitle>
          <p className="text-sm text-gray-500">Last updated: {weather.ukTime || 'Loading...'}</p>
        </DialogHeader>
        
        <div className="space-y-6 w-full min-w-0">
          {/* Current Conditions */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <CardTitle className="text-lg">Current Conditions</CardTitle>
                  <p className="text-sm text-gray-500">
                    As of {weather.ukTime || 'Loading...'} UK time
                  </p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                  weather.windSpeed <= 10 && weather.temperature >= 10 && weather.temperature <= 25 
                    ? 'bg-green-100 text-green-800' 
                    : weather.windSpeed > 15 || weather.condition.includes('rain')
                    ? 'bg-red-100 text-red-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  🌿 {weather.windSpeed <= 10 && weather.temperature >= 10 && weather.temperature <= 25 ? 'Optimal' : 
                       weather.windSpeed > 15 || weather.condition.includes('rain') ? 'Poor' : 'Caution'}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg sm:text-2xl font-bold text-gray-900">{weather.temperature}°C</div>
                  <div className="text-xs text-gray-500">feels {weather.feelsLike || weather.temperature}°C</div>
                  <div className="text-xs sm:text-sm text-gray-600">Temperature</div>
                </div>
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg sm:text-2xl font-bold text-gray-900">{weather.humidity}%</div>
                  <div className="text-xs text-gray-500">dew {weather.dewPoint || '--'}°C</div>
                  <div className="text-xs sm:text-sm text-gray-600">Humidity</div>
                </div>
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg sm:text-2xl font-bold text-gray-900">{weather.windSpeed}</div>
                  <div className="text-xs text-gray-500">km/h</div>
                  <div className="text-xs sm:text-sm text-gray-600">Wind Speed</div>
                </div>
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg sm:text-2xl font-bold text-gray-900">{weather.pressure}</div>
                  <div className="text-xs text-gray-500">hPa</div>
                  <div className="text-xs sm:text-sm text-gray-600">Pressure</div>
                </div>
              </div>
              
              {/* Additional conditions row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3 mt-3">
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-gray-900">{weather.precipitation || 0}%</div>
                  <div className="text-xs sm:text-sm text-gray-600">Precipitation</div>
                </div>
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-gray-900">{weather.totalRainfall || 0}</div>
                  <div className="text-xs text-gray-500">ml</div>
                  <div className="text-xs sm:text-sm text-gray-600">Total Rainfall</div>
                </div>
                <div className="text-center p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-gray-900">{weather.visibility || 10} km</div>
                  <div className="text-xs sm:text-sm text-gray-600">Visibility</div>
                </div>
              </div>
              
              {/* Current conditions and next hour forecast */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-gray-900 capitalize">{weather.description}</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-sm font-medium text-blue-900">
                    {(() => {
                      const precipitation = weather.precipitation || 0;
                      const condition = weather.condition?.toLowerCase() || weather.description?.toLowerCase() || '';
                      
                      if (precipitation >= 80) {
                        return "Expect heavy rain next hour";
                      } else if (precipitation >= 60) {
                        return "Expect moderate rain next hour";
                      } else if (precipitation >= 30) {
                        return "Expect light showers next hour";
                      } else if (condition.includes('cloud') && precipitation < 20) {
                        return "Cloudy conditions continuing";
                      } else if (condition.includes('clear') || condition.includes('sunny')) {
                        return "Sunshine expected next hour";
                      } else if (condition.includes('drizzle')) {
                        return "Expect drizzle next hour";
                      } else if (condition.includes('mist') || condition.includes('fog')) {
                        return "Misty conditions continuing";
                      } else {
                        return precipitation > 10 ? "Possible light rain next hour" : "Dry conditions expected";
                      }
                    })()}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Disease Pressure Forecasting */}
          {(weatherData as any)?.diseaseRisk && (
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-amber-900 flex items-center space-x-2">
                  <span>🦠</span>
                  <span>Disease Pressure Forecast</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    (weatherData as any).diseaseRisk.overallRisk === 'Critical' ? 'bg-red-100 text-red-800' :
                    (weatherData as any).diseaseRisk.overallRisk === 'High' ? 'bg-orange-100 text-orange-800' :
                    (weatherData as any).diseaseRisk.overallRisk === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {(weatherData as any).diseaseRisk.overallRisk} Risk
                  </span>
                </CardTitle>
                <p className="text-sm text-amber-700">48-72 hour disease development assessment</p>
              </CardHeader>
              <CardContent>
                {(weatherData as any).diseaseRisk.diseases.length > 0 ? (
                  <div className="space-y-4">
                    {/* Disease List */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {(weatherData as any).diseaseRisk.diseases.map((disease: any, index: number) => (
                        <div key={index} className={`p-3 rounded-lg border ${
                          disease.riskLevel === 'Critical' ? 'bg-red-50 border-red-200' :
                          disease.riskLevel === 'High' ? 'bg-orange-50 border-orange-200' :
                          'bg-yellow-50 border-yellow-200'
                        }`}>
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium text-gray-900">{disease.name}</h4>
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              disease.riskLevel === 'Critical' ? 'bg-red-100 text-red-800' :
                              disease.riskLevel === 'High' ? 'bg-orange-100 text-orange-800' :
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {disease.riskLevel}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">{disease.description}</p>
                          <div className="text-xs text-gray-600">
                            <p>Peak risk: {disease.peakRiskHours}h</p>
                            <p>Confidence: {Math.round(disease.confidence * 100)}%</p>
                            <p className="text-green-700 font-medium mt-1">{disease.optimalApplicationWindow}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Preventative Treatments */}
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-medium text-blue-900 mb-2">Recommended Preventative Treatments</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {Array.from(new Set((weatherData as any).diseaseRisk.diseases.flatMap((d: any) => d.preventativeTreatments))).map((treatment: any, index: number) => (
                          <div key={index} className="text-sm text-blue-800 bg-blue-100 px-2 py-1 rounded">
                            {treatment}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Action Recommendations */}
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <h4 className="font-medium text-green-900 mb-2">Action Recommendations</h4>
                      <ul className="space-y-1">
                        {(weatherData as any).diseaseRisk.recommendations.map((rec: string, index: number) => (
                          <li key={index} className="text-sm text-green-800 flex items-start space-x-2">
                            <span className="text-green-600 mt-1">•</span>
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <div className="text-green-600 text-2xl mb-2">✅</div>
                    <p className="text-green-800 font-medium">Low Disease Pressure</p>
                    <p className="text-sm text-green-700">Current conditions show minimal disease risk. Maintain normal monitoring schedule.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Professional Greenkeeping Commentary */}
          {weather.greenkeepingCommentary && (
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-blue-900">Professional Greenkeeping Commentary</CardTitle>
                <p className="text-sm text-blue-700">Analysis specific to Dullatur Golf Club conditions</p>
              </CardHeader>
              <CardContent>
                <p className="text-blue-900 leading-relaxed break-words whitespace-normal overflow-wrap-anywhere">{weather.greenkeepingCommentary}</p>
              </CardContent>
            </Card>
          )}

          {/* Greenkeeping Hours Forecast */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">
                Greenkeeping Hours Forecast {weather.forecastDay === 'tomorrow' ? '(Tomorrow)' : '(Today)'}
              </CardTitle>
              <p className="text-sm text-gray-600">Working hours: 6 AM - 3 PM</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {weather.forecast && weather.forecast.length > 0 ? (
                  weather.forecast.map((forecast, i) => (
                    <div key={i} className="flex justify-between items-center py-3 border-b border-gray-100 last:border-0">
                      <span className="font-medium text-gray-700">{forecast.time}</span>
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="font-medium">{forecast.temperature}°C</span>
                        <span className="text-gray-600">{forecast.windSpeed} km/h</span>
                        <span className="text-gray-600">{forecast.humidity}%</span>
                        <span className={`font-medium ${forecast.precipitation > 50 ? 'text-red-600' : forecast.precipitation > 20 ? 'text-yellow-600' : 'text-green-600'}`}>
                          {forecast.precipitation}% rain
                        </span>
                        <span className="text-lg">
                          {forecast.precipitation < 20 ? '☀️' : forecast.precipitation < 50 ? '🌥' : '🌧'}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p>Real forecast data loading...</p>
                    <p className="text-xs mt-1">Will show next working hours (6 AM - 3 PM)</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* AI Integration Status */}
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <h3 className="font-medium text-green-900 mb-2">AI Integration Active</h3>
              <div className="space-y-1 text-sm text-green-800">
                <p>✅ AI analysis using live weather data</p>
                <p>✅ Weather-adjusted recommendations enabled</p>
                <p>✅ Automatic spray condition alerts active</p>
              </div>
            </CardContent>
          </Card>

          {/* Weather Recommendations */}
          {weatherData.recommendations && weatherData.recommendations.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Spray Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {weatherData.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-start space-x-2 p-2 bg-gray-50 rounded-lg">
                      <span className="text-green-500 mt-1">•</span>
                      <span className="text-sm text-gray-700">{rec}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Annual Weather Statistics */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">2025 Weather Statistics — Dullatur Golf Club</CardTitle>
              <p className="text-sm text-gray-600">Year-to-date environmental data for course planning</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-2xl font-bold text-blue-900">
                    {annualLoading ? 'Loading...' : annualStats?.totalRainfall2025 || '--'}
                  </div>
                  <div className="text-xs text-blue-600 mt-1">ml total</div>
                  <div className="text-sm text-blue-700 font-medium">Total Rainfall 2025</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg border border-orange-200">
                  <div className="text-2xl font-bold text-orange-900">
                    {annualLoading ? 'Loading...' : annualStats?.averageTemperature2025 || '--'}
                  </div>
                  <div className="text-xs text-orange-600 mt-1">°C average</div>
                  <div className="text-sm text-orange-700 font-medium">Annual Temperature</div>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="text-2xl font-bold text-yellow-900">
                    {annualLoading ? 'Loading...' : annualStats?.totalSunshineHours || '--'}
                  </div>
                  <div className="text-xs text-yellow-600 mt-1">hours total</div>
                  <div className="text-sm text-yellow-700 font-medium">Sunshine Hours</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-2xl font-bold text-green-900">
                    {annualLoading ? 'Loading...' : annualStats?.totalEvapotranspiration || '--'}
                  </div>
                  <div className="text-xs text-green-600 mt-1">mm total</div>
                  <div className="text-sm text-green-700 font-medium">Evapotranspiration</div>
                </div>
              </div>

              {/* Greenkeeper Temperature Chart */}
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">Average Monthly Temperatures (°C)</h4>
                <div className="flex items-center space-x-6 mb-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-orange-400 rounded"></div>
                    <span className="text-sm text-gray-700">Average Daytime High</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 bg-green-500 rounded"></div>
                    <span className="text-sm text-gray-700">Average Soil Temperature</span>
                  </div>
                </div>
                <div className="h-48 bg-gray-50 rounded-lg flex items-end justify-between p-4 space-x-1 relative">
                  {/* Y-axis labels */}
                  <div className="absolute left-2 top-4 text-xs text-gray-500">25°C</div>
                  <div className="absolute left-2 top-1/3 text-xs text-gray-500">15°C</div>
                  <div className="absolute left-2 top-2/3 text-xs text-gray-500">5°C</div>
                  <div className="absolute left-2 bottom-12 text-xs text-gray-500">0°C</div>
                  
                  {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((month, index) => {
                    // Use authentic weather data from Scottish weather API
                    const daytimeHigh = annualStats?.monthlyDaytimeHighs?.[index] || 0;
                    const soilTemp = annualStats?.monthlySoilTemperatures?.[index] || 0;
                    
                    const maxHeight = 140; // Max chart height in pixels
                    const soilHeight = Math.max(8, (soilTemp / 25) * maxHeight);
                    const airHeight = Math.max(8, ((daytimeHigh - soilTemp) / 25) * maxHeight);
                    
                    return (
                      <div key={month} className="flex flex-col items-center space-y-1 flex-1">
                        <div className="w-full flex flex-col relative group">
                          {/* Air temperature (orange, stacked on top) */}
                          <div 
                            className="bg-orange-400 rounded-t w-full transition-all duration-300"
                            style={{ height: `${airHeight}px` }}
                          >
                            <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                              Air: {daytimeHigh.toFixed(1)}°C<br/>
                              Soil: {soilTemp.toFixed(1)}°C
                            </div>
                          </div>
                          {/* Soil temperature (green, base) */}
                          <div 
                            className="bg-green-500 rounded-b w-full transition-all duration-300"
                            style={{ height: `${soilHeight}px` }}
                          />
                        </div>
                        <span className="text-xs text-gray-600 transform -rotate-45 origin-center mt-2">{month}</span>
                      </div>
                    );
                  })}
                </div>
              </div>



              {/* Monthly Rainfall Chart */}
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">Monthly Rainfall (ml)</h4>
                <div className="h-32 bg-gray-50 rounded-lg flex items-end justify-between p-4 space-x-1">
                  {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((month, index) => {
                    const rainfall = annualStats?.monthlyRainfall?.[index] || 0;
                    const height = Math.max(10, (rainfall / 200) * 80); // Scale to chart height
                    return (
                      <div key={month} className="flex flex-col items-center space-y-1 flex-1">
                        <div 
                          className="bg-blue-400 rounded-t w-full transition-all duration-300 relative group"
                          style={{ height: `${height}px` }}
                        >
                          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-1 py-0.5 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                            {rainfall}ml
                          </div>
                        </div>
                        <span className="text-xs text-gray-600 transform -rotate-45 origin-center">{month}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span>0ml</span>
                  <span>200ml</span>
                </div>
              </div>

              {/* Advanced Greenkeeping Intelligence */}
              <AdvancedGreenkeeperIntelligence />

              <div className="mt-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
                <p className="text-sm text-amber-800">
                  <span className="font-medium">Data Source:</span> Authentic historical weather data from WeatherAPI meteorological records. 
                  {annualStats?.error ? 
                    'WeatherAPI access required for complete 2025 statistics including sunshine hours and evapotranspiration data.' :
                    'Displaying comprehensive weather station data for Dullatur Golf Club area.'
                  }
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Export Section */}
          <div className="flex gap-3 pt-4 border-t">
            <Button className="flex-1 bg-green-600 hover:bg-green-700">
              Export Weather Report PDF
            </Button>
            <Button variant="outline" className="flex-1">
              Sync Weather to Plans
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}