import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Calendar, X, Check, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface StaffMember {
  id: number;
  name: string;
  staffType: string;
  weekendShiftsWorked: number;
}

interface CalendarProps {
  staffMember: StaffMember;
  isOpen: boolean;
  onClose: () => void;
}

interface CalendarDay {
  date: Date;
  hasShift: boolean;
  isPayday: boolean;
  isTimeOffRequested: boolean;
  isWeekend: boolean;
  isCurrentMonth: boolean;
}

export function StaffCalendar({ staffMember, isOpen, onClose }: CalendarProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDates, setSelectedDates] = useState<Date[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<Date | null>(null);

  // Fetch staff rota data
  const { data: rotaData = [] } = useQuery({
    queryKey: ['/api/staff-rota'],
  });

  // Fetch time off requests
  const { data: timeOffRequests = [] } = useQuery({
    queryKey: ['/api/time-off-requests', staffMember.id],
  });

  // Submit time off request
  const timeOffMutation = useMutation({
    mutationFn: async (dates: Date[]) => {
      return await apiRequest('/api/time-off-requests', 'POST', {
        staffId: staffMember.id,
        startDate: dates[0].toISOString(),
        endDate: dates[dates.length - 1].toISOString(),
        dates: dates.map(d => d.toISOString())
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/time-off-requests', staffMember.id] });
      setSelectedDates([]);
      toast({
        title: "Time Off Requested",
        description: `Successfully requested ${selectedDates.length} days off for ${staffMember.name}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Request Failed",
        description: error.message || "Failed to submit time off request",
        variant: "destructive",
      });
    }
  });

  // Generate calendar days for current month view
  const generateCalendarDays = (): CalendarDay[] => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    // Get first day of month and calculate starting date (showing previous month's trailing days)
    const firstDay = new Date(year, month, 1);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay()); // Start from Sunday
    
    const days: CalendarDay[] = [];
    
    // Generate 42 days (6 weeks) for complete calendar view
    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);
      
      const isCurrentMonth = date.getMonth() === month;
      const isWeekend = date.getDay() === 0 || date.getDay() === 6; // Sunday or Saturday
      
      // Check if staff member has a shift on this date
      const hasShift = Array.isArray(rotaData) && rotaData.some((shift: any) => {
        if (shift.staffId !== staffMember.id) return false;
        const shiftDate = new Date(shift.date);
        return shiftDate.toDateString() === date.toDateString();
      });
      
      // Check if it's payday (28th or Friday before if 28th is weekend)
      const isPayday = calculatePayday(date);
      
      // Check if time off is requested for this date
      const isTimeOffRequested = Array.isArray(timeOffRequests) && timeOffRequests.some((request: any) => {
        const requestDate = new Date(request.date);
        return requestDate.toDateString() === date.toDateString();
      });
      
      days.push({
        date,
        hasShift,
        isPayday,
        isTimeOffRequested,
        isWeekend,
        isCurrentMonth
      });
    }
    
    return days;
  };

  // Calculate if a date is payday
  const calculatePayday = (date: Date): boolean => {
    const day28 = new Date(date.getFullYear(), date.getMonth(), 28);
    
    // If 28th is weekend, payday is Friday before
    if (day28.getDay() === 0) { // Sunday
      day28.setDate(26); // Friday before
    } else if (day28.getDay() === 6) { // Saturday
      day28.setDate(27); // Friday before
    }
    
    return date.toDateString() === day28.toDateString();
  };

  // Handle date selection for time off requests
  const handleDateClick = (date: Date) => {
    if (!isDragging) {
      // Single click - toggle selection
      const isSelected = selectedDates.some(d => d.toDateString() === date.toDateString());
      if (isSelected) {
        setSelectedDates(selectedDates.filter(d => d.toDateString() !== date.toDateString()));
      } else if (selectedDates.length < 14) {
        setSelectedDates([...selectedDates, date]);
      }
    }
  };

  const handleMouseDown = (date: Date) => {
    setIsDragging(true);
    setDragStart(date);
    setSelectedDates([date]);
  };

  const handleMouseOver = (date: Date) => {
    if (isDragging && dragStart) {
      const start = dragStart < date ? dragStart : date;
      const end = dragStart < date ? date : dragStart;
      
      const range: Date[] = [];
      const current = new Date(start);
      
      while (current <= end && range.length < 14) {
        range.push(new Date(current));
        current.setDate(current.getDate() + 1);
      }
      
      setSelectedDates(range);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragStart(null);
  };

  const calendarDays = generateCalendarDays();
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const clearSelection = () => {
    setSelectedDates([]);
  };

  const submitTimeOff = () => {
    if (selectedDates.length > 0) {
      timeOffMutation.mutate(selectedDates);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            {staffMember.name} - Personal Calendar
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Calendar Header */}
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={previousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <h3 className="text-xl font-semibold">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </h3>
            
            <Button variant="outline" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span>Weekend Shift</span>
            </div>
            <div className="flex items-center gap-1">
              <DollarSign className="h-4 w-4 text-yellow-500" />
              <span>Payday</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 bg-blue-500 rounded"></div>
              <span>Selected for Time Off</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span>Time Off Requested</span>
            </div>
          </div>

          {/* Calendar Grid */}
          <Card>
            <CardContent className="p-4">
              {/* Day headers */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="text-center font-semibold text-sm p-2">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* Calendar days */}
              <div 
                className="grid grid-cols-7 gap-1"
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              >
                {calendarDays.map((day, index) => {
                  const isSelected = selectedDates.some(d => d.toDateString() === day.date.toDateString());
                  
                  return (
                    <div
                      key={index}
                      className={`
                        relative min-h-[40px] p-1 border border-gray-200 rounded cursor-pointer
                        hover:bg-gray-50 transition-colors select-none
                        ${!day.isCurrentMonth ? 'text-gray-400 bg-gray-50' : ''}
                        ${day.hasShift ? 'bg-green-100 border-green-300' : ''}
                        ${day.isTimeOffRequested ? 'bg-red-100 border-red-300' : ''}
                        ${isSelected ? 'bg-blue-100 border-blue-300' : ''}
                      `}
                      onClick={() => handleDateClick(day.date)}
                      onMouseDown={() => handleMouseDown(day.date)}
                      onMouseOver={() => handleMouseOver(day.date)}
                    >
                      <div className="text-sm font-medium">
                        {day.date.getDate()}
                      </div>
                      
                      {/* Indicators */}
                      <div className="absolute top-1 right-1 flex flex-col gap-1">
                        {day.hasShift && (
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        )}
                        {day.isPayday && (
                          <DollarSign className="h-3 w-3 text-yellow-500" />
                        )}
                        {day.isTimeOffRequested && (
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Time Off Request Actions */}
          {selectedDates.length > 0 && (
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold">Time Off Request</h4>
                    <p className="text-sm text-gray-600">
                      {selectedDates.length} day{selectedDates.length !== 1 ? 's' : ''} selected
                      {selectedDates.length > 14 && ' (Maximum 14 days allowed)'}
                    </p>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={clearSelection}>
                      <X className="h-4 w-4 mr-2" />
                      Clear
                    </Button>
                    <Button 
                      onClick={submitTimeOff}
                      disabled={selectedDates.length === 0 || selectedDates.length > 14 || timeOffMutation.isPending}
                    >
                      {timeOffMutation.isPending ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Check className="h-4 w-4 mr-2" />
                          Submit Request
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Staff Summary */}
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">{staffMember.weekendShiftsWorked}</div>
                  <div className="text-sm text-gray-600">Weekend Shifts</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">{selectedDates.length}</div>
                  <div className="text-sm text-gray-600">Days Selected</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-yellow-600">
                    {calendarDays.filter(d => d.isPayday && d.isCurrentMonth).length}
                  </div>
                  <div className="text-sm text-gray-600">Paydays This Month</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">
                    {Array.isArray(timeOffRequests) ? timeOffRequests.length : 0}
                  </div>
                  <div className="text-sm text-gray-600">Time Off Requests</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}