import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar, Plus, Edit, Trash2, CheckCircle, Clock, AlertTriangle, BarChart3, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StaffRota } from "@/components/staff-rota";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO, isAfter, isBefore, startOfDay, endOfDay } from "date-fns";
import type { SeasonalPlan, InsertSeasonalPlan, ScheduledApplication, SprayProduct, TurfArea } from "@shared/schema";

const seasonalPlanSchema = z.object({
  name: z.string().min(1, "Plan name is required"),
  season: z.enum(["spring", "summer", "autumn", "winter"]),
  year: z.number().min(2020).max(2030),
  startDate: z.string(),
  endDate: z.string(),
  description: z.string().optional(),
  status: z.enum(["active", "completed", "archived"]).default("active"),
});

type FormData = z.infer<typeof seasonalPlanSchema>;

const seasonColors = {
  spring: "bg-green-100 text-green-800 border-green-200",
  summer: "bg-yellow-100 text-yellow-800 border-yellow-200", 
  autumn: "bg-orange-100 text-orange-800 border-orange-200",
  winter: "bg-blue-100 text-blue-800 border-blue-200"
};

const statusColors = {
  active: "bg-emerald-100 text-emerald-800",
  completed: "bg-gray-100 text-gray-800",
  archived: "bg-slate-100 text-slate-800"
};

export function SeasonalPlanning() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<SeasonalPlan | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<SeasonalPlan | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(seasonalPlanSchema),
    defaultValues: {
      name: "",
      season: "spring",
      year: new Date().getFullYear(),
      startDate: "",
      endDate: "",
      description: "",
      status: "active",
    },
  });

  const { data: plans = [], isLoading } = useQuery<SeasonalPlan[]>({
    queryKey: ["/api/seasonal-plans"],
  });

  const { data: products = [] } = useQuery<SprayProduct[]>({
    queryKey: ["/api/spray-products"],
  });

  const { data: areas = [] } = useQuery<TurfArea[]>({
    queryKey: ["/api/turf-areas"],
  });

  const { data: scheduledApplications = [] } = useQuery<ScheduledApplication[]>({
    queryKey: ["/api/scheduled-applications"],
    enabled: !!selectedPlan,
  });

  const createMutation = useMutation({
    mutationFn: (data: FormData) => {
      const planData: InsertSeasonalPlan = {
        ...data,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
      };
      return apiRequest("POST", "/api/seasonal-plans", planData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/seasonal-plans"] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({ title: "Seasonal plan created successfully" });
    },
    onError: () => {
      toast({ title: "Failed to create seasonal plan", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<FormData> }) => {
      const planData = {
        ...data,
        ...(data.startDate && { startDate: new Date(data.startDate) }),
        ...(data.endDate && { endDate: new Date(data.endDate) }),
      };
      return apiRequest("PUT", `/api/seasonal-plans/${id}`, planData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/seasonal-plans"] });
      setEditingPlan(null);
      form.reset();
      toast({ title: "Seasonal plan updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update seasonal plan", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/seasonal-plans/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/seasonal-plans"] });
      toast({ title: "Seasonal plan deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete seasonal plan", variant: "destructive" });
    },
  });

  const handleSubmit = (data: FormData) => {
    if (editingPlan) {
      updateMutation.mutate({ id: editingPlan.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (plan: SeasonalPlan) => {
    setEditingPlan(plan);
    form.reset({
      name: plan.name,
      season: plan.season as "spring" | "summer" | "autumn" | "winter",
      year: plan.year,
      startDate: format(parseISO(plan.startDate.toString()), "yyyy-MM-dd"),
      endDate: format(parseISO(plan.endDate.toString()), "yyyy-MM-dd"),
      description: plan.description || "",
      status: plan.status as "active" | "completed" | "archived",
    });
    setIsCreateDialogOpen(true);
  };

  const calculatePlanProgress = (plan: SeasonalPlan) => {
    const total = scheduledApplications.filter(app => app.seasonalPlanId === plan.id).length;
    const completed = scheduledApplications.filter(app => 
      app.seasonalPlanId === plan.id && app.status === "completed"
    ).length;
    return { total, completed, percentage: total > 0 ? Math.round((completed / total) * 100) : 0 };
  };

  const getUpcomingApplications = (plan: SeasonalPlan) => {
    const now = new Date();
    return scheduledApplications
      .filter(app => 
        app.seasonalPlanId === plan.id && 
        app.status === "scheduled" &&
        isAfter(new Date(app.scheduledDate), now)
      )
      .sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime())
      .slice(0, 3);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-gray-200 rounded animate-pulse"></div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 bg-gray-200 rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Seasonal Planning</h2>
          <p className="text-gray-600">Plan and track seasonal application programs & staff management</p>
        </div>
      </div>

      <Tabs defaultValue="plans" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="plans" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Seasonal Plans
          </TabsTrigger>
          <TabsTrigger value="staff-rota" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Staff Rota
          </TabsTrigger>
        </TabsList>

        <TabsContent value="plans" className="space-y-6">
          <div className="flex justify-between items-center">
            <div></div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Seasonal Plan
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingPlan ? "Edit Seasonal Plan" : "Create New Seasonal Plan"}
              </DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Plan Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Spring Disease Prevention" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="season"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Season</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select season" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="spring">Spring</SelectItem>
                            <SelectItem value="summer">Summer</SelectItem>
                            <SelectItem value="autumn">Autumn</SelectItem>
                            <SelectItem value="winter">Winter</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Year</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="2020" 
                            max="2030"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe the seasonal plan objectives and key treatments..."
                          className="min-h-[80px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="archived">Archived</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsCreateDialogOpen(false);
                      setEditingPlan(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                    {editingPlan ? "Update Plan" : "Create Plan"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
          </div>

      {plans.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No seasonal plans yet</h3>
            <p className="text-gray-600 mb-4">
              Create your first seasonal plan to organize spray applications by season
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Seasonal Plan
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {plans.map((plan: SeasonalPlan) => {
            const progress = calculatePlanProgress(plan);
            const upcomingApps = getUpcomingApplications(plan);
            
            return (
              <Card key={plan.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{plan.name}</CardTitle>
                      <div className="flex gap-2">
                        <Badge className={seasonColors[plan.season as keyof typeof seasonColors]}>
                          {plan.season} {plan.year}
                        </Badge>
                        <Badge className={statusColors[plan.status as keyof typeof statusColors]}>
                          {plan.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(plan)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => deleteMutation.mutate(plan.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-sm text-gray-600">
                    {format(parseISO(plan.startDate.toString()), "MMM d")} - {format(parseISO(plan.endDate.toString()), "MMM d, yyyy")}
                  </div>
                  
                  {plan.description && (
                    <p className="text-sm text-gray-700 line-clamp-2">{plan.description}</p>
                  )}

                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600">Progress</span>
                      <span className="font-medium">{progress.completed}/{progress.total} applications</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all"
                        style={{ width: `${progress.percentage}%` }}
                      ></div>
                    </div>
                  </div>

                  {upcomingApps.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-1 text-sm font-medium text-gray-700">
                        <Clock className="h-3 w-3" />
                        Upcoming Applications
                      </div>
                      {upcomingApps.map((app) => {
                        const product = products.find(p => p.id === app.productId);
                        const area = areas.find(a => a.id === app.areaId);
                        return (
                          <div key={app.id} className="text-xs text-gray-600 pl-4">
                            {format(parseISO(app.scheduledDate.toString()), "MMM d")} - {product?.name} on {area?.name}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => setSelectedPlan(plan)}
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
        </TabsContent>

        <TabsContent value="staff-rota">
          <StaffRota />
        </TabsContent>
      </Tabs>
    </div>
  );
}