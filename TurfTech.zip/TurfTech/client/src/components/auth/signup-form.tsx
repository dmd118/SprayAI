import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Building, CreditCard, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

// Payment Form Component
const PaymentForm = ({ clientSecret, onSuccess, onBack }: {
  clientSecret: string;
  onSuccess: () => void;
  onBack: () => void;
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState<string>("");

  const handlePayment = async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setPaymentError("");

    const cardElement = elements.getElement(CardElement);
    if (!cardElement) {
      setPaymentError("Card element not found");
      setIsProcessing(false);
      return;
    }

    try {
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
        },
      });

      if (error) {
        setPaymentError(error.message || "Payment failed");
      } else if (paymentIntent?.status === "succeeded") {
        onSuccess();
      }
    } catch (err: any) {
      setPaymentError(err.message || "Payment failed");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Card Details</Label>
        <div className="border border-gray-300 dark:border-gray-600 rounded-md p-3 bg-white dark:bg-gray-800">
          <CardElement 
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': {
                    color: '#aab7c4',
                  },
                },
              },
            }}
          />
        </div>
      </div>

      {paymentError && (
        <Alert>
          <AlertDescription className="text-red-600">{paymentError}</AlertDescription>
        </Alert>
      )}

      <div className="flex space-x-3">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onBack}
          className="flex-1"
          disabled={isProcessing}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button 
          type="button" 
          onClick={handlePayment}
          className="flex-1" 
          disabled={isProcessing || !stripe}
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <CreditCard className="mr-2 h-4 w-4" />
              Complete Payment
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

const signupSchema = z.object({
  // Club information
  clubName: z.string().min(2, "Club name must be at least 2 characters"),
  location: z.string().min(2, "Location is required"),
  // User information
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Valid email address required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type SignupFormData = z.infer<typeof signupSchema>;

interface SignupFormProps {
  onSuccess: (message: string) => void;
  onSwitchToLogin: () => void;
}

export function SignupForm({ onSuccess, onSwitchToLogin }: SignupFormProps) {
  const [error, setError] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<'club' | 'user' | 'payment'>('club');
  const [priceInfo, setPriceInfo] = useState<{ amount: number; currency: string; interval: string } | null>(null);
  const [clientSecret, setClientSecret] = useState<string>("");
  const [subscriptionData, setSubscriptionData] = useState<any>(null);

  useEffect(() => {
    // Fetch current subscription price
    fetch('/api/subscription-price')
      .then(res => res.json())
      .then(data => setPriceInfo(data))
      .catch(err => console.error('Failed to fetch price:', err));
  }, []);

  const form = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      clubName: "",
      location: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onSubmit = async (data: SignupFormData) => {
    try {
      setIsLoading(true);
      setError("");

      const payload = {
        club: {
          name: data.clubName,
          location: data.location,
          subscriptionStatus: "inactive", // Will be activated after payment
          subscriptionTier: "premium",
        },
        user: {
          username: data.username,
          email: data.email,
          password: data.password,
        },
      };

      const response = await fetch("/api/auth/create-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Registration failed");
      }

      // If we have a client secret, proceed to payment step
      if (result.clientSecret) {
        setStep('payment'); // Move to payment step
        setClientSecret(result.clientSecret);
        setSubscriptionData(result);
      } else {
        onSuccess("Account created successfully! Please complete payment to activate your subscription.");
      }
    } catch (err: any) {
      setError(err.message || "Registration failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const renderClubStep = () => (
    <>
      <div className="space-y-2">
        <Label htmlFor="clubName">Golf Club Name</Label>
        <Input
          id="clubName"
          type="text"
          placeholder="e.g., Pinehurst Golf Club"
          {...form.register("clubName")}
          disabled={isLoading}
        />
        {form.formState.errors.clubName && (
          <p className="text-sm text-red-600">{form.formState.errors.clubName.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="location">Location</Label>
        <Input
          id="location"
          type="text"
          placeholder="e.g., Edinburgh, Scotland"
          {...form.register("location")}
          disabled={isLoading}
        />
        {form.formState.errors.location && (
          <p className="text-sm text-red-600">{form.formState.errors.location.message}</p>
        )}
        <p className="text-xs text-gray-500">Used for weather data and regional compliance</p>
      </div>

      <Button 
        type="button" 
        onClick={() => setStep('user')} 
        className="w-full"
        disabled={!form.watch("clubName") || !form.watch("location")}
      >
        Continue to Account Setup
      </Button>
    </>
  );

  const renderUserStep = () => (
    <>
      <div className="space-y-2">
        <Label htmlFor="username">Username</Label>
        <Input
          id="username"
          type="text"
          placeholder="Choose a username"
          {...form.register("username")}
          disabled={isLoading}
        />
        {form.formState.errors.username && (
          <p className="text-sm text-red-600">{form.formState.errors.username.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email Address</Label>
        <Input
          id="email"
          type="email"
          placeholder="admin@yourgolfclub.com"
          {...form.register("email")}
          disabled={isLoading}
        />
        {form.formState.errors.email && (
          <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          placeholder="Create a secure password"
          {...form.register("password")}
          disabled={isLoading}
        />
        {form.formState.errors.password && (
          <p className="text-sm text-red-600">{form.formState.errors.password.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="confirmPassword">Confirm Password</Label>
        <Input
          id="confirmPassword"
          type="password"
          placeholder="Confirm your password"
          {...form.register("confirmPassword")}
          disabled={isLoading}
        />
        {form.formState.errors.confirmPassword && (
          <p className="text-sm text-red-600">{form.formState.errors.confirmPassword.message}</p>
        )}
      </div>

      <div className="flex space-x-3">
        <Button 
          type="button" 
          variant="outline" 
          onClick={() => setStep('club')}
          className="flex-1"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Button 
          type="submit" 
          className="flex-1"
          disabled={isLoading || !form.watch("username") || !form.watch("email") || !form.watch("password")}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating Account...
            </>
          ) : (
            "Continue to Payment"
          )}
        </Button>
      </div>
    </>
  );

  const renderPaymentStep = () => (
    <>
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-4">
        <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">Premium Features Include:</h3>
        <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
          <li>• Unlimited spray products and fertilizers</li>
          <li>• AI-powered compatibility analysis</li>
          <li>• Weather-integrated spray timing</li>
          <li>• Staff rota management</li>
          <li>• Application record tracking</li>
          <li>• Industry news and updates</li>
        </ul>
      </div>

      <div className="border border-gray-200 dark:border-gray-700 p-4 rounded-lg mb-4">
        <div className="flex justify-between items-center">
          <span className="font-medium">Premium Subscription</span>
          <span className="text-2xl font-bold">
            {priceInfo ? `£${priceInfo.amount}/${priceInfo.interval}` : 'Loading...'}
          </span>
        </div>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Professional greenkeeping management platform
        </p>
      </div>

      {clientSecret ? (
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <PaymentForm
            clientSecret={clientSecret}
            onSuccess={() => onSuccess("Payment completed successfully! Welcome to the platform.")}
            onBack={() => setStep('user')}
          />
        </Elements>
      ) : (
        <div className="space-y-4">
          <div className="text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Loading payment form...
            </p>
          </div>
          <div className="flex space-x-3">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setStep('user')}
              className="flex-1"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <Button 
              type="button" 
              className="flex-1" 
              disabled
            >
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Loading...
            </Button>
          </div>
        </div>
      )}
    </>
  );



  const getStepTitle = () => {
    switch (step) {
      case 'club': return 'Club Information';
      case 'user': return 'Account Setup';
      case 'payment': return 'Subscription';
      default: return 'Sign Up';
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex items-center justify-center mb-4">
            <Building className="h-8 w-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-center">{getStepTitle()}</CardTitle>
          <CardDescription className="text-center">
            Join the professional greenkeeping platform
          </CardDescription>
          
          {/* Progress indicator */}
          <div className="flex justify-center space-x-2 mt-4">
            <div className={`h-2 w-8 rounded-full ${step === 'club' ? 'bg-green-600' : 'bg-gray-300'}`} />
            <div className={`h-2 w-8 rounded-full ${step === 'user' ? 'bg-green-600' : 'bg-gray-300'}`} />
            <div className={`h-2 w-8 rounded-full ${step === 'payment' ? 'bg-green-600' : 'bg-gray-300'}`} />
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {step === 'club' && renderClubStep()}
            {step === 'user' && renderUserStep()}
            {step === 'payment' && renderPaymentStep()}
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Already have an account?{" "}
              <button
                type="button"
                onClick={onSwitchToLogin}
                className="text-green-600 hover:text-green-500 font-medium"
                disabled={isLoading}
              >
                Sign in
              </button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}