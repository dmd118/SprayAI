import { useState, useEffect } from "react";
import { LoginForm } from "./login-form";
import { SignupForm } from "./signup-form";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle } from "lucide-react";

interface AuthWrapperProps {
  children: React.ReactNode;
}

interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  user: any | null;
  club: any | null;
  isLoading: boolean;
}

export function AuthWrapper({ children }: AuthWrapperProps) {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    token: null,
    user: null,
    club: null,
    isLoading: true,
  });
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [successMessage, setSuccessMessage] = useState<string>("");

  useEffect(() => {
    // Check for existing authentication on mount
    const token = localStorage.getItem("auth_token");
    const userData = localStorage.getItem("user_data");
    const clubData = localStorage.getItem("club_data");

    if (token && userData && clubData) {
      try {
        const user = JSON.parse(userData);
        const club = JSON.parse(clubData);
        
        setAuthState({
          isAuthenticated: true,
          token,
          user,
          club,
          isLoading: false,
        });
      } catch (error) {
        // Clear corrupted data
        localStorage.removeItem("auth_token");
        localStorage.removeItem("user_data");
        localStorage.removeItem("club_data");
        setAuthState(prev => ({ ...prev, isLoading: false }));
      }
    } else {
      setAuthState(prev => ({ ...prev, isLoading: false }));
    }
  }, []);

  const handleLoginSuccess = (token: string, user: any, club: any) => {
    setAuthState({
      isAuthenticated: true,
      token,
      user,
      club,
      isLoading: false,
    });
    setSuccessMessage("");
  };

  const handleSignupSuccess = (message: string) => {
    setSuccessMessage(message);
    setAuthMode('login');
  };

  const handleLogout = () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("user_data");
    localStorage.removeItem("club_data");
    setAuthState({
      isAuthenticated: false,
      token: null,
      user: null,
      club: null,
      isLoading: false,
    });
  };

  // Add logout function to window for easy access
  useEffect(() => {
    (window as any).logout = handleLogout;
    return () => {
      delete (window as any).logout;
    };
  }, []);

  if (authState.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!authState.isAuthenticated) {
    return (
      <>
        {successMessage && (
          <div className="fixed top-4 right-4 z-50 max-w-md">
            <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800 dark:text-green-200">
                {successMessage}
              </AlertDescription>
            </Alert>
          </div>
        )}
        
        {authMode === 'login' ? (
          <LoginForm
            onSuccess={handleLoginSuccess}
            onSwitchToSignup={() => setAuthMode('signup')}
          />
        ) : (
          <SignupForm
            onSuccess={handleSignupSuccess}
            onSwitchToLogin={() => setAuthMode('login')}
          />
        )}
      </>
    );
  }

  // User is authenticated, show the main application
  return <>{children}</>;
}