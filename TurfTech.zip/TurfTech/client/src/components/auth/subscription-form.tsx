import { useState, useEffect } from "react";
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle } from "lucide-react";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface SubscriptionFormProps {
  clubData: any;
  userData: any;
  onSuccess: (paymentResult: any) => void;
  onBack: () => void;
}

const CheckoutForm = ({ clubData, userData, onSuccess, onBack }: SubscriptionFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [priceInfo, setPriceInfo] = useState<{ amount: number; currency: string; interval: string } | null>(null);

  useEffect(() => {
    // Fetch current subscription price
    fetch('/api/subscription-price')
      .then(res => res.json())
      .then(data => setPriceInfo(data))
      .catch(err => console.error('Failed to fetch price:', err));
  }, []);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      // Create subscription on backend
      const response = await fetch("/api/auth/create-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          club: clubData,
          user: userData,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to create subscription");
      }

      // Confirm payment with Stripe
      const cardElement = elements.getElement(CardElement);
      if (!cardElement) {
        throw new Error("Card element not found");
      }

      const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(
        result.clientSecret,
        {
          payment_method: {
            card: cardElement,
            billing_details: {
              name: `${userData.firstName || ""} ${userData.lastName || ""}`.trim() || userData.username,
              email: userData.email,
            },
          },
        }
      );

      if (stripeError) {
        throw new Error(stripeError.message || "Payment failed");
      }

      if (paymentIntent?.status === "succeeded") {
        onSuccess({
          paymentIntent,
          subscription: result.subscription,
          user: result.user,
          club: result.club,
        });
      }
    } catch (err: any) {
      setError(err.message || "Payment failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl text-center">Complete Subscription</CardTitle>
          <CardDescription className="text-center">
            Enter your payment details to start your {priceInfo ? `£${priceInfo.amount}/${priceInfo.interval}` : 'subscription'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-4">
              <div className="p-4 border rounded-lg bg-gray-50 dark:bg-gray-800">
                <h3 className="font-semibold mb-2">Subscription Details</h3>
                <div className="text-sm space-y-1">
                  <p><strong>Club:</strong> {clubData.name}</p>
                  <p><strong>Location:</strong> {clubData.location}</p>
                  <p><strong>Plan:</strong> Premium Subscription</p>
                  <p><strong>Price:</strong> {priceInfo ? `£${priceInfo.amount}/${priceInfo.interval}` : 'Loading...'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Payment Information</label>
                <div className="p-3 border rounded-lg bg-white dark:bg-gray-900">
                  <CardElement
                    options={{
                      style: {
                        base: {
                          fontSize: "16px",
                          color: "#424770",
                          "::placeholder": {
                            color: "#aab7c4",
                          },
                        },
                      },
                    }}
                  />
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <div className="flex items-start space-x-2">
                  <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium">Premium Features Include:</p>
                    <ul className="list-disc list-inside mt-2 space-y-1 text-gray-600 dark:text-gray-300">
                      <li>Unlimited spray products and fertilizers</li>
                      <li>AI-powered compatibility analysis</li>
                      <li>Weather-integrated spray timing</li>
                      <li>Staff rota management</li>
                      <li>Application record tracking</li>
                      <li>Industry news and updates</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={onBack}
                disabled={isLoading}
                className="flex-1"
              >
                Back
              </Button>
              <Button
                type="submit"
                disabled={!stripe || isLoading}
                className="flex-1"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Subscribe Now"
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export function SubscriptionForm(props: SubscriptionFormProps) {
  return (
    <Elements stripe={stripePromise}>
      <CheckoutForm {...props} />
    </Elements>
  );
}