import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Search, Edit, Trash2, SprayCan } from "lucide-react";
import { insertSprayProductSchema, type SprayProduct } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { ProductSuggestionInput } from "@/components/product-suggestion-input";
import { ImageUpload } from "@/components/image-upload";
import { BatchProductUpload } from "@/components/batch-product-upload";

type FormData = z.infer<typeof insertSprayProductSchema>;

const formSchema = insertSprayProductSchema.extend({
  labelRate: z.string().min(1, "Label rate is required"),
  compatibilityNotes: z.string().optional(),
});

export function SprayProducts() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<SprayProduct | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      type: "",
      activeIngredient: "",
      labelRate: "",
      compatibilityNotes: "",
      imageUrl: "",
    },
  });

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["/api/spray-products"],
  });

  const createMutation = useMutation({
    mutationFn: (data: FormData) => apiRequest("POST", "/api/spray-products", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/spray-products"] });
      form.reset();
      setIsDialogOpen(false);
      toast({ title: "Product added successfully" });
    },
    onError: (error: any) => {
      // Handle duplicate product error specifically
      if (error.status === 409) {
        toast({
          title: "Product already added",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error adding product",
          description: error.message || "Please try again",
          variant: "destructive",
        });
      }
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: FormData }) =>
      apiRequest("PUT", `/api/spray-products/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/spray-products"] });
      form.reset();
      setIsDialogOpen(false);
      setEditingProduct(null);
      toast({ title: "Product updated successfully" });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating product",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/spray-products/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/spray-products"] });
      toast({ title: "Product deleted successfully" });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting product",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: FormData) => {
    if (editingProduct) {
      updateMutation.mutate({ id: editingProduct.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (product: SprayProduct) => {
    setEditingProduct(product);
    form.reset({
      name: product.name,
      type: product.type,
      activeIngredient: product.activeIngredient,
      labelRate: product.labelRate,
      compatibilityNotes: product.compatibilityNotes || "",
      imageUrl: product.imageUrl || "",
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleProductDetected = (product: any) => {
    console.log("Product detected, filling form:", product);
    form.setValue("name", product.name || "");
    form.setValue("type", product.type ? product.type.toLowerCase() : "");
    form.setValue("activeIngredient", product.activeIngredient || "");
    form.setValue("labelRate", product.labelRate || product.commonRate || "");
    form.setValue("brand", product.brand || "");
    form.setValue("compatibilityNotes", product.compatibilityNotes || "");
  };

  const filteredProducts = products
    .filter((product: SprayProduct) => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.activeIngredient.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = typeFilter === "all" || product.type === typeFilter;
      return matchesSearch && matchesType;
    })
    .sort((a: SprayProduct, b: SprayProduct) => a.name.localeCompare(b.name));

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "fungicide": return "bg-blue-100 text-blue-800";
      case "herbicide": return "bg-green-100 text-green-800";
      case "insecticide": return "bg-red-100 text-red-800";
      case "growth regulator": return "bg-purple-100 text-purple-800";
      case "wetting agent": return "bg-cyan-100 text-cyan-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Spray Products</h2>
            <p className="text-slate-600 mt-1">Loading...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-8 text-center">
            <div className="animate-pulse">Loading products...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Spray Products</h2>
          <p className="text-slate-600 mt-1">Manage your spray product inventory and compatibility information</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          <BatchProductUpload />
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="mr-2" size={16} />
                Add Product
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingProduct ? "Edit Spray Product" : "Add New Spray Product"}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Image</FormLabel>
                        <FormControl>
                          <ImageUpload
                            onProductDetected={handleProductDetected}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Name</FormLabel>
                        <FormControl>
                          <ProductSuggestionInput
                            value={field.value}
                            onChange={field.onChange}
                            onProductSelect={(product) => {
                              form.setValue("name", product.name);
                              form.setValue("type", product.type);
                              form.setValue("activeIngredient", product.activeIngredient);
                              form.setValue("labelRate", product.labelRate);
                              form.setValue("compatibilityNotes", product.compatibilityNotes || "");
                            }}
                            placeholder="Enter product name or search suggestions..."
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select product type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="fungicide">Fungicide</SelectItem>
                            <SelectItem value="herbicide">Herbicide</SelectItem>
                            <SelectItem value="insecticide">Insecticide</SelectItem>
                            <SelectItem value="growth regulator">Growth Regulator</SelectItem>
                            <SelectItem value="wetting agent">Wetting Agent</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="activeIngredient"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Active Ingredient</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., Glyphosate 360 g/L" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="labelRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Label Rate</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., 2-4 L/ha" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="compatibilityNotes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Compatibility Notes</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Enter compatibility information and mixing restrictions..."
                            rows={3}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex gap-3 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsDialogOpen(false);
                        setEditingProduct(null);
                        form.reset();
                      }}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createMutation.isPending || updateMutation.isPending}
                      className="flex-1"
                    >
                      {editingProduct ? "Update Product" : "Add Product"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4 border-b border-slate-200">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <label className="block text-sm font-medium text-slate-700 mb-2">Search Products</label>
              <div className="relative">
                <Input
                  placeholder="Search by name or type..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
                <Search className="absolute left-3 top-3 text-slate-400" size={16} />
              </div>
            </div>
            <div className="sm:w-48">
              <label className="block text-sm font-medium text-slate-700 mb-2">Filter by Type</label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="fungicide">Fungicide</SelectItem>
                  <SelectItem value="herbicide">Herbicide</SelectItem>
                  <SelectItem value="insecticide">Insecticide</SelectItem>
                  <SelectItem value="growth regulator">Growth Regulator</SelectItem>
                  <SelectItem value="wetting agent">Wetting Agent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Products Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left py-3 px-4 font-medium text-slate-700">Product Name</th>
                <th className="text-left py-3 px-4 font-medium text-slate-700">Type</th>
                <th className="text-left py-3 px-4 font-medium text-slate-700">Label Rate</th>
                <th className="text-left py-3 px-4 font-medium text-slate-700">Compatibility</th>
                <th className="text-left py-3 px-4 font-medium text-slate-700">Status</th>
                <th className="text-right py-3 px-4 font-medium text-slate-700">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 px-4 text-center text-slate-500">
                    No spray products found. Click "Add Product" to get started.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
                          <SprayCan className="text-primary" size={16} />
                        </div>
                        <div>
                          <div className="font-medium text-slate-900">{product.name}</div>
                          <div className="text-sm text-slate-500">{product.activeIngredient}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Badge className={getTypeColor(product.type)}>
                        {product.type}
                      </Badge>
                    </td>
                    <td className="py-4 px-4 text-slate-900">{product.labelRate}</td>
                    <td className="py-4 px-4">
                      <div className="text-sm text-slate-600 max-w-xs truncate">
                        {product.compatibilityNotes || "No notes"}
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Badge variant="outline" className="text-green-700 border-green-300">
                        Active
                      </Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(product)}
                          className="text-slate-600 hover:text-slate-900"
                        >
                          <Edit size={16} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(product.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}