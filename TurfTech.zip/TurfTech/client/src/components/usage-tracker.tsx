import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { BarChart3, TrendingUp, DollarSign, MapPin, Calendar, Droplets, Sprout, Target, Eye, Package, User, LogOut, Key, Shield } from "lucide-react";

interface SeasonalStats {
  totalApplications: number;
  totalCost: number;
  totalAreaTreated: number;
  mostUsedProduct: string;
  averageApplicationCost: number;
  recentApplications: number;
  applicationsByType: { [key: string]: number };
  costByMonth: { [key: string]: number };
  totalWaterUsed: number;
  topProducts: Array<{ name: string; count: number; cost: number }>;
  personalInsights: Array<{ text: string; type: 'rate' | 'cost' | 'timing' }>;
}

export function UsageTracker() {
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const { toast } = useToast();

  // Get user data from localStorage
  const userData = localStorage.getItem("user_data");
  const clubData = localStorage.getItem("club_data");
  const user = userData ? JSON.parse(userData) : null;
  const club = clubData ? JSON.parse(clubData) : null;

  // Fetch real application records data
  const { data: applicationRecords } = useQuery({
    queryKey: ['/api/application-records'],
  });

  const handleLogout = () => {
    localStorage.removeItem("auth_token");
    localStorage.removeItem("user_data");
    localStorage.removeItem("club_data");
    window.location.reload();
  };

  const handlePasswordChange = async () => {
    if (newPassword !== confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords don't match",
        variant: "destructive",
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "Error", 
        description: "Password must be at least 6 characters",
        variant: "destructive",
      });
      return;
    }

    setIsChangingPassword(true);

    try {
      const response = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("auth_token")}`
        },
        body: JSON.stringify({
          currentPassword,
          newPassword
        }),
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Password changed successfully",
        });
        setPasswordDialogOpen(false);
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
      } else {
        const result = await response.json();
        toast({
          title: "Error",
          description: result.message || "Failed to change password",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to change password",
        variant: "destructive",
      });
    } finally {
      setIsChangingPassword(false);
    }
  };

  // Calculate comprehensive usage statistics
  const calculateUsageStats = (): SeasonalStats => {
    if (!applicationRecords || !Array.isArray(applicationRecords)) {
      return {
        totalApplications: 0,
        totalCost: 0,
        totalAreaTreated: 0,
        mostUsedProduct: "No data",
        averageApplicationCost: 0,
        recentApplications: 0,
        applicationsByType: {},
        costByMonth: {},
        totalWaterUsed: 0,
        personalInsights: [],
        topProducts: []
      };
    }

    const totalApplications = applicationRecords.length;
    
    // Extract cost and area data from productDetails JSON
    const totalCost = applicationRecords.reduce((sum: number, record: any) => {
      try {
        if (record.productDetails) {
          const details = JSON.parse(record.productDetails);
          const jobCost = details.costSummary?.totalJobCost || 0;
          return sum + parseFloat(jobCost.toString());
        }
      } catch (e) {
        console.warn('Failed to parse productDetails:', e);
      }
      return sum;
    }, 0);
    
    const totalAreaTreated = applicationRecords.reduce((sum: number, record: any) => {
      try {
        if (record.productDetails) {
          const details = JSON.parse(record.productDetails);
          const water = details.tankMixSummary?.totalWater || 0;
          const rate = details.tankMixSummary?.applicationRate || 750;
          const area = water / rate; // Calculate area from water volume and rate
          return sum + area;
        }
      } catch (e) {
        console.warn('Failed to parse productDetails:', e);
      }
      return sum;
    }, 0);

    // Recent applications (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const recentApplications = applicationRecords.filter((record: any) => {
      if (!record.date) return false;
      const recordDate = new Date(record.date);
      return recordDate >= thirtyDaysAgo;
    }).length;

    // Applications by type/category
    const applicationsByType: { [key: string]: number } = {};
    const productCosts: { [key: string]: { count: number; cost: number } } = {};
    const costByMonth: { [key: string]: number } = {};

    applicationRecords.forEach((record: any) => {
      try {
        // Extract products from JSON structure
        if (record.productDetails) {
          const details = JSON.parse(record.productDetails);
          const products = details.products || [];
          const totalJobCost = details.costSummary?.totalJobCost || 0;
          
          // Track each product in the application
          products.forEach((product: any) => {
            const productName = product.name || 'Unknown Product';
            applicationsByType[productName] = (applicationsByType[productName] || 0) + 1;
            
            if (!productCosts[productName]) {
              productCosts[productName] = { count: 0, cost: 0 };
            }
            productCosts[productName].count += 1;
            // Distribute cost proportionally among products
            productCosts[productName].cost += totalJobCost / products.length;
          });
        }

        // Cost by month using actual job costs
        if (record.date && record.productDetails) {
          const month = new Date(record.date).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' });
          const details = JSON.parse(record.productDetails);
          const jobCost = details.costSummary?.totalJobCost || 0;
          costByMonth[month] = (costByMonth[month] || 0) + jobCost;
        }
      } catch (e) {
        console.warn('Failed to parse product details:', e);
        // Fallback to simple product string if JSON parsing fails
        if (record.products) {
          const productNames = record.products.split(', ');
          productNames.forEach((name: string) => {
            applicationsByType[name] = (applicationsByType[name] || 0) + 1;
          });
        }
      }
    });

    // Top products by usage
    const topProducts = Object.entries(productCosts)
      .map(([name, data]) => ({ 
        name, 
        count: data.count, 
        cost: data.cost 
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Most used product
    const mostUsedProduct = topProducts.length > 0 ? topProducts[0].name : "No data";

    // Water usage calculation from actual tank mix data
    const totalWaterUsed = applicationRecords.reduce((sum: number, record: any) => {
      try {
        if (record.productDetails) {
          const details = JSON.parse(record.productDetails);
          const totalWater = details.tankMixSummary?.totalWater || 0;
          return sum + parseFloat(totalWater.toString());
        }
      } catch (e) {
        console.warn('Failed to parse water data:', e);
      }
      return sum;
    }, 0);

    const averageApplicationCost = totalApplications > 0 ? totalCost / totalApplications : 0;

    // Generate Personal Insights based on actual data
    const personalInsights: Array<{ text: string; type: 'rate' | 'cost' | 'timing' }> = [];
    
    // Rate insights for Primo Maxx based on actual usage
    const primoApplications = applicationRecords.filter(record => 
      record.products && record.products.includes('Primo Maxx')
    );
    
    if (primoApplications.length > 0) {
      try {
        const avgPrimoRate = primoApplications.reduce((sum, record) => {
          const details = JSON.parse(record.productDetails || '{}');
          const primoProduct = details.products?.find((p: any) => p.name?.includes('Primo Maxx'));
          return sum + (primoProduct?.amount || 0);
        }, 0) / primoApplications.length;
        
        personalInsights.push({
          text: `Your typical Primo Maxx rate: ${(avgPrimoRate * 1000).toFixed(0)} ml/ha - ideal for selective growth regulation`,
          type: 'rate'
        });
      } catch (e) {
        console.warn('Failed to calculate Primo Maxx rate:', e);
      }
    }
    
    // Cost insights based on actual application costs
    if (averageApplicationCost > 200) {
      personalInsights.push({
        text: `High-value applications averaging £${averageApplicationCost.toFixed(0)} - consider split applications for better cost efficiency`,
        type: 'cost'
      });
    }
    
    // Timing insights based on seasonal activity
    const currentMonth = new Date().getMonth();
    const isGrowingSeason = currentMonth >= 3 && currentMonth <= 9; // April to October
    if (isGrowingSeason && recentApplications > 0) {
      personalInsights.push({
        text: `Active growing season applications - your timing aligns well with turf growth patterns`,
        type: 'timing'
      });
    }

    return {
      totalApplications,
      totalCost,
      totalAreaTreated,
      mostUsedProduct,
      averageApplicationCost,
      recentApplications,
      applicationsByType,
      costByMonth,
      totalWaterUsed,
      topProducts,
      personalInsights
    };
  };

  const stats = calculateUsageStats();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Usage Analytics
          </CardTitle>
          <CardDescription>
            Track product usage, costs, and application statistics in real-time
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Main Statistics Grid */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalApplications}</div>
                <p className="text-xs text-muted-foreground">
                  <Badge variant="secondary" className="mt-1">
                    {stats.recentApplications} last 30 days
                  </Badge>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Cost</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">£{stats.totalCost.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">Spray & fertilizer combined</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Area Treated</CardTitle>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalAreaTreated.toFixed(1)} ha</div>
                <p className="text-xs text-muted-foreground">Total area coverage</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Water Used</CardTitle>
                <Droplets className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{(stats.totalWaterUsed / 1000).toFixed(1)}k L</div>
                <p className="text-xs text-muted-foreground">Total water consumption</p>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analytics */}
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {/* Top Products */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Droplets className="h-5 w-5" />
                  Top Products by Usage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.topProducts.length > 0 ? (
                    stats.topProducts.map((product, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="font-medium">{product.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {product.count} applications • £{product.cost.toFixed(2)}
                          </div>
                        </div>
                        <Badge variant={index === 0 ? "default" : "secondary"}>
                          #{index + 1}
                        </Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground">No product data available</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Monthly Cost Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Monthly Cost Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(stats.costByMonth).length > 0 ? (
                    Object.entries(stats.costByMonth)
                      .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime())
                      .slice(-6) // Show last 6 months
                      .map(([month, cost]) => (
                        <div key={month} className="flex items-center justify-between">
                          <div className="font-medium">{month}</div>
                          <div className="text-right">
                            <div className="font-semibold">£{cost.toFixed(2)}</div>
                            <Progress 
                              value={(cost / Math.max(...Object.values(stats.costByMonth))) * 100} 
                              className="w-16 h-2 mt-1"
                            />
                          </div>
                        </div>
                      ))
                  ) : (
                    <p className="text-muted-foreground">No monthly data available</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Personal Insights Section */}
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Eye className="h-5 w-5 text-purple-600" />
                  Personal Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.personalInsights.length > 0 ? (
                    stats.personalInsights.map((insight, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 dark:bg-purple-950/30">
                        <div className="w-2 h-2 rounded-full bg-purple-500 mt-2 flex-shrink-0"></div>
                        <p className="text-sm text-purple-800 dark:text-purple-200 leading-relaxed">
                          {insight.text}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-sm">
                      Complete more applications to see personalized insights based on your usage patterns.
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Product This Season */}
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Package className="h-5 w-5 text-orange-600" />
                  Top Product This Season
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-lg">{stats.mostUsedProduct}</div>
                    <p className="text-sm text-muted-foreground">Most frequently applied product</p>
                  </div>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200">
                    #1
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Key Metrics Summary */}
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Average Cost per Application</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-semibold text-blue-600">£{stats.averageApplicationCost.toFixed(2)}</div>
                <p className="text-sm text-muted-foreground mt-1">Including materials & labor</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Application Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-semibold text-purple-600">
                  {((stats.recentApplications / 30) * 7).toFixed(1)}/week
                </div>
                <p className="text-sm text-muted-foreground mt-1">Average weekly rate</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Water Efficiency</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-semibold text-cyan-600">
                  {stats.totalAreaTreated > 0 ? (stats.totalWaterUsed / stats.totalAreaTreated).toFixed(0) : '750'} L/ha
                </div>
                <p className="text-sm text-muted-foreground mt-1">Average water usage rate</p>
              </CardContent>
            </Card>
          </div>

          {/* User Profile & Account Management */}
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <User className="h-5 w-5 text-blue-600" />
                  Account Management
                </CardTitle>
                <CardDescription>
                  Manage your profile, security settings, and session preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* User Info */}
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <div className="font-semibold">{user?.username || "Unknown User"}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">{user?.email || "No email"}</div>
                      <div className="text-xs text-green-600 dark:text-green-400 mt-1">
                        Club: {club?.name || "Unknown Club"} ({club?.location || "Unknown Location"})
                      </div>
                      {club?.subscriptionStatus === "grandfathered_active" && (
                        <Badge variant="secondary" className="mt-1 bg-gold-100 text-gold-800">
                          <Shield className="h-3 w-3 mr-1" />
                          Grandfathered Premium
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Account Actions */}
                  <div className="flex flex-wrap gap-3">
                    <Dialog open={passwordDialogOpen} onOpenChange={setPasswordDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Key className="h-4 w-4 mr-2" />
                          Change Password
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Change Password</DialogTitle>
                          <DialogDescription>
                            Enter your current password and choose a new one. Make sure it's at least 6 characters long.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="currentPassword">Current Password</Label>
                            <Input
                              id="currentPassword"
                              type="password"
                              value={currentPassword}
                              onChange={(e) => setCurrentPassword(e.target.value)}
                              placeholder="Enter current password"
                            />
                          </div>
                          <div>
                            <Label htmlFor="newPassword">New Password</Label>
                            <Input
                              id="newPassword"
                              type="password"
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                              placeholder="Enter new password"
                            />
                          </div>
                          <div>
                            <Label htmlFor="confirmPassword">Confirm New Password</Label>
                            <Input
                              id="confirmPassword"
                              type="password"
                              value={confirmPassword}
                              onChange={(e) => setConfirmPassword(e.target.value)}
                              placeholder="Confirm new password"
                            />
                          </div>
                          <div className="flex gap-3">
                            <Button
                              onClick={handlePasswordChange}
                              disabled={isChangingPassword || !currentPassword || !newPassword || !confirmPassword}
                              className="flex-1"
                            >
                              {isChangingPassword ? "Changing..." : "Change Password"}
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => setPasswordDialogOpen(false)}
                              className="flex-1"
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button variant="outline" size="sm" onClick={handleLogout}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </Button>
                  </div>

                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Session will remain active until you sign out. For security, we recommend signing out on shared devices.
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}