import { Button } from "@/components/ui/button";
import { TrendingUp, User, Leaf, Clock } from "lucide-react";
import { WeatherPreview } from "./weather-preview";
import { useState, useEffect } from "react";

export function Header() {
  const [ukTime, setUkTime] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const ukTimeString = now.toLocaleString('en-GB', {
        timeZone: 'Europe/London',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      });
      setUkTime(ukTimeString);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const handleUsageAnalytics = () => {
    window.dispatchEvent(new CustomEvent('show-usage-analytics'));
  };

  return (
    <header className="bg-white shadow-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16">
          <div className="flex items-center space-x-2 sm:space-x-3 min-w-0">
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('navigate-to-spray-products'))}
              className="bg-primary p-1.5 sm:p-2 rounded-lg flex-shrink-0 hover:bg-primary/90 transition-colors"
            >
              <Leaf className="text-white" size={16} />
            </button>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-lg font-bold text-slate-900 truncate">
                <span className="sm:hidden">TurfAI</span>
                <span className="hidden sm:inline">GreenKeeper Pro</span>
              </h1>
              <p className="text-xs text-slate-600 hidden sm:block">Golf Course Management</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-1 sm:space-x-3 overflow-x-auto">
            {/* UK Time Display */}
            <div className="hidden lg:flex items-center bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 flex-shrink-0">
              <Clock className="text-slate-500 mr-2" size={14} />
              <div className="text-center">
                <div className="text-xs text-slate-500 font-medium leading-none">UK TIME</div>
                <div className="text-sm font-mono font-bold text-slate-900 leading-none mt-1">{ukTime}</div>
              </div>
            </div>
            
            <div className="flex-shrink-0">
              <WeatherPreview location="Dullatur, Cumbernauld, Scotland, GB" />
            </div>
            
            <Button 
              onClick={handleUsageAnalytics}
              className="bg-primary hover:bg-primary/90 text-white text-xs sm:text-sm flex-shrink-0"
              size="sm"
            >
              <span className="hidden sm:inline">
                Usage Analytics
              </span>
              <span className="sm:hidden text-xs w-6 h-6 flex items-center justify-center">
                📖
              </span>
            </Button>
            

          </div>
        </div>
      </div>
    </header>
  );
}
