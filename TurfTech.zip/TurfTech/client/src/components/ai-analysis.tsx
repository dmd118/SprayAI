import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Brain, CheckCircle, AlertTriangle, XCircle, Save, Printer, Plus, X, Cloud, Thermometer, Wind, MessageCircle, Send, User, Bot, Camera, Image, Paperclip } from "lucide-react";
import { type SprayProduct, type TurfArea, type InsertApplicationRecord } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { formatCompatibilityStatus, type AIAnalysisResult } from "@/lib/openai";
import { WATER_VOLUMES, NOZZLE_TYPES, BAR_PRESSURES, NOZZLE_FLOW_RATES, SPRAY_RECOMMENDATIONS, PRESSURE_GUIDE, parseWaterVolume, calculateWaterNeeded } from "@/lib/calculations";
import { CostCalculator } from "./cost-calculator";

interface ProductSelection {
  productId: number;
  rate: string;
  unit: string;
}

export function AIAnalysis() {
  const { toast } = useToast();
  const [selectedProducts, setSelectedProducts] = useState<ProductSelection[]>([]);
  const [selectedAreaIds, setSelectedAreaIds] = useState<number[]>([]);
  const [waterVolume, setWaterVolume] = useState<string>("200 L/ha");
  const [customWaterVolume, setCustomWaterVolume] = useState<string>("");
  const [isCustomWaterVolume, setIsCustomWaterVolume] = useState<boolean>(false);
  const [location, setLocation] = useState("Dullatur Golf Club, Cumbernauld, UK");
  const [nozzleType, setNozzleType] = useState<string>("");
  const [barPressure, setBarPressure] = useState<string>("");
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Chat functionality state
  const [chatMessages, setChatMessages] = useState<Array<{id: string, role: 'user' | 'assistant', content: string, image?: string, timestamp: Date}>>([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages are added (but not on initial load)
  useEffect(() => {
    if (chatMessages.length > 0 && chatContainerRef.current) {
      // Small delay to ensure the DOM has updated
      setTimeout(() => {
        const container = chatContainerRef.current;
        if (container) {
          container.scrollTop = container.scrollHeight;
        }
      }, 100);
    }
  }, [chatMessages.length]); // Only trigger when the number of messages changes

  // Handle image upload
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setUploadedImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  // Send chat message to expert greenkeeper
  const sendChatMessage = async () => {
    if ((!chatInput.trim() && !uploadedImage) || isChatLoading) return;
    
    const userMessage = {
      id: Date.now().toString(),
      role: 'user' as const,
      content: chatInput.trim() || (uploadedImage ? "Please analyze this image" : ""),
      image: uploadedImage || undefined,
      timestamp: new Date()
    };
    
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput("");
    setUploadedImage(null);
    setIsChatLoading(true);
    
    try {
      const response = await fetch("/api/expert-greenkeeper-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: userMessage.content,
          image: userMessage.image,
          conversationHistory: chatMessages.slice(-10) // Last 10 messages for context
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        const assistantMessage = {
          id: (Date.now() + 1).toString(),
          role: 'assistant' as const,
          content: data.response,
          image: data.generatedImage,
          timestamp: new Date()
        };
        setChatMessages(prev => [...prev, assistantMessage]);
      } else {
        toast({ title: "Failed to get response from expert greenkeeper", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error communicating with expert greenkeeper", variant: "destructive" });
    } finally {
      setIsChatLoading(false);
    }
  };

  const { data: products = [] } = useQuery<SprayProduct[]>({
    queryKey: ["/api/spray-products"],
  });

  const { data: areas = [] } = useQuery<TurfArea[]>({
    queryKey: ["/api/turf-areas"],
  });

  const { data: weatherData } = useQuery({
    queryKey: ["/api/weather", location],
    queryFn: () => fetch(`/api/weather?location=${encodeURIComponent(location)}`).then(res => res.json()),
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const createRecordMutation = useMutation({
    mutationFn: (record: InsertApplicationRecord) => 
      apiRequest("POST", "/api/application-records", record),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/application-records"] });
      toast({ title: "Application record saved successfully" });
    },
    onError: () => {
      toast({ title: "Failed to save application record", variant: "destructive" });
    },
  });

  const analyzeMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/ai-analysis", data);
      return response.json();
    },
    onSuccess: (data) => {
      setAnalysis(data.analysis);
      setIsAnalyzing(false);
      toast({ title: "AI analysis completed" });
    },
    onError: () => {
      setIsAnalyzing(false);
      toast({ title: "Failed to perform AI analysis", variant: "destructive" });
    },
  });

  const addProduct = () => {
    setSelectedProducts([...selectedProducts, { productId: 0, rate: "", unit: "L/ha" }]);
  };

  const removeProduct = (index: number) => {
    setSelectedProducts(selectedProducts.filter((_, i) => i !== index));
  };

  const updateProduct = (index: number, updates: Partial<ProductSelection>) => {
    setSelectedProducts(selectedProducts.map((product, i) => 
      i === index ? { ...product, ...updates } : product
    ));
  };

  const toggleArea = (areaId: number) => {
    setSelectedAreaIds(prev => 
      prev.includes(areaId) 
        ? prev.filter(id => id !== areaId)
        : [...prev, areaId]
    );
  };

  const handleWaterVolumeChange = (value: string) => {
    if (value === "custom") {
      setIsCustomWaterVolume(true);
      setWaterVolume("");
    } else {
      setIsCustomWaterVolume(false);
      setWaterVolume(value);
      setCustomWaterVolume("");
    }
  };

  const getEffectiveWaterVolume = () => {
    return isCustomWaterVolume ? customWaterVolume : waterVolume;
  };

  const handleAnalyze = async () => {
    const effectiveWaterVolume = getEffectiveWaterVolume();
    
    if (selectedProducts.length === 0 || selectedAreaIds.length === 0 || !effectiveWaterVolume || !nozzleType || !barPressure) {
      toast({ title: "Please select at least one product and area, and fill in all parameters", variant: "destructive" });
      return;
    }

    const incompleteProducts = selectedProducts.some(p => !p.productId || !p.rate);
    if (incompleteProducts) {
      toast({ title: "Please complete all product selections and rates", variant: "destructive" });
      return;
    }

    setIsAnalyzing(true);
    const productIds = selectedProducts.map(p => p.productId);

    // Include current weather data in analysis for intelligent recommendations
    let currentWeather = null;
    if (weatherData?.weather) {
      currentWeather = weatherData.weather;
    }

    analyzeMutation.mutate({
      productIds,
      targetAreaIds: selectedAreaIds,
      waterVolume: effectiveWaterVolume,
      nozzleType,
      barPressure,
      location,
      weatherData: currentWeather
    });
  };

  const handleSaveAnalysis = () => {
    if (!analysis || selectedAreaIds.length === 0) return;

    const selectedAreas = areas.filter(a => selectedAreaIds.includes(a.id));
    const selectedProductObjs = selectedProducts
      .map(p => products.find(prod => prod.id === p.productId))
      .filter(Boolean);

    const productNames = selectedProductObjs.map(p => p!.name).join(" + ");
    const productDetails = selectedProductObjs.map(p => `${p!.type}`).join(" + ");
    const areaNames = selectedAreas.map(a => a.name).join(", ");

    const record: InsertApplicationRecord = {
      date: new Date(),
      type: "Spray",
      products: productNames,
      productDetails,
      areaId: selectedAreas[0].id, // Use first area for compatibility
      areaName: areaNames,
      rate: waterVolume,
      weather: "Clear, 22°C",
      waterVolume,
      notes: `AI Analysis: ${analysis.compatibility.status}. Applied to ${selectedAreas.length} areas.`,
    };

    createRecordMutation.mutate(record);
  };

  const handlePrint = () => {
    window.print();
  };

  const selectedAreas = areas.filter(a => selectedAreaIds.includes(a.id));
  const compatibilityStyle = analysis ? formatCompatibilityStatus(analysis.compatibility.status) : null;

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900">AI Spray Analysis</h2>
        <p className="text-slate-600 mt-1">Get AI-powered compatibility analysis and application calculations</p>
      </div>

      {/* Expert Greenkeeper Chat */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="text-green-600" size={20} />
            Expert Greenkeeper Assistant
          </CardTitle>
          <p className="text-sm text-green-700">Ask our AI expert about turf management, product compatibility, timing, and chemical applications</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Chat Messages */}
            <div ref={chatContainerRef} className="h-64 overflow-y-auto border rounded-lg bg-white p-4 space-y-3">
              {chatMessages.length === 0 ? (
                <div className="flex items-center justify-center h-full text-slate-500">
                  <div className="text-center">
                    <Bot size={32} className="mx-auto mb-2 text-green-500" />
                    <p className="text-sm">Hello! I'm your expert greenkeeper assistant.</p>
                    <p className="text-xs">Ask me about products, timing, weather considerations, or any turf management questions!</p>
                  </div>
                </div>
              ) : (
                chatMessages.map((message) => (
                  <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-lg ${
                      message.role === 'user' 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-green-100 text-green-900 border border-green-200'
                    }`}>
                      <div className="flex items-start gap-2">
                        {message.role === 'assistant' && <Bot size={16} className="text-green-600 mt-1 flex-shrink-0" />}
                        <div className="flex-1">
                          {message.image && (
                            <img 
                              src={message.image} 
                              alt="Uploaded turf analysis" 
                              className="max-w-full h-auto rounded mb-2 max-h-48 object-cover"
                            />
                          )}
                          <div className="text-sm whitespace-pre-wrap">{message.content}</div>
                        </div>
                        {message.role === 'user' && <User size={16} className="text-blue-200 mt-1 flex-shrink-0" />}
                      </div>
                      <div className={`text-xs mt-1 ${message.role === 'user' ? 'text-blue-200' : 'text-green-600'}`}>
                        {message.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                ))
              )}
              {isChatLoading && (
                <div className="flex justify-start">
                  <div className="bg-green-100 text-green-900 border border-green-200 p-3 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Bot size={16} className="text-green-600" />
                      <div className="text-sm">Expert is thinking...</div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatMessagesEndRef} />
            </div>
            
            {/* Image Preview */}
            {uploadedImage && (
              <div className="relative inline-block">
                <img 
                  src={uploadedImage} 
                  alt="Upload preview" 
                  className="max-h-32 rounded border"
                />
                <Button
                  size="sm"
                  variant="destructive"
                  className="absolute -top-2 -right-2"
                  onClick={() => setUploadedImage(null)}
                >
                  <X size={12} />
                </Button>
              </div>
            )}
            
            {/* Chat Input */}
            <div className="flex gap-2">
              <div className="flex gap-1">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('image-upload')?.click()}
                  disabled={isChatLoading}
                  className="px-3"
                >
                  <Camera size={16} />
                </Button>
              </div>
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about products, timing, weather, chemical compatibility..."
                className="flex-1"
                onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendChatMessage()}
                disabled={isChatLoading}
              />
              <Button
                onClick={sendChatMessage}
                disabled={(!chatInput.trim() && !uploadedImage) || isChatLoading}
                className="bg-green-600 hover:bg-green-700"
              >
                <Send size={16} />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Product Selection */}
        <div className="space-y-6">
          {/* Weather Conditions */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Cloud className="text-white" size={16} />
                </div>
                <CardTitle>Current Weather</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700 mb-2 block">Location</label>
                  <Input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Enter location (e.g., Glasgow, UK)"
                    className="w-full"
                  />
                </div>
                
                {weatherData?.weather && (
                  <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Thermometer size={16} className="text-red-500" />
                      <span className="text-sm">{weatherData.weather.temperature}°C</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Cloud size={16} className="text-gray-500" />
                      <span className="text-sm">{weatherData.weather.precipitation || 0}% rain</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Wind size={16} className="text-blue-500" />
                      <span className="text-sm">{weatherData.weather.windSpeed} km/h</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-slate-500">💧 {weatherData.weather.humidity}%</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-sm text-slate-600 capitalize">{weatherData.weather.description}</span>
                    </div>
                  </div>
                )}
                
                {weatherData?.recommendations && weatherData.recommendations.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-slate-700">Weather-based Recommendations:</h4>
                    <ul className="space-y-1">
                      {weatherData.recommendations.map((rec: string, index: number) => (
                        <li key={index} className="text-xs text-slate-600 flex items-start space-x-2">
                          <span className="text-blue-500 mt-1">•</span>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Select Products to Mix</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between mb-3">
                <label className="block text-sm font-medium text-slate-700">Selected Products</label>
                <Button variant="outline" size="sm" onClick={addProduct}>
                  <Plus className="mr-1" size={14} />
                  Add Product
                </Button>
              </div>

              {selectedProducts.length === 0 ? (
                <div className="text-center py-8 text-slate-500 border-2 border-dashed border-slate-200 rounded-lg">
                  <p>No products selected</p>
                  <p className="text-sm">Click "Add Product" to get started</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {selectedProducts.map((product, index) => (
                    <div key={index} className="border border-slate-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <label className="block text-sm font-medium text-slate-700">
                          Product {index + 1}
                        </label>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => removeProduct(index)}
                          className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                        >
                          <X size={12} />
                        </Button>
                      </div>
                      
                      <Select 
                        value={product.productId.toString()} 
                        onValueChange={(value) => updateProduct(index, { productId: parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select product..." />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map((prod) => (
                            <SelectItem key={prod.id} value={prod.id.toString()}>
                              {prod.name} ({prod.type})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      
                      <div className="mt-2">
                        <label className="block text-sm text-slate-600 mb-1">Application Rate</label>
                        <div className="flex space-x-2">
                          <Input 
                            type="number" 
                            placeholder="2.5" 
                            value={product.rate}
                            onChange={(e) => updateProduct(index, { rate: e.target.value })}
                            className="flex-1"
                          />
                          <Select 
                            value={product.unit}
                            onValueChange={(value) => updateProduct(index, { unit: value })}
                          >
                            <SelectTrigger className="w-40">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="L/ha">L/ha</SelectItem>
                              <SelectItem value="ml/ha">ml/ha</SelectItem>
                              <SelectItem value="fl oz/1000 sq ft">fl oz/1000 sq ft</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Application Parameters */}
          <Card>
            <CardHeader>
              <CardTitle>Application Parameters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-slate-700">Target Areas</label>
                    <div className="flex space-x-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const individualAreas = areas.filter(area => !area.name.includes('Total'));
                          setSelectedAreaIds(individualAreas.map(area => area.id));
                        }}
                        className="text-xs h-7"
                      >
                        Select All
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedAreaIds([])}
                        className="text-xs h-7"
                      >
                        Clear All
                      </Button>
                    </div>
                  </div>
                  
                  {/* Quick Select by Type */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {['Tees', 'Greens', 'Fairways', 'Rough'].map((type) => {
                      const typeAreas = areas.filter(area => area.type === type && !area.name.includes('Total'));
                      if (typeAreas.length === 0) return null;
                      
                      const allSelected = typeAreas.every(area => selectedAreaIds.includes(area.id));
                      
                      return (
                        <Button
                          key={type}
                          type="button"
                          variant={allSelected ? "default" : "outline"}
                          size="sm"
                          onClick={() => {
                            if (allSelected) {
                              // Deselect all of this type
                              setSelectedAreaIds(prev => prev.filter(id => !typeAreas.map(a => a.id).includes(id)));
                            } else {
                              // Select all of this type
                              setSelectedAreaIds(prev => Array.from(new Set([...prev, ...typeAreas.map(a => a.id)])));
                            }
                          }}
                          className="text-xs h-7"
                        >
                          {type} ({typeAreas.length})
                        </Button>
                      );
                    })}
                  </div>
                  
                  <div className="border border-slate-200 rounded-lg p-3 max-h-64 overflow-y-auto">
                    {areas.filter(area => !area.name.includes('Total')).length === 0 ? (
                      <p className="text-slate-500 text-sm">No areas available</p>
                    ) : (
                      <div className="space-y-4">
                        {['Tees', 'Greens', 'Fairways', 'Rough'].map((type) => {
                          const typeAreas = areas
                            .filter(area => area.type === type && !area.name.includes('Total'))
                            .sort((a, b) => {
                              const aHole = parseInt(a.name.match(/\d+/)?.[0] || '999');
                              const bHole = parseInt(b.name.match(/\d+/)?.[0] || '999');
                              return aHole - bHole;
                            });
                          
                          if (typeAreas.length === 0) return null;
                          
                          return (
                            <div key={type}>
                              <h4 className="text-sm font-medium text-slate-700 mb-2 flex items-center">
                                <span className={`w-2 h-2 rounded-full mr-2 ${
                                  type === 'Tees' ? 'bg-blue-500' :
                                  type === 'Greens' ? 'bg-green-500' :
                                  type === 'Fairways' ? 'bg-yellow-500' : 'bg-gray-500'
                                }`}></span>
                                {type}
                              </h4>
                              <div className="grid grid-cols-1 gap-2 ml-4">
                                {typeAreas.map((area) => (
                                  <div key={area.id} className="flex items-center space-x-2">
                                    <Checkbox
                                      id={`area-${area.id}`}
                                      checked={selectedAreaIds.includes(area.id)}
                                      onCheckedChange={() => toggleArea(area.id)}
                                    />
                                    <label 
                                      htmlFor={`area-${area.id}`} 
                                      className="text-sm cursor-pointer flex-1 truncate"
                                    >
                                      {area.name.replace(`${type.slice(0, -1)} `, '')} 
                                      <span className="text-slate-500">({area.hectares.toFixed(3)} ha)</span>
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                  {selectedAreaIds.length > 0 && (
                    <div className="mt-2">
                      <div className="text-xs text-slate-600">
                        Selected: {selectedAreaIds.length} areas
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedAreas.slice(0, 3).map((area) => (
                          <Badge key={area.id} variant="secondary" className="text-xs">
                            {area.name}
                          </Badge>
                        ))}
                        {selectedAreas.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{selectedAreas.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Water Volume</label>
                  <Select value={isCustomWaterVolume ? "custom" : waterVolume} onValueChange={handleWaterVolumeChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {WATER_VOLUMES.map((volume) => (
                        <SelectItem key={volume.value} value={volume.value}>
                          {volume.label}
                        </SelectItem>
                      ))}
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                  {isCustomWaterVolume && (
                    <div className="mt-2">
                      <Input
                        type="text"
                        placeholder="e.g. 250 L/ha or 100 gal/acre"
                        value={customWaterVolume}
                        onChange={(e) => setCustomWaterVolume(e.target.value)}
                        className="w-full"
                      />
                      <p className="text-xs text-slate-500 mt-1">
                        Include units (e.g. L/ha, gal/acre, ml/m²)
                      </p>
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Nozzle Type</label>
                  <Select value={nozzleType} onValueChange={setNozzleType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select nozzle..." />
                    </SelectTrigger>
                    <SelectContent>
                      {NOZZLE_TYPES.map((nozzle) => (
                        <SelectItem key={nozzle} value={nozzle}>
                          {nozzle}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Bar Pressure</label>
                  <Select value={barPressure} onValueChange={setBarPressure}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select pressure..." />
                    </SelectTrigger>
                    <SelectContent>
                      {BAR_PRESSURES.map((pressure) => (
                        <SelectItem key={pressure} value={pressure}>
                          {pressure}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                className="w-full mt-6 bg-primary hover:bg-primary/90" 
                onClick={handleAnalyze}
                disabled={isAnalyzing || analyzeMutation.isPending}
              >
                {isAnalyzing ? (
                  <Brain className="mr-2 animate-spin" size={16} />
                ) : (
                  <Brain className="mr-2" size={16} />
                )}
                {isAnalyzing ? "Analyzing..." : "Analyze Compatibility & Calculate"}
              </Button>
            </CardContent>
          </Card>

          {/* Nozzle Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Spray Setup Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              {nozzleType && barPressure && (
                <div className="space-y-4">
                  {/* Current Setup */}
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-medium text-slate-900 mb-2">Current Setup</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-slate-600">Nozzle:</span>
                        <div className="font-medium">{nozzleType.split(' - ')[0]}</div>
                      </div>
                      <div>
                        <span className="text-sm text-slate-600">Pressure:</span>
                        <div className="font-medium">{barPressure}</div>
                      </div>
                      {NOZZLE_FLOW_RATES[nozzleType.split(' - ')[0] as keyof typeof NOZZLE_FLOW_RATES] && (
                        <>
                          <div>
                            <span className="text-sm text-slate-600">Flow Rate:</span>
                            <div className="font-medium">
                              {NOZZLE_FLOW_RATES[nozzleType.split(' - ')[0] as keyof typeof NOZZLE_FLOW_RATES][barPressure as keyof typeof NOZZLE_FLOW_RATES['Yellow 02']]} L/min
                            </div>
                          </div>
                          <div>
                            <span className="text-sm text-slate-600">Droplet Size:</span>
                            <div className="font-medium">
                              {PRESSURE_GUIDE[barPressure as keyof typeof PRESSURE_GUIDE]?.dropletSize}
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Weather-based warnings */}
                  {weatherData?.weather && (
                    <div className="space-y-2">
                      {weatherData.weather.windSpeed > parseInt(PRESSURE_GUIDE[barPressure as keyof typeof PRESSURE_GUIDE]?.windLimit || "15") && (
                        <div className="flex items-start space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                          <AlertTriangle className="text-red-600 mt-0.5" size={16} />
                          <div>
                            <div className="text-sm font-medium text-red-800">Wind Warning</div>
                            <div className="text-xs text-red-700">
                              Current wind ({weatherData.weather.windSpeed} km/h) exceeds safe limit for {barPressure} 
                              (max {PRESSURE_GUIDE[barPressure as keyof typeof PRESSURE_GUIDE]?.windLimit}). 
                              Consider reducing pressure or postponing spray.
                            </div>
                          </div>
                        </div>
                      )}
                      {weatherData.weather.windSpeed <= parseInt(PRESSURE_GUIDE[barPressure as keyof typeof PRESSURE_GUIDE]?.windLimit || "15") && (
                        <div className="flex items-start space-x-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                          <CheckCircle className="text-green-600 mt-0.5" size={16} />
                          <div>
                            <div className="text-sm font-medium text-green-800">Good Spray Conditions</div>
                            <div className="text-xs text-green-700">
                              Wind conditions are suitable for {barPressure} spray application.
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Product-based recommendations */}
                  {selectedProducts.length > 0 && products.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-medium text-slate-700">Product Recommendations</h4>
                      {selectedProducts.map((product, index) => {
                        const productData = products.find(p => p.id === product.productId);
                        if (!productData) return null;
                        
                        const recommendation = SPRAY_RECOMMENDATIONS[productData.type as keyof typeof SPRAY_RECOMMENDATIONS];
                        if (!recommendation) return null;

                        const recommendedNozzles = recommendation.nozzles;
                        const currentNozzleBase = nozzleType.split(' - ')[0];
                        const isRecommended = recommendedNozzles.includes(currentNozzleBase);

                        return (
                          <div key={index} className={`p-3 rounded-lg border ${isRecommended ? 'border-green-200 bg-green-50' : 'border-yellow-200 bg-yellow-50'}`}>
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="font-medium text-sm">{productData.name}</div>
                                <div className="text-xs text-slate-600 mt-1">
                                  Recommended: {recommendation.nozzles.join(' or ')} @ {recommendation.pressure}
                                </div>
                                <div className="text-xs text-slate-600">
                                  Volume: {recommendation.volume}
                                </div>
                              </div>
                              {isRecommended ? (
                                <CheckCircle className="text-green-600" size={16} />
                              ) : (
                                <AlertTriangle className="text-yellow-600" size={16} />
                              )}
                            </div>
                            {!isRecommended && (
                              <div className="text-xs text-yellow-700 mt-2">
                                Consider switching to {recommendation.nozzles.join(' or ')} for optimal results
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
              {(!nozzleType || !barPressure) && (
                <div className="text-center py-6 text-slate-500">
                  <p>Select nozzle type and pressure to see recommendations</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Results Panel */}
        <div className="space-y-6">
          {/* Cost Calculator */}
          <CostCalculator 
            selectedProducts={selectedProducts}
            selectedAreas={selectedAreas}
            waterVolume={getEffectiveWaterVolume()}
            products={products}
          />
          {/* AI Compatibility Analysis */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Brain className="text-white" size={16} />
                </div>
                <CardTitle>AI Compatibility Analysis</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {analysis ? (
                <div className="space-y-4">
                  <div className={`${compatibilityStyle?.bgColor} border rounded-lg p-4`}>
                    <div className="flex items-center space-x-2 mb-2">
                      {compatibilityStyle?.icon === 'fas fa-check-circle' && <CheckCircle className="text-green-600" size={20} />}
                      {compatibilityStyle?.icon === 'fas fa-exclamation-triangle' && <AlertTriangle className="text-yellow-600" size={20} />}
                      {compatibilityStyle?.icon === 'fas fa-times-circle' && <XCircle className="text-red-600" size={20} />}
                      <span className={`font-medium ${compatibilityStyle?.color}`}>
                        {analysis.compatibility.status === 'compatible' && 'Compatible Mix'}
                        {analysis.compatibility.status === 'warning' && 'Caution Required'}
                        {analysis.compatibility.status === 'incompatible' && 'Incompatible Mix'}
                      </span>
                    </div>
                    <p className={`text-sm ${compatibilityStyle?.color}`}>
                      {analysis.compatibility.message}
                    </p>
                    {analysis.compatibility.recommendations.length > 0 && (
                      <div className="mt-3">
                        <div className="font-medium text-sm mb-1">Recommendations:</div>
                        <ul className={`text-sm ${compatibilityStyle?.color} space-y-1`}>
                          {analysis.compatibility.recommendations.map((rec, index) => (
                            <li key={index} className="flex items-start">
                              <span className="mr-1">•</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  Select products and click "Analyze" to see compatibility results
                </div>
              )}
            </CardContent>
          </Card>

          {/* Spray Calculations */}
          <Card>
            <CardHeader>
              <CardTitle>Spray Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              {analysis && selectedAreas.length > 0 ? (
                <div>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-slate-50 rounded-lg p-4">
                      <div className="text-sm text-slate-600">Target Areas</div>
                      <div className="text-xl font-bold text-slate-900">
                        {selectedAreas.reduce((sum, area) => sum + area.hectares, 0).toFixed(3)} ha
                      </div>
                      <div className="text-sm text-slate-500">{selectedAreas.length} areas selected</div>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <div className="text-sm text-slate-600">Total Water Volume</div>
                      <div className="text-xl font-bold text-slate-900">{analysis.calculations.totalWaterNeeded}</div>
                      <div className="text-sm text-slate-500">{waterVolume}</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium text-slate-900">Tank Mix Calculations</h4>
                    
                    {analysis.calculations.productAmounts.map((product, index) => (
                      <div key={index} className="border border-slate-200 rounded-lg p-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium text-slate-900">{product.productName}</span>
                          <span className="text-primary font-bold">{product.amount}</span>
                        </div>
                      </div>
                    ))}

                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-primary">Tank Loads Required</span>
                        <span className="text-primary font-bold">{analysis.calculations.tankLoads}</span>
                      </div>
                      <div className="text-sm text-primary/70">Based on 1000L tank with operational constraints</div>
                      <div className="text-xs text-primary/60 mt-1">
                        Includes nozzle capacity limits and realistic multi-tank planning
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-3 mt-6">
                    <Button 
                      className="flex-1 bg-primary hover:bg-primary/90"
                      onClick={handleSaveAnalysis}
                      disabled={createRecordMutation.isPending}
                    >
                      <Save className="mr-2" size={16} />
                      Save Analysis
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={handlePrint}
                    >
                      <Printer className="mr-2" size={16} />
                      Print
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  Complete the analysis to see calculations
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
