import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Upload, Camera, X, CheckCircle, AlertTriangle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProductAnalysis {
  productFound: boolean;
  product: {
    name: string;
    type: string;
    activeIngredient: string;
    labelRate: string;
    brand: string;
    compatibilityNotes: string;
  };
  confidence: "high" | "medium" | "low";
  notes: string;
}

interface ImageUploadProps {
  onProductDetected: (product: ProductAnalysis["product"]) => void;
  className?: string;
}

export function ImageUpload({ onProductDetected, className = "" }: ImageUploadProps) {
  const { toast } = useToast();
  const [preview, setPreview] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ProductAnalysis | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const analyzeMutation = useMutation({
    mutationFn: async (imageBase64: string) => {
      const response = await apiRequest("POST", "/api/analyze-product-image", {
        imageBase64: imageBase64.split(",")[1], // Remove data:image/jpeg;base64, prefix
      });
      return response.json();
    },
    onSuccess: (data: ProductAnalysis) => {
      setAnalysis(data);
      if (data.productFound && data.confidence !== "low") {
        toast({ title: "Product detected successfully!" });
      } else if (!data.productFound) {
        toast({ 
          title: "No product detected", 
          description: "Try a clearer image of the product label",
          variant: "destructive" 
        });
      } else {
        toast({ 
          title: "Low confidence detection", 
          description: "Please verify the detected information",
          variant: "destructive" 
        });
      }
    },
    onError: () => {
      toast({ 
        title: "Analysis failed", 
        description: "Could not analyze the image. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({ title: "Please select an image file", variant: "destructive" });
      return;
    }

    // Validate file size (max 80MB)
    if (file.size > 80 * 1024 * 1024) {
      toast({ title: "Image too large. Please select an image under 80MB", variant: "destructive" });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const imageDataUrl = e.target?.result as string;
      setPreview(imageDataUrl);
      setAnalysis(null);
      analyzeMutation.mutate(imageDataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleClearImage = () => {
    setPreview(null);
    setAnalysis(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleUseProduct = () => {
    if (analysis?.product) {
      console.log("Using detected product:", analysis.product);
      onProductDetected(analysis.product);
      handleClearImage();
    }
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case "high": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getConfidenceIcon = (confidence: string) => {
    switch (confidence) {
      case "high": return <CheckCircle className="w-4 h-4" />;
      case "medium": return <AlertTriangle className="w-4 h-4" />;
      case "low": return <AlertTriangle className="w-4 h-4" />;
      default: return null;
    }
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Upload Area */}
      {!preview && (
        <Card className="border-2 border-dashed border-slate-300 hover:border-primary/50 transition-colors">
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto bg-slate-100 rounded-full flex items-center justify-center">
                <Camera className="w-8 h-8 text-slate-400" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">
                  Upload Product Image
                </h3>
                <p className="text-sm text-slate-600 mb-4">
                  Take a clear photo of the product label to automatically extract information
                </p>
                <Button 
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Choose Image
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>
              <p className="text-xs text-slate-500">
                Supports JPG, PNG, WebP. Max 80MB.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Preview and Analysis */}
      {preview && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start space-x-4">
              <div className="relative">
                <img
                  src={preview}
                  alt="Product preview"
                  className="w-32 h-32 object-cover rounded-lg border"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearImage}
                  className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-slate-900 text-white hover:bg-slate-700"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>

              <div className="flex-1 min-w-0">
                {analyzeMutation.isPending && (
                  <div className="flex items-center space-x-2 text-slate-600">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Analyzing product...</span>
                  </div>
                )}

                {analysis && (
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Badge className={getConfidenceColor(analysis.confidence)} variant="secondary">
                        <span className="flex items-center space-x-1">
                          {getConfidenceIcon(analysis.confidence)}
                          <span>{analysis.confidence} confidence</span>
                        </span>
                      </Badge>
                      {analysis.productFound && (
                        <Badge className="bg-green-100 text-green-800" variant="secondary">
                          Product Detected
                        </Badge>
                      )}
                    </div>

                    {analysis.productFound && analysis.product && (
                      <div className="space-y-2">
                        <div>
                          <div className="font-medium text-slate-900">{analysis.product.name}</div>
                          <div className="text-sm text-slate-600">{analysis.product.brand}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="text-slate-500">Type:</span>
                            <span className="ml-1 text-slate-900">{analysis.product.type}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Rate:</span>
                            <span className="ml-1 text-slate-900">{analysis.product.labelRate}</span>
                          </div>
                        </div>
                        <div className="text-sm">
                          <span className="text-slate-500">Active Ingredient:</span>
                          <span className="ml-1 text-slate-900">{analysis.product.activeIngredient}</span>
                        </div>
                        
                        <div className="flex space-x-2 pt-2">
                          <Button 
                            onClick={() => {
                              handleUseProduct();
                              toast({ title: "Product details filled in - scroll down to save" });
                            }}
                            size="sm"
                            className="bg-primary hover:bg-primary/90"
                          >
                            Use This Product
                          </Button>
                          <Button 
                            onClick={handleClearImage}
                            variant="outline"
                            size="sm"
                          >
                            Try Another Image
                          </Button>
                        </div>
                      </div>
                    )}

                    {!analysis.productFound && (
                      <div className="text-sm text-slate-600">
                        <p>{analysis.notes || "Could not detect a product in this image."}</p>
                        <Button 
                          onClick={handleClearImage}
                          variant="outline"
                          size="sm"
                          className="mt-2"
                        >
                          Try Another Image
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}