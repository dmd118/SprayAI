import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, Users, Shield, CheckCircle, AlertTriangle, CalendarDays, BarChart3 } from "lucide-react";
import { useMutation, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ProductUsage {
  productName: string;
  totalAmount: number;
  applications: number;
  averageRate: number;
  lastUsed: Date;
  costSpent: number;
}

interface SeasonalStats {
  totalApplications: number;
  totalCost: number;
  totalAreaTreated: number;
  mostUsedProduct: string;
  averageApplicationCost: number;
}

export function UsageTracker() {
  const [activeTab, setActiveTab] = useState("usage");
  const [generatedRota, setGeneratedRota] = useState<any>(null);
  const [savedRota, setSavedRota] = useState<any>(null);
  const [isRotaSaved, setIsRotaSaved] = useState(false);
  const { toast } = useToast();

  const [rotaParams, setRotaParams] = useState({
    totalStaff: 6,
    annualHours: 2080,
    weekendStartTime: "08:00",
    weekendEndTime: "16:00",
    christmasStartDate: "2024-12-20",
    christmasEndDate: "2025-01-03",
    minimumStaffOnDuty: 1
  });

  // Generate AI-optimized rota with load balancing
  const generateRotaMutation = useMutation({
    mutationFn: async (params: any) => {
      return apiRequest('POST', '/api/staff-rota/generate', params);
    },
    onSuccess: (data) => {
      setGeneratedRota(data);
      toast({
        title: "Rota Generated Successfully",
        description: "AI-optimized weekend rota with load balancing created",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate rota. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Save rota to database
  const saveRotaMutation = useMutation({
    mutationFn: async (rotaData: any) => {
      const response = await apiRequest('POST', '/api/staff-rota/save', { rota: rotaData.rota });
      localStorage.setItem('dullatur-saved-rota', JSON.stringify(rotaData));
      return response;
    },
    onSuccess: () => {
      if (generatedRota) {
        setSavedRota(generatedRota);
        setIsRotaSaved(true);
        toast({
          title: "Rota Saved Successfully",
          description: "Weekend rota is now active and protected",
        });
      }
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save rota. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateRota = () => {
    generateRotaMutation.mutate(rotaParams);
  };

  const handleSaveRota = () => {
    if (generatedRota) {
      saveRotaMutation.mutate(generatedRota);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Usage Tracker & Staff Management
          </CardTitle>
          <CardDescription>
            Track product usage, costs, and manage staff rota with AI optimization
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
              <TabsTrigger value="rota">Staff Rota</TabsTrigger>
            </TabsList>

            <TabsContent value="usage" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">47</div>
                    <p className="text-xs text-muted-foreground">+12% from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Cost</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">£2,340</div>
                    <p className="text-xs text-muted-foreground">+8% from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Area Treated</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">85.5 ha</div>
                    <p className="text-xs text-muted-foreground">Tournament ready</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="rota" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Regular Work Week</Label>
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-sm font-medium text-green-900">40 hours/week average</p>
                    <p className="text-xs text-green-700 mt-1">Seasonal work patterns:</p>
                    <ul className="text-xs text-green-700 mt-1 space-y-0.5">
                      <li>• Spring: 5:30am - 2:30pm</li>
                      <li>• Main Season: 5:30am - 2:30pm</li>
                      <li>• Summer Fridays: 5:30am - 9:30am</li>
                      <li>• Autumn: 6:00am - 2:00pm</li>
                      <li>• Winter: 7:30am - 1:30pm</li>
                    </ul>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="weekendStart">Weekend Shift Start</Label>
                  <Input
                    id="weekendStart"
                    type="time"
                    value={rotaParams.weekendStartTime}
                    onChange={(e) => setRotaParams(prev => ({ ...prev, weekendStartTime: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="weekendEnd">Weekend Shift End</Label>
                  <Input
                    id="weekendEnd"
                    type="time"
                    value={rotaParams.weekendEndTime}
                    onChange={(e) => setRotaParams(prev => ({ ...prev, weekendEndTime: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-3">
                {isRotaSaved ? (
                  <div className="space-y-3">
                    <div className="p-4 bg-green-50 border-2 border-green-300 rounded-lg">
                      <div className="flex items-center gap-2 text-green-800 font-semibold mb-2">
                        <Shield className="h-5 w-5" />
                        Rota Protected & Active
                      </div>
                      <p className="text-sm text-green-700 mb-3">
                        Weekend rota is safely stored and active. Staff can rely on these schedules for planning.
                      </p>
                      <div className="flex items-center gap-2 text-xs text-green-600">
                        <CheckCircle className="h-3 w-3" />
                        Load balancing applied - all experienced staff have equal weekend hours
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Button 
                      onClick={handleGenerateRota}
                      disabled={generateRotaMutation.isPending}
                      className="w-full"
                    >
                      {generateRotaMutation.isPending ? (
                        <>
                          <Clock className="mr-2 h-4 w-4 animate-spin" />
                          Generating AI-Optimized Weekend Rota...
                        </>
                      ) : (
                        <>
                          <Calendar className="mr-2 h-4 w-4" />
                          Generate AI-Optimized Weekend Rota
                        </>
                      )}
                    </Button>

                    {generatedRota && (
                      <div className="space-y-3">
                        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <div className="flex items-center gap-2 text-blue-800 font-semibold mb-2">
                            <CalendarDays className="h-5 w-5" />
                            Rota Generated Successfully
                          </div>
                          <p className="text-sm text-blue-700 mb-3">
                            Weekend schedule created with load balancing to ensure fair distribution of hours.
                          </p>
                          <div className="flex items-center gap-2 text-xs text-blue-600">
                            <Users className="h-3 w-3" />
                            All experienced staff (FE and F classifications) have equal weekend hours
                          </div>
                        </div>

                        <Button 
                          onClick={handleSaveRota}
                          disabled={saveRotaMutation.isPending}
                          className="w-full"
                          variant="default"
                        >
                          {saveRotaMutation.isPending ? (
                            <>
                              <Clock className="mr-2 h-4 w-4 animate-spin" />
                              Saving Rota...
                            </>
                          ) : (
                            <>
                              <Shield className="mr-2 h-4 w-4" />
                              Save & Activate Rota
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}