import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Edit, Trash2, Sprout, Calculator } from "lucide-react";
import { insertGranularFertilizerSchema, type GranularFertilizer, type TurfArea } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { SPREADER_TYPES } from "@/lib/calculations";

const formSchema = insertGranularFertilizerSchema.extend({
  name: z.string().min(1, "Product name is required"),
  brand: z.string().min(1, "Brand is required"),
  npkAnalysis: z.string().min(1, "NPK analysis is required"),
  applicationRate: z.string().min(1, "Application rate is required"),
});

type FormData = z.infer<typeof formSchema>;

export function Fertilizers() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFertilizer, setEditingFertilizer] = useState<GranularFertilizer | null>(null);

  // Calculator state
  const [selectedFertilizer, setSelectedFertilizer] = useState<string>("");
  const [selectedArea, setSelectedArea] = useState<string>("");
  const [applicationRate, setApplicationRate] = useState<string>("");
  const [spreaderType, setSpreaderType] = useState<string>("");
  const [calculation, setCalculation] = useState<any>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      brand: "",
      npkAnalysis: "",
      applicationRate: "",
      spreaderSetting: 2.5,
      spreaderType: "Drop",
      coverage: "",
    },
  });

  const { data: fertilizers = [], isLoading } = useQuery<GranularFertilizer[]>({
    queryKey: ["/api/granular-fertilizers"],
  });

  const { data: areas = [] } = useQuery<TurfArea[]>({
    queryKey: ["/api/turf-areas"],
  });

  const createMutation = useMutation({
    mutationFn: (data: FormData) => apiRequest("POST", "/api/granular-fertilizers", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/granular-fertilizers"] });
      setIsDialogOpen(false);
      form.reset();
      toast({ title: "Fertilizer created successfully" });
    },
    onError: () => {
      toast({ title: "Failed to create fertilizer", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<FormData> }) =>
      apiRequest("PUT", `/api/granular-fertilizers/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/granular-fertilizers"] });
      setIsDialogOpen(false);
      setEditingFertilizer(null);
      form.reset();
      toast({ title: "Fertilizer updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update fertilizer", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/granular-fertilizers/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/granular-fertilizers"] });
      toast({ title: "Fertilizer deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete fertilizer", variant: "destructive" });
    },
  });

  const calculateMutation = useMutation({
    mutationFn: (data: { fertilizerId: number; areaId: number; applicationRate: string; spreaderType: string }) =>
      apiRequest("POST", "/api/calculate-fertilizer", data),
    onSuccess: (response) => {
      response.json().then(setCalculation);
      toast({ title: "Calculation completed" });
    },
    onError: () => {
      toast({ title: "Failed to calculate settings", variant: "destructive" });
    },
  });

  const handleSubmit = (data: FormData) => {
    if (editingFertilizer) {
      updateMutation.mutate({ id: editingFertilizer.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (fertilizer: GranularFertilizer) => {
    setEditingFertilizer(fertilizer);
    form.reset({
      name: fertilizer.name,
      brand: fertilizer.brand,
      npkAnalysis: fertilizer.npkAnalysis,
      applicationRate: fertilizer.applicationRate,
      spreaderSetting: fertilizer.spreaderSetting,
      spreaderType: fertilizer.spreaderType,
      coverage: fertilizer.coverage,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this fertilizer?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleCalculate = () => {
    if (!selectedFertilizer || !selectedArea || !applicationRate || !spreaderType) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }

    calculateMutation.mutate({
      fertilizerId: parseInt(selectedFertilizer),
      areaId: parseInt(selectedArea),
      applicationRate,
      spreaderType,
    });
  };

  if (isLoading) {
    return <div className="p-6">Loading granular fertilizers...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Granular Fertilizers</h2>
          <p className="text-slate-600 mt-1">Manage your granular fertilizer inventory and Scott's spreader settings</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="mr-2" size={16} />
              Add Fertilizer
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingFertilizer ? "Edit Granular Fertilizer" : "Add New Granular Fertilizer"}
              </DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Scott's Starter Fertilizer" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="brand"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Brand</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Scott's Professional" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="npkAnalysis"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>NPK Analysis</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="21-22-4" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="applicationRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Application Rate</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="2-3 lbs/1000 sq ft" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="spreaderSetting"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Spreader Setting</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number" 
                            step="0.1" 
                            placeholder="2.5"
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="spreaderType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Spreader Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select spreader type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Drop">Drop Spreader</SelectItem>
                            <SelectItem value="Broadcast">Broadcast Spreader</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="coverage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Coverage</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="15,000 sq ft/50lb bag" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setEditingFertilizer(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending}
                  >
                    {editingFertilizer ? "Update" : "Create"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Fertilizer Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Fertilizer Products</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Product Name</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">N-P-K Analysis</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Application Rate</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Spreader Setting</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Coverage</th>
                  <th className="text-right py-3 px-4 font-medium text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {fertilizers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 px-4 text-center text-slate-500">
                      No fertilizers found. Click "Add Fertilizer" to get started.
                    </td>
                  </tr>
                ) : (
                  fertilizers.map((fertilizer) => (
                    <tr key={fertilizer.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-4 px-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                            <Sprout className="text-green-600" size={16} />
                          </div>
                          <div>
                            <div className="font-medium text-slate-900">{fertilizer.name}</div>
                            <div className="text-sm text-slate-500">{fertilizer.brand}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className="font-mono text-slate-900">{fertilizer.npkAnalysis}</span>
                      </td>
                      <td className="py-4 px-4 text-slate-900">{fertilizer.applicationRate}</td>
                      <td className="py-4 px-4">
                        <span className="font-medium text-primary">{fertilizer.spreaderSetting}</span>
                        <span className="text-sm text-slate-500 ml-1">({fertilizer.spreaderType} spreader)</span>
                      </td>
                      <td className="py-4 px-4 text-slate-900">{fertilizer.coverage}</td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(fertilizer)}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(fertilizer.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Application Calculator */}
      <Card>
        <CardHeader>
          <CardTitle>Application Calculator</CardTitle>
          <p className="text-sm text-slate-600">Calculate spreader settings and material requirements</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Select Fertilizer</label>
                <Select value={selectedFertilizer} onValueChange={setSelectedFertilizer}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select fertilizer product..." />
                  </SelectTrigger>
                  <SelectContent>
                    {fertilizers.map((fertilizer) => (
                      <SelectItem key={fertilizer.id} value={fertilizer.id.toString()}>
                        {fertilizer.name} ({fertilizer.npkAnalysis})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Target Area</label>
                <Select value={selectedArea} onValueChange={setSelectedArea}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select area..." />
                  </SelectTrigger>
                  <SelectContent>
                    {areas.map((area) => (
                      <SelectItem key={area.id} value={area.id.toString()}>
                        {area.name} ({area.hectares} hectares)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Application Rate</label>
                <div className="flex space-x-2">
                  <Input
                    type="number"
                    placeholder="2.5"
                    value={applicationRate}
                    onChange={(e) => setApplicationRate(e.target.value)}
                    className="flex-1"
                  />
                  <Select disabled>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="lbs/1000 sq ft" />
                    </SelectTrigger>
                  </Select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Spreader Type</label>
                <Select value={spreaderType} onValueChange={setSpreaderType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select spreader type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {SPREADER_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              {calculation ? (
                <div className="bg-slate-50 rounded-lg p-4">
                  <h4 className="font-medium text-slate-900 mb-3">Calculation Results</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-600">Spreader Setting:</span>
                      <span className="font-bold text-primary">{calculation.spreaderSetting}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Total Material Needed:</span>
                      <span className="font-bold text-slate-900">{calculation.materialNeeded}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Number of Bags:</span>
                      <span className="font-bold text-slate-900">{calculation.numberOfBags}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-600">Walking Speed:</span>
                      <span className="font-bold text-slate-900">{calculation.walkingSpeed}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 rounded-lg p-4 text-center text-slate-500">
                  Fill in the form and click calculate to see results
                </div>
              )}

              <Button 
                className="w-full"
                onClick={handleCalculate}
                disabled={calculateMutation.isPending}
              >
                <Calculator className="mr-2" size={16} />
                Calculate Settings
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
