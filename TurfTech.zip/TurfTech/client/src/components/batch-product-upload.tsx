import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Upload, X, Check, Edit3, Save, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { InsertSprayProduct } from "@shared/schema";

interface DetectedProduct {
  id: string;
  name: string;
  type: string;
  activeIngredient: string;
  labelRate: string;
  brand: string;
  compatibilityNotes: string;
  confidence: "high" | "medium" | "low";
  imageUrl: string;
  isEditing?: boolean;
  formulation?: string;
  suggestedSection?: "spray" | "fertilizer";
  warning?: string;
}

export function BatchProductUpload() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [detectedProducts, setDetectedProducts] = useState<DetectedProduct[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [editingProduct, setEditingProduct] = useState<string | null>(null);

  const productTypes = [
    "Growth Regulator",
    "Fungicide", 
    "Herbicide",
    "Insecticide",
    "Wetting Agent",
    "Fertilizer",
    "Biostimulant",
    "Other"
  ];

  const analyzeImagesMutation = useMutation({
    mutationFn: async (files: File[]) => {
      const results = [];
      
      for (const file of files) {
        // Convert file to base64
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
        const imageBase64 = await base64Promise;
        
        const response = await apiRequest("POST", "/api/analyze-product-image", {
          imageBase64: imageBase64.split(",")[1], // Remove data:image/jpeg;base64, prefix
        });
        
        if (!response.ok) {
          throw new Error(`Failed to analyze ${file.name}`);
        }
        
        const data = await response.json();
        
        // Detect if this is a granular fertilizer
        const productName = data.product.name?.toLowerCase() || '';
        const productType = data.product.type?.toLowerCase() || '';
        const activeIngredient = data.product.activeIngredient?.toLowerCase() || '';
        const labelRate = data.product.labelRate?.toLowerCase() || '';
        
        const isGranularFertilizer = 
          productName.includes('granular') ||
          productName.includes('prills') ||
          labelRate.includes('kg/ha') ||
          labelRate.includes('g/m²') ||
          activeIngredient.includes('nitrogen') ||
          activeIngredient.includes('phosphorus') ||
          activeIngredient.includes('potassium') ||
          productType.includes('fertilizer') ||
          productName.match(/\d+-\d+-\d+/); // NPK ratio pattern
        
        results.push({
          ...data.product,
          id: crypto.randomUUID(),
          imageUrl: URL.createObjectURL(file),
          confidence: data.confidence,
          suggestedSection: isGranularFertilizer ? 'fertilizer' : 'spray',
          warning: isGranularFertilizer ? 'This appears to be a granular fertilizer. Consider moving to G Fertilizers section.' : undefined
        });
      }
      
      return results;
    },
    onSuccess: (products) => {
      setDetectedProducts(prev => [...prev, ...products]);
      setIsAnalyzing(false);
      toast({ title: `Successfully analyzed ${products.length} product labels` });
    },
    onError: (error) => {
      setIsAnalyzing(false);
      toast({ 
        title: "Failed to analyze product labels", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const saveProductsMutation = useMutation({
    mutationFn: async (products: DetectedProduct[]) => {
      const results = [];
      let sprayCount = 0;
      let fertilizerCount = 0;
      
      for (const product of products) {
        if (product.suggestedSection === 'fertilizer') {
          // Save as granular fertilizer
          const fertilizerData = {
            name: product.name,
            brand: product.brand,
            npkRatio: product.labelRate,
            applicationRate: product.labelRate,
            notes: product.compatibilityNotes,
            status: "Active"
          };
          
          const response = await apiRequest("POST", "/api/granular-fertilizers", fertilizerData);
          results.push(response);
          fertilizerCount++;
        } else {
          // Save as spray product
          const productData: InsertSprayProduct = {
            name: product.name,
            type: product.type,
            activeIngredient: product.activeIngredient,
            labelRate: product.labelRate,
            brand: product.brand,
            compatibilityNotes: product.compatibilityNotes,
            status: "Active"
          };
          
          const response = await apiRequest("POST", "/api/spray-products", productData);
          results.push(response);
          sprayCount++;
        }
      }
      
      return { results, sprayCount, fertilizerCount };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/spray-products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/granular-fertilizers"] });
      
      let message = "Successfully organized products: ";
      const parts = [];
      if (data.sprayCount > 0) parts.push(`${data.sprayCount} spray products`);
      if (data.fertilizerCount > 0) parts.push(`${data.fertilizerCount} moved to G Fertilizers`);
      message += parts.join(", ");
      
      toast({ title: message });
      setIsDialogOpen(false);
      setSelectedFiles([]);
      setDetectedProducts([]);
    },
    onError: () => {
      toast({ 
        title: "Failed to save products", 
        variant: "destructive" 
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setSelectedFiles(prev => [...prev, ...files]);
    // Reset the input so the same file can be selected again if needed
    event.target.value = '';
  };

  const clearAllFiles = () => {
    setSelectedFiles([]);
    setDetectedProducts([]);
  };

  const handleAnalyze = () => {
    if (selectedFiles.length === 0) {
      toast({ title: "Please select at least one image", variant: "destructive" });
      return;
    }
    
    setIsAnalyzing(true);
    analyzeImagesMutation.mutate(selectedFiles);
  };

  const handleSaveAll = () => {
    if (detectedProducts.length === 0) {
      toast({ title: "No products to save", variant: "destructive" });
      return;
    }
    
    saveProductsMutation.mutate(detectedProducts);
  };

  const updateProduct = (id: string, updates: Partial<DetectedProduct>) => {
    setDetectedProducts(products => 
      products.map(product => 
        product.id === id ? { ...product, ...updates } : product
      )
    );
  };

  const removeProduct = (id: string) => {
    setDetectedProducts(products => products.filter(p => p.id !== id));
  };

  const toggleEdit = (id: string) => {
    setEditingProduct(editingProduct === id ? null : id);
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case "high": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 w-full sm:w-auto">
          <Upload className="mr-2" size={16} />
          Batch Upload Products
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Batch Upload Product Labels</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* File Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Upload Product Label Photos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFileSelect}
                  className="file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:bg-blue-50 file:text-blue-700"
                  id="batch-file-input"
                />
                
                {selectedFiles.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-gray-600">
                        Selected {selectedFiles.length} image{selectedFiles.length > 1 ? 's' : ''}
                      </p>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => document.getElementById('batch-file-input')?.click()}
                        >
                          <Upload className="w-4 h-4 mr-1" />
                          Add Another
                        </Button>
                        <Button variant="outline" size="sm" onClick={clearAllFiles}>
                          <X className="w-4 h-4 mr-1" />
                          Clear All
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                      {selectedFiles.map((file, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {file.name.length > 20 ? `${file.name.substring(0, 20)}...` : file.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                <Button 
                  onClick={handleAnalyze}
                  disabled={selectedFiles.length === 0 || isAnalyzing}
                  className="w-full"
                >
                  {isAnalyzing ? "Analyzing Labels..." : "Analyze Product Labels"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Review Section */}
          {detectedProducts.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Review Detected Products</CardTitle>
                  <Button onClick={handleSaveAll} disabled={saveProductsMutation.isPending}>
                    <Save className="mr-2" size={16} />
                    Save All {detectedProducts.length} Products
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {detectedProducts.map((product) => (
                    <div key={product.id} className={`border rounded-lg p-4 ${product.warning ? 'border-orange-300 bg-orange-50' : 'border-gray-200'}`}>
                      {product.warning && (
                        <div className="flex items-center space-x-2 mb-3 p-2 bg-orange-100 rounded-md">
                          <AlertCircle className="w-4 h-4 text-orange-600" />
                          <span className="text-sm text-orange-800">{product.warning}</span>
                        </div>
                      )}
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          <Badge className={getConfidenceColor(product.confidence)}>
                            {product.confidence} confidence
                          </Badge>
                          {product.suggestedSection === 'fertilizer' && (
                            <Badge variant="outline" className="text-orange-700 border-orange-300">
                              Granular Fertilizer Detected
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleEdit(product.id)}
                          >
                            <Edit3 size={14} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeProduct(product.id)}
                          >
                            <X size={14} />
                          </Button>
                        </div>
                        <img 
                          src={product.imageUrl} 
                          alt="Product label"
                          className="w-16 h-16 object-cover rounded border"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Product Name
                          </label>
                          {editingProduct === product.id ? (
                            <Input
                              value={product.name}
                              onChange={(e) => updateProduct(product.id, { name: e.target.value })}
                            />
                          ) : (
                            <p className="text-sm text-gray-900">{product.name}</p>
                          )}
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Type
                          </label>
                          {editingProduct === product.id ? (
                            <Select
                              value={product.type}
                              onValueChange={(value) => updateProduct(product.id, { type: value })}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {productTypes.map((type) => (
                                  <SelectItem key={type} value={type}>
                                    {type}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <p className="text-sm text-gray-900">{product.type}</p>
                          )}
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Active Ingredient
                          </label>
                          {editingProduct === product.id ? (
                            <Input
                              value={product.activeIngredient}
                              onChange={(e) => updateProduct(product.id, { activeIngredient: e.target.value })}
                            />
                          ) : (
                            <p className="text-sm text-gray-900">{product.activeIngredient}</p>
                          )}
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Label Rate
                          </label>
                          {editingProduct === product.id ? (
                            <Input
                              value={product.labelRate}
                              onChange={(e) => updateProduct(product.id, { labelRate: e.target.value })}
                            />
                          ) : (
                            <p className="text-sm text-gray-900">{product.labelRate}</p>
                          )}
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Brand/Manufacturer
                          </label>
                          {editingProduct === product.id ? (
                            <Input
                              value={product.brand}
                              onChange={(e) => updateProduct(product.id, { brand: e.target.value })}
                            />
                          ) : (
                            <p className="text-sm text-gray-900">{product.brand}</p>
                          )}
                        </div>
                        
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Compatibility Notes
                          </label>
                          {editingProduct === product.id ? (
                            <Input
                              value={product.compatibilityNotes}
                              onChange={(e) => updateProduct(product.id, { compatibilityNotes: e.target.value })}
                              placeholder="Tank mix compatibility and application notes"
                            />
                          ) : (
                            <p className="text-sm text-gray-900">{product.compatibilityNotes || "No notes"}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}