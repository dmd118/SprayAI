import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Edit, Trash2, Flag, Circle, TrafficCone, ChevronDown, ChevronRight } from "lucide-react";
import { insertTurfAreaSchema, type TurfArea } from "@shared/schema";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { hectaresToSquareFeet, squareFeetToHectares } from "@/lib/calculations";

const formSchema = insertTurfAreaSchema.extend({
  name: z.string().min(1, "Area name is required"),
  type: z.string().min(1, "Area type is required"),
  hectares: z.number().min(0.001, "Area must be greater than 0"),
});

type FormData = z.infer<typeof formSchema>;

export function TurfAreas() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<TurfArea | null>(null);
  const [expandedAreas, setExpandedAreas] = useState<string[]>([]);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      type: "",
      hectares: 0,
      squareFeet: 0,
    },
  });

  const { data: areas = [], isLoading } = useQuery<TurfArea[]>({
    queryKey: ["/api/turf-areas"],
  });

  const createMutation = useMutation({
    mutationFn: (data: FormData) => {
      const squareFeet = Math.round(hectaresToSquareFeet(data.hectares));
      return apiRequest("POST", "/api/turf-areas", { ...data, squareFeet });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/turf-areas"] });
      setIsDialogOpen(false);
      form.reset();
      toast({ title: "Area created successfully" });
    },
    onError: () => {
      toast({ title: "Failed to create area", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<FormData> }) => {
      const updateData = data.hectares 
        ? { ...data, squareFeet: Math.round(hectaresToSquareFeet(data.hectares)) }
        : data;
      return apiRequest("PUT", `/api/turf-areas/${id}`, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/turf-areas"] });
      setIsDialogOpen(false);
      setEditingArea(null);
      form.reset();
      toast({ title: "Area updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update area", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/turf-areas/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/turf-areas"] });
      toast({ title: "Area deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete area", variant: "destructive" });
    },
  });

  const handleSubmit = (data: FormData) => {
    if (editingArea) {
      updateMutation.mutate({ id: editingArea.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (area: TurfArea) => {
    setEditingArea(area);
    form.reset({
      name: area.name,
      type: area.type,
      hectares: area.hectares,
      squareFeet: area.squareFeet,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this area?")) {
      deleteMutation.mutate(id);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "green": return <Flag className="text-green-600" size={16} />;
      case "tee": return <Circle className="text-blue-600" size={16} />;
      case "fairway": return <TrafficCone className="text-yellow-600" size={16} />;
      default: return <Flag className="text-gray-600" size={16} />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "green": return "bg-green-100 text-green-800";
      case "tee": return "bg-blue-100 text-blue-800";
      case "fairway": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getCourseAreas = () => {
    const courseAreas = {
      'C': { greens: [] as TurfArea[], tees: [] as TurfArea[], fairways: [] as TurfArea[] },
      'A': { greens: [] as TurfArea[], tees: [] as TurfArea[], fairways: [] as TurfArea[] }
    };
    
    areas.forEach(area => {
      const course = area.name.includes('-C') ? 'C' : area.name.includes('-A') ? 'A' : null;
      if (!course) return;
      
      const type = area.type.toLowerCase();
      if (type === 'greens' || type === 'green') {
        courseAreas[course].greens.push(area);
      } else if (type === 'tees' || type === 'tee') {
        courseAreas[course].tees.push(area);
      } else if (type === 'fairways' || type === 'fairway') {
        courseAreas[course].fairways.push(area);
      }
    });
    
    return courseAreas;
  };

  const getTypeStats = (typeAreas: TurfArea[]) => {
    // Check if there's a "Total" entry - if so, use only that for total hectares
    const totalEntry = typeAreas.find(area => area.name.includes('Total'));
    const individualAreas = typeAreas.filter(area => !area.name.includes('Total'));
    
    // Use total entry if available, otherwise sum individual areas
    const totalHectares = totalEntry ? totalEntry.hectares : individualAreas.reduce((sum, area) => sum + area.hectares, 0);
    const count = individualAreas.length;
    const average = count > 0 ? totalHectares / count : 0;
    return { count, totalHectares, average };
  };

  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string | null>(null);

  if (isLoading) {
    return <div className="p-6">Loading turf areas...</div>;
  }

  const courseAreas = getCourseAreas();

  // If detailed view is selected, show breakdown
  if (selectedCourse && selectedType) {
    const typeAreas = courseAreas[selectedCourse as 'C' | 'A'][selectedType as 'greens' | 'tees' | 'fairways'];
    
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Button 
              variant="ghost" 
              onClick={() => {
                setSelectedCourse(null);
                setSelectedType(null);
              }}
              className="mb-2"
            >
              ← Back to Overview
            </Button>
            <h2 className="text-2xl font-bold text-slate-900">
              {selectedType.charAt(0).toUpperCase() + selectedType.slice(1)}-{selectedCourse} Detailed Breakdown
            </h2>
            <p className="text-slate-600 mt-1">Individual {selectedType} measurements</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="mr-2" size={16} />
                Add Area
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>
                  {editingArea ? "Edit Turf Area" : "Add New Turf Area"}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Area Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Tee 1-C" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select area type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Greens">Greens</SelectItem>
                            <SelectItem value="Tees">Tees</SelectItem>
                            <SelectItem value="Fairways">Fairways</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="hectares"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Area (Hectares)</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number" 
                            step="0.001" 
                            placeholder="0.12"
                            onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsDialogOpen(false);
                        setEditingArea(null);
                        form.reset();
                      }}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createMutation.isPending || updateMutation.isPending}
                    >
                      {editingArea ? "Update" : "Create"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Detailed breakdown table */}
        <Card>
          <CardHeader>
            <CardTitle>{selectedType.charAt(0).toUpperCase() + selectedType.slice(1)}-{selectedCourse} Detailed Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Hole</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Area Name</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Area (ha)</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Area (m²)</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Last Updated</th>
                    <th className="text-right py-3 px-4 font-medium text-slate-700">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {typeAreas.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 px-4 text-center text-slate-500">
                        No {selectedType} found for Course {selectedCourse}. Add individual {selectedType} for holes 1-18.
                      </td>
                    </tr>
                  ) : (
                    typeAreas
                      .sort((a, b) => {
                        // Put total row at the top, then sort by hole number
                        if (a.name.includes('Total')) return -1;
                        if (b.name.includes('Total')) return 1;
                        const aHole = parseInt(a.name.match(/\d+/)?.[0] || '999');
                        const bHole = parseInt(b.name.match(/\d+/)?.[0] || '999');
                        return aHole - bHole;
                      })
                      .map((area) => {
                        const isTotal = area.name.includes('Total');
                        return (
                          <tr key={area.id} className={`transition-colors ${
                            isTotal 
                              ? 'bg-blue-50 border-t-2 border-blue-200 hover:bg-blue-100' 
                              : 'hover:bg-slate-50'
                          }`}>
                            <td className="py-4 px-4">
                              <div className="flex items-center">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                                  isTotal 
                                    ? 'bg-blue-100 border-2 border-blue-300' 
                                    : 'bg-slate-100'
                                }`}>
                                  <span className={`text-sm font-medium ${
                                    isTotal ? 'text-blue-700' : 'text-slate-700'
                                  }`}>
                                    {isTotal ? '∑' : area.name.match(/\d+/)?.[0] || '?'}
                                  </span>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <span className={`font-medium ${
                                isTotal ? 'text-blue-900 font-bold' : 'text-slate-900'
                              }`}>{area.name}</span>
                            </td>
                            <td className={`py-4 px-4 font-mono ${
                              isTotal ? 'text-blue-900 font-bold' : 'text-slate-900'
                            }`}>
                              {area.hectares.toFixed(3)}
                            </td>
                            <td className={`py-4 px-4 font-mono ${
                              isTotal ? 'text-blue-700 font-semibold' : 'text-slate-600'
                            }`}>
                              {Math.round(area.hectares * 10000)}
                            </td>
                            <td className="py-4 px-4 text-slate-600 text-sm">
                              {new Date(area.lastUpdated).toLocaleDateString()}
                            </td>
                            <td className="py-4 px-4 text-right">
                              <div className="flex items-center justify-end space-x-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEdit(area)}
                                  className="h-8 w-8 p-0"
                                >
                                  <Edit size={14} />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDelete(area.id)}
                                  className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                                >
                                  <Trash2 size={14} />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Turf Areas</h2>
          <p className="text-slate-600 mt-1">Manage your golf course area measurements and zones</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="mr-2" size={16} />
              Add Area
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {editingArea ? "Edit Turf Area" : "Add New Turf Area"}
              </DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Area Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Green #1" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select area type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Green">Green</SelectItem>
                          <SelectItem value="Tee">Tee</SelectItem>
                          <SelectItem value="Fairway">Fairway</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="hectares"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Area (hectares)</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          step="0.001" 
                          placeholder="0.12"
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setEditingArea(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending}
                  >
                    {editingArea ? "Update" : "Create"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* 3x2 Grid Layout - Course Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Top Row - Course C */}
        <Card 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setSelectedCourse('C');
            setSelectedType('greens');
          }}
        >
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Flag className="text-green-600" size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Greens</h3>
                <p className="text-sm text-slate-600">{getTypeStats(courseAreas.C.greens).count} putting greens</p>
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {getTypeStats(courseAreas.C.greens).totalHectares.toFixed(1)} ha
            </div>
            <div className="text-sm text-slate-600">
              Average: {getTypeStats(courseAreas.C.greens).average.toFixed(3)} ha per green
            </div>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setSelectedCourse('C');
            setSelectedType('tees');
          }}
        >
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Circle className="text-blue-600" size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Tees</h3>
                <p className="text-sm text-slate-600">{getTypeStats(courseAreas.C.tees).count} tee boxes</p>
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {getTypeStats(courseAreas.C.tees).totalHectares.toFixed(1)} ha
            </div>
            <div className="text-sm text-slate-600">
              Average: {getTypeStats(courseAreas.C.tees).average.toFixed(3)} ha per tee
            </div>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setSelectedCourse('C');
            setSelectedType('fairways');
          }}
        >
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <TrafficCone className="text-yellow-600" size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Fairways</h3>
                <p className="text-sm text-slate-600">{getTypeStats(courseAreas.C.fairways).count} fairways</p>
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {getTypeStats(courseAreas.C.fairways).totalHectares.toFixed(1)} ha
            </div>
            <div className="text-sm text-slate-600">
              Average: {getTypeStats(courseAreas.C.fairways).average.toFixed(3)} ha per fairway
            </div>
          </CardContent>
        </Card>

        {/* Bottom Row - Course A */}
        <Card 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setSelectedCourse('A');
            setSelectedType('greens');
          }}
        >
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Flag className="text-green-600" size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Greens-A</h3>
                <p className="text-sm text-slate-600">{getTypeStats(courseAreas.A.greens).count} putting greens</p>
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {getTypeStats(courseAreas.A.greens).totalHectares.toFixed(1)} ha
            </div>
            <div className="text-sm text-slate-600">
              Average: {getTypeStats(courseAreas.A.greens).average.toFixed(3)} ha per green
            </div>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setSelectedCourse('A');
            setSelectedType('tees');
          }}
        >
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Circle className="text-blue-600" size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Tees-A</h3>
                <p className="text-sm text-slate-600">{getTypeStats(courseAreas.A.tees).count} tee boxes</p>
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {getTypeStats(courseAreas.A.tees).totalHectares.toFixed(1)} ha
            </div>
            <div className="text-sm text-slate-600">
              Average: {getTypeStats(courseAreas.A.tees).average.toFixed(3)} ha per tee
            </div>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setSelectedCourse('A');
            setSelectedType('fairways');
          }}
        >
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <TrafficCone className="text-yellow-600" size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Fairways-A</h3>
                <p className="text-sm text-slate-600">{getTypeStats(courseAreas.A.fairways).count} fairways</p>
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-2">
              {getTypeStats(courseAreas.A.fairways).totalHectares.toFixed(1)} ha
            </div>
            <div className="text-sm text-slate-600">
              Average: {getTypeStats(courseAreas.A.fairways).average.toFixed(3)} ha per fairway
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Areas Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Area Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Zone</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Type</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Area (ha)</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Area (sq ft)</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-700">Last Updated</th>
                  <th className="text-right py-3 px-4 font-medium text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {areas.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 px-4 text-center text-slate-500">
                      No turf areas found. Click "Add Area" to get started.
                    </td>
                  </tr>
                ) : (
                  areas.map((area) => (
                    <tr key={area.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-4 px-4">
                        <div className="flex items-center">
                          <div className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center mr-3">
                            {getTypeIcon(area.type)}
                          </div>
                          <span className="font-medium text-slate-900">{area.name}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <Badge className={getTypeColor(area.type)} variant="secondary">
                          {area.type}
                        </Badge>
                      </td>
                      <td className="py-4 px-4 text-slate-900">{area.hectares.toFixed(2)}</td>
                      <td className="py-4 px-4 text-slate-600">{area.squareFeet.toLocaleString()}</td>
                      <td className="py-4 px-4 text-slate-600">
                        {new Date(area.lastUpdated).toLocaleDateString()}
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(area)}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(area.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
