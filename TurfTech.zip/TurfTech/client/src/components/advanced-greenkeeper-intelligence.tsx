import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Droplets, Thermometer, Wind, Activity, Bug, Tractor } from "lucide-react";

interface GrowingDegreeDayData {
  date: string;
  dailyGDD: number;
  cumulativeGDD: number;
  baseTemp: number;
  maxTemp: number;
  minTemp: number;
}

interface DiseaseRiskAssessment {
  dollarSpotRisk: 'low' | 'moderate' | 'high' | 'severe';
  anthracnoseRisk: 'low' | 'moderate' | 'high' | 'severe';
  fusariumRisk: 'low' | 'moderate' | 'high' | 'severe';
  riskFactors: {
    temperature: number;
    humidity: number;
    dewPoint: number;
    leafWetnessDuration: number;
  };
  recommendations: string[];
}

interface SoilConditionData {
  moistureLevel: 'dry' | 'optimal' | 'wet' | 'saturated';
  moisturePercentage: number;
  trafficRisk: 'safe' | 'caution' | 'avoid';
  machineryRecommendation: string;
  compactionRisk: 'low' | 'moderate' | 'high';
}

interface SprayConditionAlert {
  windSpeed: number;
  windRisk: 'safe' | 'caution' | 'unsafe';
  temperatureRisk: 'safe' | 'caution' | 'unsafe';
  humidityRisk: 'safe' | 'caution' | 'unsafe';
  overallRisk: 'safe' | 'caution' | 'unsafe';
  alerts: string[];
  recommendations: string[];
}

function getRiskColor(risk: string): string {
  switch (risk) {
    case 'low': case 'safe': return 'bg-green-100 text-green-800';
    case 'moderate': case 'caution': return 'bg-yellow-100 text-yellow-800';
    case 'high': case 'unsafe': return 'bg-orange-100 text-orange-800';
    case 'severe': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
}

export function AdvancedGreenkeeperIntelligence() {
  // Fetch Growing Degree Days for current year
  const { data: gddData, isLoading: gddLoading } = useQuery<GrowingDegreeDayData[]>({
    queryKey: ["/api/growing-degree-days"],
    queryFn: () => fetch("/api/growing-degree-days").then(res => res.json()),
    refetchInterval: 60 * 60 * 1000, // Refresh every hour
  });

  // Fetch disease risk assessment
  const { data: diseaseRisk, isLoading: diseaseLoading } = useQuery<DiseaseRiskAssessment>({
    queryKey: ["/api/disease-risk"],
    queryFn: () => fetch("/api/disease-risk").then(res => res.json()),
    refetchInterval: 30 * 60 * 1000, // Refresh every 30 minutes
  });

  // Fetch soil conditions
  const { data: soilConditions, isLoading: soilLoading } = useQuery<SoilConditionData>({
    queryKey: ["/api/soil-conditions"],
    queryFn: () => fetch("/api/soil-conditions").then(res => res.json()),
    refetchInterval: 15 * 60 * 1000, // Refresh every 15 minutes
  });

  // Fetch spray conditions
  const { data: sprayConditions, isLoading: sprayLoading } = useQuery<SprayConditionAlert>({
    queryKey: ["/api/spray-conditions"],
    queryFn: () => fetch("/api/spray-conditions").then(res => res.json()),
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const currentGDD = gddData && gddData.length > 0 ? gddData[gddData.length - 1] : null;

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-900">Advanced Greenkeeping Intelligence</h3>
      
      {/* Growing Degree Days */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Activity className="text-green-600" size={20} />
            <CardTitle className="text-lg">Growing Degree Days (GDD)</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {gddLoading ? (
            <div className="animate-pulse">Loading GDD data...</div>
          ) : currentGDD ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-900">
                  {currentGDD.cumulativeGDD === 0 ? "Soon" : currentGDD.cumulativeGDD}
                </div>
                <div className="text-sm text-green-700">Cumulative GDD</div>
                <div className="text-xs text-green-600">Base: {currentGDD.baseTemp}°C</div>
              </div>
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-900">
                  {currentGDD.dailyGDD === 0 ? "Soon" : currentGDD.dailyGDD}
                </div>
                <div className="text-sm text-blue-700">Today's GDD</div>
                <div className="text-xs text-blue-600">Growth potential</div>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-900">{currentGDD.maxTemp}°C</div>
                <div className="text-sm text-orange-700">Today's High</div>
                <div className="text-xs text-orange-600">Low: {currentGDD.minTemp}°C</div>
              </div>
            </div>
          ) : (
            <div className="text-gray-500">GDD data coming soon</div>
          )}
        </CardContent>
      </Card>

      {/* Disease Risk Assessment */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Bug className="text-red-600" size={20} />
            <CardTitle className="text-lg">Disease Pressure Assessment</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {diseaseLoading ? (
            <div className="animate-pulse">Analyzing disease risk...</div>
          ) : diseaseRisk ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 rounded-lg">
                  <div className="text-sm font-medium text-gray-700 mb-1">Dollar Spot</div>
                  <Badge className={getRiskColor(diseaseRisk.dollarSpotRisk)}>
                    {diseaseRisk.dollarSpotRisk.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-center p-3 rounded-lg">
                  <div className="text-sm font-medium text-gray-700 mb-1">Anthracnose</div>
                  <Badge className={getRiskColor(diseaseRisk.anthracnoseRisk)}>
                    {diseaseRisk.anthracnoseRisk.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-center p-3 rounded-lg">
                  <div className="text-sm font-medium text-gray-700 mb-1">Fusarium</div>
                  <Badge className={getRiskColor(diseaseRisk.fusariumRisk)}>
                    {diseaseRisk.fusariumRisk.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="text-center p-2 bg-gray-50 rounded">
                  <div className="font-medium">{diseaseRisk.riskFactors.temperature}°C</div>
                  <div className="text-gray-600">Temperature</div>
                </div>
                <div className="text-center p-2 bg-gray-50 rounded">
                  <div className="font-medium">{diseaseRisk.riskFactors.humidity}%</div>
                  <div className="text-gray-600">Humidity</div>
                </div>
                <div className="text-center p-2 bg-gray-50 rounded">
                  <div className="font-medium">{diseaseRisk.riskFactors.dewPoint}°C</div>
                  <div className="text-gray-600">Dew Point</div>
                </div>
                <div className="text-center p-2 bg-gray-50 rounded">
                  <div className="font-medium">{diseaseRisk.riskFactors.leafWetnessDuration}h</div>
                  <div className="text-gray-600">Leaf Wetness</div>
                </div>
              </div>

              {diseaseRisk.recommendations.length > 0 && (
                <div className="space-y-2">
                  <h5 className="font-medium text-gray-900">Recommendations:</h5>
                  {diseaseRisk.recommendations.map((rec, index) => (
                    <Alert key={index}>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{rec}</AlertDescription>
                    </Alert>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="text-gray-500">Disease risk data unavailable</div>
          )}
        </CardContent>
      </Card>

      {/* Soil Conditions & Machinery Risk */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Tractor className="text-amber-600" size={20} />
            <CardTitle className="text-lg">Soil Conditions & Machinery Risk</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {soilLoading ? (
            <div className="animate-pulse">Assessing soil conditions...</div>
          ) : soilConditions ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-900">{soilConditions.moisturePercentage}%</div>
                  <div className="text-sm text-blue-700">Soil Moisture</div>
                  <Badge className={getRiskColor(soilConditions.moistureLevel)}>
                    {soilConditions.moistureLevel.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-center p-3 bg-amber-50 rounded-lg">
                  <div className="text-lg font-bold text-amber-900">Traffic Risk</div>
                  <Badge className={getRiskColor(soilConditions.trafficRisk)}>
                    {soilConditions.trafficRisk.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-center p-3 bg-red-50 rounded-lg">
                  <div className="text-lg font-bold text-red-900">Compaction Risk</div>
                  <Badge className={getRiskColor(soilConditions.compactionRisk)}>
                    {soilConditions.compactionRisk.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              <Alert>
                <Tractor className="h-4 w-4" />
                <AlertDescription>{soilConditions.machineryRecommendation}</AlertDescription>
              </Alert>
            </div>
          ) : (
            <div className="text-gray-500">Soil condition data unavailable</div>
          )}
        </CardContent>
      </Card>

      {/* Spray Conditions */}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Droplets className="text-blue-600" size={20} />
            <CardTitle className="text-lg">Spray Application Conditions</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {sprayLoading ? (
            <div className="animate-pulse">Evaluating spray conditions...</div>
          ) : sprayConditions ? (
            <div className="space-y-4">
              <div className="text-center p-4 rounded-lg border-2" style={{
                borderColor: sprayConditions.overallRisk === 'safe' ? '#10b981' : 
                           sprayConditions.overallRisk === 'caution' ? '#f59e0b' : '#ef4444',
                backgroundColor: sprayConditions.overallRisk === 'safe' ? '#ecfdf5' : 
                               sprayConditions.overallRisk === 'caution' ? '#fffbeb' : '#fef2f2'
              }}>
                <div className="text-lg font-bold text-gray-900">Overall Spray Risk</div>
                <Badge className={getRiskColor(sprayConditions.overallRisk)} style={{ fontSize: '16px', padding: '8px 16px' }}>
                  {sprayConditions.overallRisk.toUpperCase()}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-center mb-2">
                    <Wind size={16} className="mr-1" />
                    <span className="text-sm font-medium">Wind</span>
                  </div>
                  <div className="text-lg font-bold">{sprayConditions.windSpeed} km/h</div>
                  <Badge className={getRiskColor(sprayConditions.windRisk)}>
                    {sprayConditions.windRisk.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-center mb-2">
                    <Thermometer size={16} className="mr-1" />
                    <span className="text-sm font-medium">Temperature</span>
                  </div>
                  <Badge className={getRiskColor(sprayConditions.temperatureRisk)}>
                    {sprayConditions.temperatureRisk.toUpperCase()}
                  </Badge>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-center mb-2">
                    <Droplets size={16} className="mr-1" />
                    <span className="text-sm font-medium">Humidity</span>
                  </div>
                  <Badge className={getRiskColor(sprayConditions.humidityRisk)}>
                    {sprayConditions.humidityRisk.toUpperCase()}
                  </Badge>
                </div>
              </div>

              {sprayConditions.alerts.length > 0 && (
                <div className="space-y-2">
                  <h5 className="font-medium text-gray-900">Current Alerts:</h5>
                  {sprayConditions.alerts.map((alert, index) => (
                    <Alert key={index} variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{alert}</AlertDescription>
                    </Alert>
                  ))}
                </div>
              )}

              {sprayConditions.recommendations.length > 0 && (
                <div className="space-y-2">
                  <h5 className="font-medium text-gray-900">Recommendations:</h5>
                  {sprayConditions.recommendations.map((rec, index) => (
                    <Alert key={index}>
                      <AlertDescription>{rec}</AlertDescription>
                    </Alert>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="text-gray-500">Spray condition data unavailable</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}