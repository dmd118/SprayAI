import { useState, useEffect } from "react";
import { Header } from "@/components/header";
import { SprayProducts } from "@/components/spray-products";
import { Fertilizers } from "@/components/fertilizers";
import { TurfAreas } from "@/components/turf-areas";
import { AIAnalysis } from "@/components/ai-analysis";
import { ApplicationRecords } from "@/components/application-records";
import { SeasonalPlanning } from "@/components/seasonal-planning";
import { IndustryNews } from "@/components/industry-news";
import { UsageTracker } from "@/components/usage-tracker";
import { SprayCan, Sprout, Map, Brain, ClipboardList, Calendar, TrendingUp, Newspaper } from "lucide-react";

type TabType = "spray-products" | "fertilizers" | "turf-areas" | "ai-analysis" | "application-records" | "seasonal-planning" | "industry-news";

const tabs = [
  {
    id: "spray-products" as TabType,
    label: "Spray Products",
    icon: SprayCan,
    component: SprayProducts,
  },
  {
    id: "fertilizers" as TabType,
    label: "G Fertilizers", 
    icon: Sprout,
    component: Fertilizers,
  },
  {
    id: "turf-areas" as TabType,
    label: "Areas",
    icon: Map,
    component: TurfAreas,
  },
  {
    id: "ai-analysis" as TabType,
    label: "AI Analysis",
    icon: Brain,
    component: AIAnalysis,
  },
  {
    id: "application-records" as TabType,
    label: "Application Records",
    icon: ClipboardList,
    component: ApplicationRecords,
  },
  {
    id: "seasonal-planning" as TabType,
    label: "Seasonal Planning",
    icon: Calendar,
    component: SeasonalPlanning,
  },
  {
    id: "industry-news" as TabType,
    label: "Industry News",
    icon: Newspaper,
    component: IndustryNews,
  },
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<TabType>("spray-products");
  const [showUsageAnalytics, setShowUsageAnalytics] = useState(false);

  useEffect(() => {
    const handleNavigateToSprayProducts = () => {
      setActiveTab("spray-products");
      setShowUsageAnalytics(false);
    };

    const handleShowUsageAnalytics = () => {
      setShowUsageAnalytics(true);
    };

    window.addEventListener('navigate-to-spray-products', handleNavigateToSprayProducts);
    window.addEventListener('show-usage-analytics', handleShowUsageAnalytics);
    
    return () => {
      window.removeEventListener('navigate-to-spray-products', handleNavigateToSprayProducts);
      window.removeEventListener('show-usage-analytics', handleShowUsageAnalytics);
    };
  }, []);

  const ActiveComponent = showUsageAnalytics ? UsageTracker : (tabs.find(tab => tab.id === activeTab)?.component || SprayProducts);

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
          <div className="flex justify-between sm:space-x-8 w-full" role="tablist">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id && !showUsageAnalytics;
              const words = tab.label.split(' ');
              const shortLabel = words.length > 1 ? `${words[0]} ${words[1]}` : words[0];
              
              return (
                <button
                  key={tab.id}
                  className={`
                    border-b-2 py-2 sm:py-4 px-0.5 text-[10px] sm:text-xs font-medium transition-colors duration-200 flex flex-col sm:flex-row items-center space-y-1 sm:space-y-0 sm:space-x-1 flex-1 text-center
                    ${isActive 
                      ? "border-primary text-primary" 
                      : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
                    }
                  `}
                  role="tab"
                  onClick={() => {
                    setActiveTab(tab.id);
                    setShowUsageAnalytics(false);
                  }}
                >
                  <Icon size={12} className="sm:w-4 sm:h-4" />
                  <span className="text-center leading-tight text-xs sm:text-sm">
                    <span className="sm:hidden">{shortLabel}</span>
                    <span className="hidden sm:inline">{tab.label}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="animate-in slide-in-from-right-4 duration-300">
          <ActiveComponent />
        </div>
      </main>
    </div>
  );
}
