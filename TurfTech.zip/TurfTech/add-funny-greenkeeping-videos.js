import { db } from './server/db.js';
import { industryNews } from './shared/schema.js';

async function addFunnyGreenkeepingVideos() {
  try {
    const youtubeApiKey = process.env.YOUTUBE_API_KEY;
    
    if (!youtubeApiKey) {
      console.error('YouTube API key not found. Please set YOUTUBE_API_KEY environment variable.');
      return;
    }

    console.log('Searching for funny greenkeeping videos...');

    // Search terms for funny greenkeeping content
    const searchTerms = [
      'funny golf course maintenance',
      'greenkeeper fails comedy',
      'golf course mowing funny moments',
      'groundskeeper funny videos',
      'turf management comedy',
      'golf course irrigation fails'
    ];

    const videos = [];

    for (const searchTerm of searchTerms) {
      try {
        const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(searchTerm)}&type=video&maxResults=3&order=relevance&key=${youtubeApiKey}`;
        
        console.log(`Searching for: ${searchTerm}`);
        const response = await fetch(searchUrl);
        
        if (!response.ok) {
          console.log(`YouTube API error for "${searchTerm}": ${response.status}`);
          continue;
        }
        
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
          // Filter for videos that seem genuinely funny/entertaining
          const relevantVideos = data.items.filter(video => {
            const title = video.snippet.title.toLowerCase();
            const description = video.snippet.description.toLowerCase();
            
            return (
              (title.includes('funny') || title.includes('fail') || title.includes('comedy') ||
               title.includes('epic') || title.includes('hilarious') || title.includes('bloopers') ||
               description.includes('funny') || description.includes('comedy') || description.includes('laugh')) &&
              (title.includes('golf') || title.includes('green') || title.includes('turf') ||
               title.includes('mow') || title.includes('lawn') || title.includes('course') ||
               description.includes('golf') || description.includes('maintenance') || description.includes('greenkeeper'))
            );
          });

          videos.push(...relevantVideos.slice(0, 1)); // Take best match from each search
        }
        
        // Small delay to respect rate limits
        await new Promise(resolve => setTimeout(resolve, 200));
        
      } catch (error) {
        console.log(`Error searching for "${searchTerm}":`, error.message);
      }
    }

    if (videos.length === 0) {
      console.log('No funny greenkeeping videos found. Adding some curated funny content...');
      
      // Add some funny fallback content if no videos found
      const fallbackContent = [
        {
          title: "When the Sprinkler System Has a Mind of Its Own",
          summary: "Every greenkeeper's nightmare - the irrigation system that decides to water everything except the grass!",
          content: "We've all been there - you program the sprinklers perfectly, and somehow they end up watering the car park, the clubhouse windows, and that one member who always complains about everything. Meanwhile, the greens are bone dry. It's like the system has developed a sense of humor!",
          category: "humor",
          source: "Greenkeeper Comedy Central",
          publishedDate: new Date(),
          relevantProducts: ["Irrigation Systems", "Sprinkler Controllers"],
          tags: ["funny", "irrigation", "fails", "comedy"],
          priority: "normal"
        },
        {
          title: "The Great Mower Escape of 2024",
          summary: "When your ride-on mower decides it prefers the sand bunker to the fairway - a comedy of errors!",
          content: "Picture this: You're cutting the 18th fairway, feeling professional, when suddenly your mower veers left like it's following a sat nav to nowhere. Next thing you know, you're doing donuts in the bunker while members watch in bewilderment. The mower stops, you get out covered in sand, and pretend it was all part of the 'aerification process'.",
          category: "humor", 
          source: "Turf Tales",
          publishedDate: new Date(),
          relevantProducts: ["Ride-on Mowers", "Fairway Equipment"],
          tags: ["funny", "mowing", "equipment", "fails"],
          priority: "normal"
        }
      ];

      for (const content of fallbackContent) {
        try {
          await db.insert(industryNews).values(content);
          console.log(`Added funny content: ${content.title}`);
        } catch (error) {
          console.log(`Error adding fallback content:`, error.message);
        }
      }
      
      return;
    }

    console.log(`Found ${videos.length} funny greenkeeping videos`);

    // Add videos to database
    for (const video of videos.slice(0, 6)) { // Limit to 6 videos max
      try {
        const videoUrl = `https://www.youtube.com/watch?v=${video.id.videoId}`;
        const thumbnail = video.snippet.thumbnails?.medium?.url || video.snippet.thumbnails?.default?.url;
        
        const newsItem = {
          title: `[VIDEO] ${video.snippet.title}`,
          summary: video.snippet.description.substring(0, 200) + (video.snippet.description.length > 200 ? '...' : ''),
          content: `Funny greenkeeping video: ${video.snippet.description}`,
          category: "humor",
          source: "YouTube - Greenkeeping Comedy",
          sourceUrl: videoUrl,
          imageUrl: thumbnail,
          publishedDate: new Date(video.snippet.publishedAt),
          relevantProducts: ["General Maintenance", "Equipment"],
          tags: ["funny", "video", "comedy", "greenkeeping"],
          priority: "normal"
        };

        await db.insert(industryNews).values(newsItem);
        console.log(`Added funny video: ${video.snippet.title}`);
        
      } catch (error) {
        console.log(`Error adding video "${video.snippet.title}":`, error.message);
      }
    }

    console.log('✅ Successfully added funny greenkeeping videos to industry news!');
    
  } catch (error) {
    console.error('Error adding funny greenkeeping videos:', error);
  }
}

// Run the function
addFunnyGreenkeepingVideos().then(() => {
  console.log('Script completed');
  process.exit(0);
}).catch(error => {
  console.error('Script failed:', error);
  process.exit(1);
});