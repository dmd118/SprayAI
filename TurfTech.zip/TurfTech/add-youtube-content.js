// Add YouTube educational content to industry news database
import { storage } from './server/storage.js';

async function addYouTubeEducationalContent() {
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;
  if (!youtubeApiKey) {
    console.log('YouTube API key not found');
    return;
  }

  const searches = [
    'golf course superintendent maintenance',
    'greenkeeper training techniques',
    'turf equipment demonstration'
  ];

  let addedCount = 0;

  for (const query of searches) {
    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&videoDuration=medium&order=relevance&maxResults=3&key=${youtubeApiKey}`
      );
      
      if (response.ok) {
        const data = await response.json();
        
        const professionalVideos = data.items?.filter((video) => {
          const title = video.snippet?.title?.toLowerCase() || '';
          const channelTitle = video.snippet?.channelTitle?.toLowerCase() || '';
          
          return channelTitle.includes('golf course') || 
                 channelTitle.includes('turf') ||
                 channelTitle.includes('greenkeeper') ||
                 channelTitle.includes('superintendent') ||
                 title.includes('training') ||
                 title.includes('demonstration');
        }) || [];

        for (const video of professionalVideos) {
          try {
            const existingNews = await storage.getIndustryNews();
            const existingVideo = existingNews.find(existing => 
              existing.sourceUrl?.includes(video.id.videoId)
            );
            if (existingVideo) continue;
            
            const videoUrl = `https://www.youtube.com/watch?v=${video.id.videoId}`;
            const newsItem = {
              title: `[VIDEO] ${video.snippet.title}`,
              summary: (video.snippet.description || '').substring(0, 300),
              content: `Educational video from ${video.snippet.channelTitle}: ${video.snippet.description || 'Professional greenkeeping demonstration and training content.'}`,
              category: 'techniques',
              source: video.snippet.channelTitle || 'YouTube Educational',
              sourceUrl: videoUrl,
              publishedDate: new Date(video.snippet.publishedAt),
              relevantProducts: [],
              tags: ['video', 'education', 'training'],
              priority: 'high'
            };
            
            await storage.createIndustryNews(newsItem);
            addedCount++;
            console.log(`Added: ${video.snippet.title}`);
          } catch (error) {
            console.error('Error adding video:', error);
          }
        }
      }
    } catch (error) {
      console.error(`Search failed for "${query}":`, error);
    }
  }
  
  console.log(`\nTotal educational videos added: ${addedCount}`);
}

addYouTubeEducationalContent().catch(console.error);