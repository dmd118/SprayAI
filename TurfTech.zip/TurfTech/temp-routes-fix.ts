  // Staff Rota Routes
  app.get("/api/staff-rota", async (req, res) => {
    try {
      let rotaData = await storage.getStaffRota();
      res.json(rotaData || []);
    } catch (error) {
      console.error("Staff rota fetch error:", error);
      res.status(500).json({ message: "Failed to fetch staff rota" });
    }
  });

  app.post("/api/staff-rota/generate", async (req, res) => {
    try {
      const { staffRotaAI } = await import('./staff-rota-ai');
      const params = req.body;
      const result = await staffRotaAI.generateOptimalRota(params);
      res.json(result);
    } catch (error) {
      console.error("Rota generation error:", error);
      res.status(500).json({ message: "Failed to generate rota" });
    }
  });

  app.delete("/api/staff-rota/clear", async (req, res) => {
    try {
      await storage.clearAllStaffRotaEntries();
      res.json({ success: true, message: "Rota cleared successfully" });
    } catch (error) {
      console.error("Rota clear error:", error);
      res.status(500).json({ message: "Failed to clear rota" });
    }
  });

  // Time Off Management Routes
  app.get("/api/time-off-requests", async (req, res) => {
    try {
      res.json([]);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time off requests" });
    }
  });

  app.post("/api/timeoff-request", async (req, res) => {
    try {
      const { staffId, startDate, endDate, reason, status = 'approved' } = req.body;
      
      const timeOffRequest = {
        id: Date.now(),
        staffId,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        reason,
        status,
        requestedAt: new Date(),
        reviewedAt: new Date(),
        reviewedBy: 'System',
        notes: 'Auto-approved for calendar integration demo'
      };

      res.status(201).json({
        success: true,
        request: timeOffRequest,
        message: `Time off request approved for staff member ${staffId}`
      });
    } catch (error) {
      res.status(500).json({ 
        success: false,
        message: "Failed to submit time off request" 
      });
    }
  });