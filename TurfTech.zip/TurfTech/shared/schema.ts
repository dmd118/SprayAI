import { pgTable, text, serial, real, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Clubs Table - Multi-tenant support
export const clubs = pgTable("clubs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(), // For weather data
  subscriptionStatus: text("subscription_status").notNull().default("active"), // active, inactive, grandfathered_active
  subscriptionTier: text("subscription_tier").notNull().default("premium"), // basic, standard, premium
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Users Table - User authentication linked to clubs
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("admin"), // admin, member
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User News Preferences - Individual news interaction tracking
export const userNewsPreferences = pgTable("user_news_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  newsId: integer("news_id").references(() => industryNews.id).notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  isFavourited: boolean("is_favourited").default(false).notNull(),
  isHidden: boolean("is_hidden").default(false).notNull(), // User's "delete" preference
  interactedAt: timestamp("interacted_at").defaultNow().notNull(),
});

// Spray Products Table
export const sprayProducts = pgTable("spray_products", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // Herbicide, Fungicide, Insecticide, Growth Regulator
  activeIngredient: text("active_ingredient").notNull(),
  labelRate: text("label_rate").notNull(),
  brand: text("brand"),
  compatibilityNotes: text("compatibility_notes"),
  status: text("status").notNull().default("Active"), // Active, Inactive
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Granular Fertilizers Table
export const granularFertilizers = pgTable("granular_fertilizers", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  npkAnalysis: text("npk_analysis").notNull(), // e.g., "21-22-4"
  applicationRate: text("application_rate").notNull(),
  spreaderSetting: real("spreader_setting").notNull(),
  spreaderType: text("spreader_type").notNull(), // Drop, Broadcast
  coverage: text("coverage").notNull(), // e.g., "15,000 sq ft/50lb bag"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Turf Areas Table
export const turfAreas = pgTable("turf_areas", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // Green, Tee, Fairway
  hectares: real("hectares").notNull(),
  squareFeet: integer("square_feet").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Application Records Table
export const applicationRecords = pgTable("application_records", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  date: timestamp("date").notNull(),
  type: text("type").notNull(), // Spray, Fertilizer
  products: text("products").notNull(), // JSON string of product names
  productDetails: text("product_details").notNull(),
  areaId: integer("area_id").references(() => turfAreas.id).notNull(),
  areaName: text("area_name").notNull(),
  rate: text("rate").notNull(),
  weather: text("weather").notNull(),
  waterVolume: text("water_volume"), // For spray applications
  spreaderSetting: text("spreader_setting"), // For fertilizer applications
  notes: text("notes"),
  expertAnalysis: text("expert_analysis"), // AI-generated professional analysis
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// AI Analysis Results Table
export const aiAnalysisResults = pgTable("ai_analysis_results", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  productIds: text("product_ids").notNull(), // JSON array of product IDs
  compatibility: text("compatibility").notNull(), // JSON object with analysis
  calculations: text("calculations").notNull(), // JSON object with calculations
  targetAreaId: integer("target_area_id").references(() => turfAreas.id).notNull(),
  waterVolume: text("water_volume").notNull(),
  nozzleType: text("nozzle_type").notNull(),
  barPressure: text("bar_pressure").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Seasonal Plans Table
export const seasonalPlans = pgTable("seasonal_plans", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  name: text("name").notNull(),
  season: text("season").notNull(), // spring, summer, autumn, winter
  year: integer("year").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  description: text("description"),
  status: text("status").notNull().default("active"), // active, completed, archived
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Scheduled Applications Table
export const scheduledApplications = pgTable("scheduled_applications", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  seasonalPlanId: integer("seasonal_plan_id").notNull().references(() => seasonalPlans.id),
  productId: integer("product_id").notNull().references(() => sprayProducts.id),
  areaId: integer("area_id").notNull().references(() => turfAreas.id),
  scheduledDate: timestamp("scheduled_date").notNull(),
  applicationRate: text("application_rate").notNull(),
  waterVolume: text("water_volume").notNull(),
  weatherRequirements: text("weather_requirements"), // ideal conditions
  notes: text("notes"),
  status: text("status").notNull().default("scheduled"), // scheduled, completed, postponed, cancelled
  completedDate: timestamp("completed_date"),
  actualWeatherConditions: text("actual_weather_conditions"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Industry News Table - Shared content across all clubs
export const industryNews = pgTable("industry_news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  content: text("content"),
  category: text("category").notNull(), // products, news, events, research, regulations
  source: text("source").notNull(),
  sourceUrl: text("source_url"),
  imageUrl: text("image_url"),
  publishedDate: timestamp("published_date").notNull(),
  relevantProducts: text("relevant_products").array(), // Related product types
  tags: text("tags").array(),
  priority: text("priority").notNull().default("normal"), // high, normal, low
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Staff Members Table - Redesigned for new requirements
export const staffMembers = pgTable("staff_members", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  name: text("name").notNull(), // Format: 1F, 2F, 3F...7F, 8S, 9S, 10S, 11S
  staffType: text("staff_type").notNull(), // F (full-time) or S (seasonal)
  email: text("email"),
  phoneNumber: text("phone_number"),
  startDate: timestamp("start_date").notNull(),
  holidayDaysAccrued: real("holiday_days_accrued").default(0).notNull(), // 2.5 days per month
  holidayDaysTaken: real("holiday_days_taken").default(0).notNull(),
  weekendShiftsWorked: integer("weekend_shifts_worked").default(0).notNull(),
  totalHoursWorked: real("total_hours_worked").default(0).notNull(),
  lastWeekendWorked: timestamp("last_weekend_worked"),
  consecutiveWeekends: integer("consecutive_weekends").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Saved Rotas Table - Main rota storage
export const savedRotas = pgTable("saved_rotas", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  name: text("name").notNull(), // e.g., "January 2025 Rota"
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
  status: text("status").notNull().default("active"), // active, archived, deleted
  notes: text("notes"),
  createdBy: text("created_by").default("System").notNull(),
});

// Rota Shifts Table - Individual shift assignments
export const rotaShifts = pgTable("rota_shifts", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  rotaId: integer("rota_id").references(() => savedRotas.id).notNull(),
  staffId: integer("staff_id").references(() => staffMembers.id).notNull(),
  staffName: text("staff_name").notNull(),
  date: timestamp("date").notNull(),
  dayOfWeek: text("day_of_week").notNull(), // Monday, Tuesday, etc.
  shiftType: text("shift_type").notNull(), // weekday, weekend, holiday, monday_off
  startTime: text("start_time"), // null for days off
  endTime: text("end_time"), // null for days off
  hoursWorked: real("hours_worked").default(0).notNull(),
  isHoliday: boolean("is_holiday").default(false).notNull(),
  isMonday: boolean("is_monday_off").default(false).notNull(), // Monday off after weekend
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Holiday Bookings Table
export const holidayBookings = pgTable("holiday_bookings", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  staffId: integer("staff_id").references(() => staffMembers.id).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  daysBooked: real("days_booked").notNull(),
  reason: text("reason").default("Annual Leave").notNull(),
  status: text("status").notNull().default("approved"), // booked, approved, cancelled
  bookedAt: timestamp("booked_at").defaultNow().notNull(),
});

// Time Off Requests Table
export const timeOffRequests = pgTable("time_off_requests", {
  id: serial("id").primaryKey(),
  clubId: integer("club_id").references(() => clubs.id).notNull(),
  staffId: integer("staff_id").references(() => staffMembers.id).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, denied
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: text("reviewed_by"),
  notes: text("notes"),
});

// Multi-tenant types
export type Club = typeof clubs.$inferSelect;
export type User = typeof users.$inferSelect;
export type UserNewsPreference = typeof userNewsPreferences.$inferSelect;

// Rota system types
export type StaffMember = typeof staffMembers.$inferSelect;
export type SavedRota = typeof savedRotas.$inferSelect;
export type RotaShift = typeof rotaShifts.$inferSelect;
export type HolidayBooking = typeof holidayBookings.$inferSelect;
export type TimeOffRequest = typeof timeOffRequests.$inferSelect;

// Insert types for time off requests
export const insertTimeOffRequestSchema = createInsertSchema(timeOffRequests).omit({
  id: true,
  requestedAt: true,
  reviewedAt: true,
});

export type InsertTimeOffRequest = z.infer<typeof insertTimeOffRequestSchema>;

// Insert schemas for authentication
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertClubSchema = createInsertSchema(clubs).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertClub = z.infer<typeof insertClubSchema>;

// Insert Schemas
export const insertSprayProductSchema = createInsertSchema(sprayProducts).omit({
  id: true,
  createdAt: true,
});

export const insertGranularFertilizerSchema = createInsertSchema(granularFertilizers).omit({
  id: true,
  createdAt: true,
});

export const insertTurfAreaSchema = createInsertSchema(turfAreas).omit({
  id: true,
  lastUpdated: true,
});

export const insertApplicationRecordSchema = createInsertSchema(applicationRecords).omit({
  id: true,
  createdAt: true,
}).extend({
  date: z.string().transform((str) => {
    // Handle formats like "30/05/2025 07:00-10:00am"
    if (str.includes('/') && str.includes('-')) {
      const [datePart, timePart] = str.split(' ');
      const [day, month, year] = datePart.split('/');
      const [startTime] = timePart.split('-');
      
      // Parse time like "07:00am"
      let hours = parseInt(startTime.split(':')[0]);
      const minutes = parseInt(startTime.split(':')[1].replace(/[ap]m/i, ''));
      
      if (startTime.toLowerCase().includes('pm') && hours !== 12) {
        hours += 12;
      } else if (startTime.toLowerCase().includes('am') && hours === 12) {
        hours = 0;
      }
      
      return new Date(parseInt(year), parseInt(month) - 1, parseInt(day), hours, minutes);
    }
    return new Date(str);
  }),
});

export const insertAiAnalysisResultSchema = createInsertSchema(aiAnalysisResults).omit({
  id: true,
  createdAt: true,
});

export const insertSeasonalPlanSchema = createInsertSchema(seasonalPlans).omit({
  id: true,
  createdAt: true,
});

export const insertScheduledApplicationSchema = createInsertSchema(scheduledApplications).omit({
  id: true,
  createdAt: true,
});

export const insertIndustryNewsSchema = createInsertSchema(industryNews).omit({
  id: true,
  createdAt: true,
});

export const insertStaffMemberSchema = createInsertSchema(staffMembers).omit({
  id: true,
  createdAt: true,
});

export const insertSavedRotaSchema = createInsertSchema(savedRotas).omit({
  id: true,
  generatedAt: true,
});

export const insertRotaShiftSchema = createInsertSchema(rotaShifts).omit({
  id: true,
  createdAt: true,
});

export const insertHolidayBookingSchema = createInsertSchema(holidayBookings).omit({
  id: true,
  bookedAt: true,
});



// Operational spray parameters for real-world calculations
export const sprayOperationalParams = pgTable("spray_operational_params", {
  id: serial("id").primaryKey(),
  targetArea: text("target_area").notNull(), // "greens", "fairways", "rough", "tees"
  tractorSpeedKmh: real("tractor_speed_kmh").notNull(),
  recommendedNozzleType: text("recommended_nozzle_type").notNull(), // "red", "yellow", "white"
  nozzleFlowRateLMin: real("nozzle_flow_rate_l_min").notNull(),
  sprayWidthMeters: real("spray_width_meters").notNull(),
  maxApplicationRateLHa: real("max_application_rate_l_ha").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertSprayOperationalParamsSchema = createInsertSchema(sprayOperationalParams).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

// Types
export type SprayProduct = typeof sprayProducts.$inferSelect;
export type InsertSprayProduct = z.infer<typeof insertSprayProductSchema>;

export type GranularFertilizer = typeof granularFertilizers.$inferSelect;
export type InsertGranularFertilizer = z.infer<typeof insertGranularFertilizerSchema>;

export type TurfArea = typeof turfAreas.$inferSelect;
export type InsertTurfArea = z.infer<typeof insertTurfAreaSchema>;

export type ApplicationRecord = typeof applicationRecords.$inferSelect;
export type InsertApplicationRecord = z.infer<typeof insertApplicationRecordSchema>;

export type AiAnalysisResult = typeof aiAnalysisResults.$inferSelect;
export type InsertAiAnalysisResult = z.infer<typeof insertAiAnalysisResultSchema>;

export type SeasonalPlan = typeof seasonalPlans.$inferSelect;
export type InsertSeasonalPlan = z.infer<typeof insertSeasonalPlanSchema>;

export type ScheduledApplication = typeof scheduledApplications.$inferSelect;
export type InsertScheduledApplication = z.infer<typeof insertScheduledApplicationSchema>;

export type IndustryNews = typeof industryNews.$inferSelect;
export type InsertIndustryNews = z.infer<typeof insertIndustryNewsSchema>;

export type SprayOperationalParams = typeof sprayOperationalParams.$inferSelect;
export type InsertSprayOperationalParams = z.infer<typeof insertSprayOperationalParamsSchema>;

export type InsertStaffMember = z.infer<typeof insertStaffMemberSchema>;
export type InsertSavedRota = z.infer<typeof insertSavedRotaSchema>;
export type InsertRotaShift = z.infer<typeof insertRotaShiftSchema>;
export type InsertHolidayBooking = z.infer<typeof insertHolidayBookingSchema>;


