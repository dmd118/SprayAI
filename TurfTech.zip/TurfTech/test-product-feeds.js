// Test the new product-focused RSS feeds
import { fetchAndStoreProfessionalRSSContent } from './server/news-aggregator.js';

async function testProductFeeds() {
  try {
    console.log('Testing product-focused RSS feeds...');
    const result = await fetchAndStoreProfessionalRSSContent();
    
    console.log('\n=== PROFESSIONAL RSS RESULTS ===');
    console.log(`Success: ${result.success}`);
    console.log(`Articles found: ${result.count}`);
    if (result.errors && result.errors.length > 0) {
      console.log('Errors:', result.errors);
    }
    
  } catch (error) {
    console.error('Error testing feeds:', error);
  }
}

testProductFeeds();