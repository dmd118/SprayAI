// Enhanced Resilience System for 24/7 Operations
import { Express } from 'express';

interface CircuitBreakerState {
  isOpen: boolean;
  failures: number;
  lastFailure: Date | null;
  successCount: number;
}

class ResilienceSystem {
  private circuitBreakers = new Map<string, CircuitBreakerState>();
  private requestQueue: Array<{ req: any; res: any; next: any }> = [];
  private isProcessingQueue = false;

  constructor(private app: Express) {}

  public initialize(): void {
    this.setupCircuitBreakers();
    this.setupRequestQueuing();
    this.setupRetryLogic();
    this.setupCacheHeaders();
    this.setupConnectionPooling();
    
    console.log('🛡️ Resilience system activated for 24/7 uptime');
  }

  private setupCircuitBreakers(): void {
    const services = ['weather', 'news', 'openai', 'youtube'];
    
    services.forEach(service => {
      this.circuitBreakers.set(service, {
        isOpen: false,
        failures: 0,
        lastFailure: null,
        successCount: 0
      });
    });

    // Circuit breaker middleware
    this.app.use('/api', (req, res, next) => {
      const service = this.getServiceFromPath(req.path);
      const breaker = this.circuitBreakers.get(service);
      
      if (breaker && breaker.isOpen) {
        const timeSinceFailure = Date.now() - (breaker.lastFailure?.getTime() || 0);
        
        // Reset circuit breaker after 60 seconds
        if (timeSinceFailure > 60000) {
          breaker.isOpen = false;
          breaker.failures = 0;
          console.log(`🔄 Circuit breaker reset for ${service}`);
        } else {
          return res.status(503).json({ 
            error: 'Service temporarily unavailable',
            service,
            retryAfter: Math.ceil((60000 - timeSinceFailure) / 1000)
          });
        }
      }
      
      next();
    });
  }

  private setupRequestQueuing(): void {
    this.app.use((req, res, next) => {
      // Queue requests during high load
      if (this.requestQueue.length > 50) {
        this.requestQueue.push({ req, res, next });
        
        if (!this.isProcessingQueue) {
          this.processQueue();
        }
        return;
      }
      
      next();
    });
  }

  private async processQueue(): Promise<void> {
    this.isProcessingQueue = true;
    
    while (this.requestQueue.length > 0) {
      const { req, res, next } = this.requestQueue.shift()!;
      
      try {
        await new Promise(resolve => {
          const originalEnd = res.end;
          res.end = function(...args: any[]) {
            originalEnd.apply(this, args);
            resolve(void 0);
          };
          next();
        });
      } catch (error) {
        console.error('Queue processing error:', error);
      }
      
      // Small delay to prevent overwhelming
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    
    this.isProcessingQueue = false;
  }

  private setupRetryLogic(): void {
    const originalFetch = global.fetch;
    
    global.fetch = async (url: RequestInfo | URL, options?: RequestInit) => {
      const maxRetries = 3;
      let lastError;
      
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 15000);
          
          const response = await originalFetch(url, {
            ...options,
            signal: controller.signal
          });
          
          clearTimeout(timeoutId);
          
          if (response.ok) {
            this.recordSuccess(this.getServiceFromUrl(url.toString()));
            return response;
          }
          
          if (response.status >= 500 && attempt < maxRetries) {
            await this.delay(Math.pow(2, attempt) * 1000); // Exponential backoff
            continue;
          }
          
          return response;
        } catch (error) {
          lastError = error;
          this.recordFailure(this.getServiceFromUrl(url.toString()));
          
          if (attempt < maxRetries) {
            await this.delay(Math.pow(2, attempt) * 1000);
            continue;
          }
        }
      }
      
      throw lastError;
    };
  }

  private setupCacheHeaders(): void {
    this.app.use((req, res, next) => {
      if (req.method === 'GET' && req.path.startsWith('/api/')) {
        // Set cache headers for static data
        if (req.path.includes('/spray-products') || req.path.includes('/areas')) {
          res.set('Cache-Control', 'public, max-age=300'); // 5 minutes
        }
        
        // Weather data cache
        if (req.path.includes('/weather')) {
          res.set('Cache-Control', 'public, max-age=60'); // 1 minute
        }
      }
      
      next();
    });
  }

  private setupConnectionPooling(): void {
    // Configure keep-alive for outbound connections
    import('http').then(http => {
      import('https').then(https => {
        const httpAgent = new http.Agent({
          keepAlive: true,
          maxSockets: 50,
          maxFreeSockets: 10,
          timeout: 60000
        });
        
        const httpsAgent = new https.Agent({
          keepAlive: true,
          maxSockets: 50,
          maxFreeSockets: 10,
          timeout: 60000
        });
        
        // Store agents globally for reuse
        (global as any).httpAgent = httpAgent;
        (global as any).httpsAgent = httpsAgent;
      });
    });
  }

  private recordSuccess(service: string): void {
    const breaker = this.circuitBreakers.get(service);
    if (breaker) {
      breaker.successCount++;
      breaker.failures = 0;
      if (breaker.isOpen && breaker.successCount >= 3) {
        breaker.isOpen = false;
        console.log(`✅ Circuit breaker closed for ${service}`);
      }
    }
  }

  private recordFailure(service: string): void {
    const breaker = this.circuitBreakers.get(service);
    if (breaker) {
      breaker.failures++;
      breaker.lastFailure = new Date();
      breaker.successCount = 0;
      
      if (breaker.failures >= 5) {
        breaker.isOpen = true;
        console.warn(`⚠️ Circuit breaker opened for ${service}`);
      }
    }
  }

  private getServiceFromPath(path: string): string {
    if (path.includes('weather')) return 'weather';
    if (path.includes('news')) return 'news';
    if (path.includes('ai-assistant')) return 'openai';
    if (path.includes('youtube')) return 'youtube';
    return 'unknown';
  }

  private getServiceFromUrl(url: string): string {
    if (url.includes('openweathermap')) return 'weather';
    if (url.includes('newsapi')) return 'news';
    if (url.includes('openai')) return 'openai';
    if (url.includes('youtube') || url.includes('googleapis')) return 'youtube';
    return 'unknown';
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  public getStatus() {
    const status: any = {};
    this.circuitBreakers.forEach((breaker, service) => {
      status[service] = {
        isHealthy: !breaker.isOpen,
        failures: breaker.failures,
        successCount: breaker.successCount
      };
    });
    return status;
  }
}

export { ResilienceSystem };