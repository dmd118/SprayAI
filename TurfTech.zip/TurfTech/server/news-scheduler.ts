import cron from 'node-cron';
import { 
  fetchAndStoreNews, 
  cleanOldNews, 
  harvestRSSContent, 
  fetchAndStoreRedditContent,
  fetchAndStoreFunnyVideos,
  fetchEducationalYouTubeContent,
  addFallbackContent 
} from './news-aggregator';
import { storage } from './storage';

let isSchedulerRunning = false;
let scheduledTasks: any[] = [];

export function startNewsScheduler(newsApiKey?: string): void {
  if (isSchedulerRunning) {
    console.log('News scheduler already running');
    return;
  }

  console.log('Starting news scheduler...');
  
  // Fresh content fetch every morning at 5am with failsafe redundancy
  const morningNewsTask = cron.schedule('0 5 * * *', async () => {
    console.log('Running morning fresh content fetch at 5am...');
    try {
      // Parallel execution with individual error handling - all content sources
      const contentPromises = [
        fetchAndStoreNews(newsApiKey).catch(err => ({ count: 0, errors: [`News API failed: ${err.message}`] })),
        harvestRSSContent().catch(err => ({ count: 0, errors: [`RSS feeds failed: ${err.message}`] })),
        fetchAndStoreRedditContent().catch(err => ({ count: 0, errors: [`Reddit failed: ${err.message}`] })),
        fetchAndStoreFunnyVideos().catch((err: any) => ({ count: 0, errors: [`YouTube videos failed: ${err.message}`] })),
        fetchEducationalYouTubeContent().catch((err: any) => ({ count: 0, errors: [`YouTube education failed: ${err.message}`] }))
      ];
      
      const [newsResult, rssResult, redditResult, youtubeResult, educationalResult] = await Promise.all(contentPromises);
      
      const totalCount = newsResult.count + rssResult.count + redditResult.count + youtubeResult.count + educationalResult.count;
      console.log(`Morning content fetch completed: ${totalCount} new items`);
      console.log(`- News API: ${newsResult.count} articles`);
      console.log(`- RSS Feeds: ${rssResult.count} articles`);
      console.log(`- Reddit: ${redditResult.count} discussions`);
      console.log(`- YouTube Entertainment: ${youtubeResult.count} videos`);
      console.log(`- YouTube Educational: ${educationalResult.count} videos`);
      
      // Minimum content guarantee - ensure at least 5 pieces of content daily
      if (totalCount < 5) {
        console.log('Low content count, activating emergency backup systems...');
        try {
          const backupResult = await addFallbackContent();
          console.log(`Emergency backup added: ${backupResult.count} articles`);
        } catch (backupError) {
          console.error('Emergency backup failed:', backupError);
        }
      }
      
      const allErrors = [...newsResult.errors, ...rssResult.errors, ...redditResult.errors, ...youtubeResult.errors];
      if (allErrors.length > 0) {
        console.warn('Content fetch warnings:', allErrors);
      }
    } catch (error) {
      console.error('Morning content fetch failed:', error);
    }
  });

  // Supplementary fetch every 6 hours for breaking news
  const supplementaryTask = cron.schedule('0 */6 * * *', async () => {
    console.log('Running supplementary content check...');
    try {
      const result = await fetchAndStoreNews(newsApiKey);
      if (result.count > 0) {
        console.log(`Supplementary fetch: ${result.count} new articles added`);
      }
    } catch (error) {
      console.error('Supplementary fetch failed:', error);
    }
  });

  // Content quality check every 12 hours
  const qualityCheck = cron.schedule('0 */12 * * *', async () => {
    try {
      const existingNews = await storage.getIndustryNews();
      const recentArticles = existingNews.filter(article => {
        const hoursAgo = (Date.now() - new Date(article.createdAt).getTime()) / (1000 * 60 * 60);
        return hoursAgo <= 48;
      });
      
      console.log(`Quality check: ${recentArticles.length} articles in last 48 hours`);
      
      if (recentArticles.length < 3) {
        console.log('Insufficient recent content, triggering backup systems...');
        await fetchAndStoreNews(newsApiKey);
        await harvestRSSContent();
      }
    } catch (error) {
      console.error('Quality check failed:', error);
    }
  });

  // Clean old news daily at 2 AM (keep articles for 90 days for reference)
  const cleanupTask = cron.schedule('0 2 * * *', async () => {
    console.log('Running scheduled news cleanup...');
    try {
      const deletedCount = await cleanOldNews(90); // Keep 90 days for reading again
      console.log(`Cleaned up ${deletedCount} old news articles (kept 90 days)`);
    } catch (error) {
      console.error('News cleanup failed:', error);
    }
  });

  scheduledTasks = [morningNewsTask, supplementaryTask, qualityCheck, cleanupTask];

  isSchedulerRunning = true;
  console.log('Enhanced news scheduler started - fresh greenkeeping content at 5am daily with quality filters and duplicate prevention');
}

export function stopNewsScheduler(): void {
  scheduledTasks.forEach(task => task.stop());
  scheduledTasks = [];
  isSchedulerRunning = false;
  console.log('News scheduler stopped');
}

export async function fetchNewsNow(newsApiKey?: string): Promise<{ success: boolean; count: number; errors: string[] }> {
  console.log('Manually triggering news fetch...');
  return await fetchAndStoreNews(newsApiKey);
}