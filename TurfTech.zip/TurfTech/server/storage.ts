import { 
  sprayProducts, 
  granularFertilizers, 
  turfAreas, 
  applicationRecords, 
  aiAnalysisResults,
  seasonalPlans,
  scheduledApplications,
  industryNews,
  staffMembers,
  savedRotas,
  rotaShifts,
  holidayBookings,
  timeOffRequests,
  clubs,
  users,
  type SprayProduct, 
  type InsertSprayProduct,
  type GranularFertilizer,
  type InsertGranularFertilizer,
  type TurfArea,
  type InsertTurfArea,
  type ApplicationRecord,
  type InsertApplicationRecord,
  type AiAnalysisResult,
  type InsertAiAnalysisResult,
  type SeasonalPlan,
  type InsertSeasonalPlan,
  type ScheduledApplication,
  type InsertScheduledApplication,
  type IndustryNews,
  type InsertIndustryNews,
  type StaffMember,
  type InsertStaffMember,
  type SavedRota,
  type InsertSavedRota,
  type RotaShift,
  type InsertRotaShift,
  type HolidayBooking,
  type InsertHolidayBooking,
  type TimeOffRequest,
  type InsertTimeOffRequest,
  type User,
  type InsertUser,
  type Club,
  type InsertClub
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Spray Products
  getSprayProducts(clubId?: number): Promise<SprayProduct[]>;
  getSprayProduct(id: number, clubId?: number): Promise<SprayProduct | undefined>;
  createSprayProduct(product: InsertSprayProduct): Promise<SprayProduct>;
  updateSprayProduct(id: number, product: Partial<InsertSprayProduct>, clubId?: number): Promise<SprayProduct | undefined>;
  deleteSprayProduct(id: number): Promise<boolean>;

  // Granular Fertilizers
  getGranularFertilizers(): Promise<GranularFertilizer[]>;
  getGranularFertilizer(id: number): Promise<GranularFertilizer | undefined>;
  createGranularFertilizer(fertilizer: InsertGranularFertilizer): Promise<GranularFertilizer>;
  updateGranularFertilizer(id: number, fertilizer: Partial<InsertGranularFertilizer>): Promise<GranularFertilizer | undefined>;
  deleteGranularFertilizer(id: number): Promise<boolean>;

  // Turf Areas
  getTurfAreas(): Promise<TurfArea[]>;
  getTurfArea(id: number): Promise<TurfArea | undefined>;
  createTurfArea(area: InsertTurfArea): Promise<TurfArea>;
  updateTurfArea(id: number, area: Partial<InsertTurfArea>): Promise<TurfArea | undefined>;
  deleteTurfArea(id: number): Promise<boolean>;

  // Application Records
  getApplicationRecords(): Promise<ApplicationRecord[]>;
  getApplicationRecord(id: number): Promise<ApplicationRecord | undefined>;
  createApplicationRecord(record: InsertApplicationRecord): Promise<ApplicationRecord>;
  updateApplicationRecord(id: number, record: Partial<InsertApplicationRecord>): Promise<ApplicationRecord | undefined>;
  deleteApplicationRecord(id: number): Promise<boolean>;

  // AI Analysis Results
  getAiAnalysisResults(): Promise<AiAnalysisResult[]>;
  getAiAnalysisResult(id: number): Promise<AiAnalysisResult | undefined>;
  createAiAnalysisResult(result: InsertAiAnalysisResult): Promise<AiAnalysisResult>;

  // Seasonal Plans
  getSeasonalPlans(): Promise<SeasonalPlan[]>;
  getSeasonalPlan(id: number): Promise<SeasonalPlan | undefined>;
  createSeasonalPlan(plan: InsertSeasonalPlan): Promise<SeasonalPlan>;
  updateSeasonalPlan(id: number, plan: Partial<InsertSeasonalPlan>): Promise<SeasonalPlan | undefined>;
  deleteSeasonalPlan(id: number): Promise<boolean>;

  // Scheduled Applications
  getScheduledApplications(): Promise<ScheduledApplication[]>;
  getScheduledApplicationsByPlan(planId: number): Promise<ScheduledApplication[]>;
  getScheduledApplication(id: number): Promise<ScheduledApplication | undefined>;
  createScheduledApplication(application: InsertScheduledApplication): Promise<ScheduledApplication>;
  updateScheduledApplication(id: number, application: Partial<InsertScheduledApplication>): Promise<ScheduledApplication | undefined>;
  deleteScheduledApplication(id: number): Promise<boolean>;

  // Industry News
  getIndustryNews(): Promise<IndustryNews[]>;
  getIndustryNewsByCategory(category: string): Promise<IndustryNews[]>;
  getIndustryNewsItem(id: number): Promise<IndustryNews | undefined>;
  createIndustryNews(news: InsertIndustryNews): Promise<IndustryNews>;
  updateIndustryNews(id: number, news: Partial<InsertIndustryNews>): Promise<IndustryNews | undefined>;
  updateIndustryNewsCategory(id: number, category: string): Promise<IndustryNews | undefined>;
  updateIndustryNewsReadStatus(id: number, isRead: boolean): Promise<IndustryNews | undefined>;
  updateIndustryNewsFavouriteStatus(id: number, isFavourited: boolean): Promise<IndustryNews | undefined>;
  deleteIndustryNews(id: number): Promise<boolean>;

  // Staff Management
  getStaffMembers(): Promise<StaffMember[]>;
  getStaffMember(id: number): Promise<StaffMember | undefined>;
  createStaffMember(member: InsertStaffMember): Promise<StaffMember>;
  updateStaffMember(id: number, member: Partial<InsertStaffMember>): Promise<StaffMember | undefined>;
  deleteStaffMember(id: number): Promise<boolean>;

  // Saved Rotas
  getSavedRotas(): Promise<SavedRota[]>;
  getSavedRota(id: number): Promise<SavedRota | undefined>;
  createSavedRota(rota: InsertSavedRota): Promise<SavedRota>;
  updateSavedRota(id: number, rota: Partial<InsertSavedRota>): Promise<SavedRota | undefined>;
  deleteSavedRota(id: number): Promise<boolean>;

  // Rota Shifts
  getRotaShifts(rotaId: number): Promise<RotaShift[]>;
  getRotaShiftsByDate(startDate: Date, endDate: Date): Promise<RotaShift[]>;
  createRotaShift(shift: InsertRotaShift): Promise<RotaShift>;
  updateRotaShift(id: number, shift: Partial<InsertRotaShift>): Promise<RotaShift | undefined>;
  deleteRotaShift(id: number): Promise<boolean>;

  // Holiday Bookings
  getHolidayBookings(staffId?: number): Promise<HolidayBooking[]>;
  getHolidayBooking(id: number): Promise<HolidayBooking | undefined>;
  createHolidayBooking(booking: InsertHolidayBooking): Promise<HolidayBooking>;
  updateHolidayBooking(id: number, booking: Partial<InsertHolidayBooking>): Promise<HolidayBooking | undefined>;
  deleteHolidayBooking(id: number): Promise<boolean>;

  // Time Off Requests
  getTimeOffRequests(staffId: number): Promise<TimeOffRequest[]>;
  getTimeOffRequest(id: number): Promise<TimeOffRequest | undefined>;
  createTimeOffRequest(request: InsertTimeOffRequest): Promise<TimeOffRequest>;
  updateTimeOffRequest(id: number, request: Partial<InsertTimeOffRequest>): Promise<TimeOffRequest | undefined>;
  deleteTimeOffRequest(id: number): Promise<boolean>;

  // User Management
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUser(id: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPassword(userId: number, newPasswordHash: string): Promise<void>;
  
  // Club Management
  getClub(id: number): Promise<Club | undefined>;
  createClub(club: InsertClub): Promise<Club>;
}

export class DatabaseStorage implements IStorage {
  private sprayProductsCache: SprayProduct[] | null = null;
  private cacheTimestamp: number = 0;
  private readonly CACHE_DURATION = 0; // Cache disabled temporarily to show new products

  // Spray Products
  async getSprayProducts(clubId: number = 1): Promise<SprayProduct[]> {
    const now = Date.now();
    if (this.sprayProductsCache && (now - this.cacheTimestamp) < this.CACHE_DURATION) {
      return this.sprayProductsCache.filter(p => p.clubId === clubId);
    }
    
    const products = await db.select().from(sprayProducts).where(eq(sprayProducts.clubId, clubId));
    this.sprayProductsCache = products;
    this.cacheTimestamp = now;
    return products;
  }

  async getSprayProduct(id: number, clubId: number = 1): Promise<SprayProduct | undefined> {
    const [product] = await db.select().from(sprayProducts).where(
      and(eq(sprayProducts.id, id), eq(sprayProducts.clubId, clubId))
    );
    return product || undefined;
  }

  async createSprayProduct(product: InsertSprayProduct): Promise<SprayProduct> {
    const [newProduct] = await db
      .insert(sprayProducts)
      .values(product)
      .returning();
    this.sprayProductsCache = null; // Invalidate cache
    return newProduct;
  }

  async updateSprayProduct(id: number, product: Partial<InsertSprayProduct>): Promise<SprayProduct | undefined> {
    const [updated] = await db
      .update(sprayProducts)
      .set(product)
      .where(eq(sprayProducts.id, id))
      .returning();
    this.sprayProductsCache = null; // Invalidate cache
    return updated || undefined;
  }

  async deleteSprayProduct(id: number): Promise<boolean> {
    const result = await db
      .delete(sprayProducts)
      .where(eq(sprayProducts.id, id));
    this.sprayProductsCache = null; // Invalidate cache
    return (result.rowCount || 0) > 0;
  }

  // Granular Fertilizers
  async getGranularFertilizers(): Promise<GranularFertilizer[]> {
    return await db.select().from(granularFertilizers);
  }

  async getGranularFertilizer(id: number): Promise<GranularFertilizer | undefined> {
    const [fertilizer] = await db.select().from(granularFertilizers).where(eq(granularFertilizers.id, id));
    return fertilizer || undefined;
  }

  async createGranularFertilizer(fertilizer: InsertGranularFertilizer): Promise<GranularFertilizer> {
    const [newFertilizer] = await db
      .insert(granularFertilizers)
      .values(fertilizer)
      .returning();
    return newFertilizer;
  }

  async updateGranularFertilizer(id: number, fertilizer: Partial<InsertGranularFertilizer>): Promise<GranularFertilizer | undefined> {
    const [updated] = await db
      .update(granularFertilizers)
      .set(fertilizer)
      .where(eq(granularFertilizers.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteGranularFertilizer(id: number): Promise<boolean> {
    const result = await db
      .delete(granularFertilizers)
      .where(eq(granularFertilizers.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Turf Areas
  async getTurfAreas(): Promise<TurfArea[]> {
    return await db.select().from(turfAreas);
  }

  async getTurfArea(id: number): Promise<TurfArea | undefined> {
    const [area] = await db.select().from(turfAreas).where(eq(turfAreas.id, id));
    return area || undefined;
  }

  async createTurfArea(area: InsertTurfArea): Promise<TurfArea> {
    const [newArea] = await db
      .insert(turfAreas)
      .values(area)
      .returning();
    return newArea;
  }

  async updateTurfArea(id: number, area: Partial<InsertTurfArea>): Promise<TurfArea | undefined> {
    const [updated] = await db
      .update(turfAreas)
      .set({ ...area, lastUpdated: new Date() })
      .where(eq(turfAreas.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTurfArea(id: number): Promise<boolean> {
    const result = await db
      .delete(turfAreas)
      .where(eq(turfAreas.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Application Records
  async getApplicationRecords(): Promise<ApplicationRecord[]> {
    return await db.select().from(applicationRecords).orderBy(applicationRecords.date);
  }

  async getApplicationRecord(id: number): Promise<ApplicationRecord | undefined> {
    const [record] = await db.select().from(applicationRecords).where(eq(applicationRecords.id, id));
    return record || undefined;
  }

  async createApplicationRecord(record: InsertApplicationRecord): Promise<ApplicationRecord> {
    const [newRecord] = await db
      .insert(applicationRecords)
      .values(record)
      .returning();
    return newRecord;
  }

  async updateApplicationRecord(id: number, record: Partial<InsertApplicationRecord>): Promise<ApplicationRecord | undefined> {
    const [updated] = await db
      .update(applicationRecords)
      .set(record)
      .where(eq(applicationRecords.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteApplicationRecord(id: number): Promise<boolean> {
    const result = await db
      .delete(applicationRecords)
      .where(eq(applicationRecords.id, id));
    return (result.rowCount || 0) > 0;
  }

  // AI Analysis Results
  async getAiAnalysisResults(): Promise<AiAnalysisResult[]> {
    return await db.select().from(aiAnalysisResults).orderBy(aiAnalysisResults.createdAt);
  }

  async getAiAnalysisResult(id: number): Promise<AiAnalysisResult | undefined> {
    const [result] = await db.select().from(aiAnalysisResults).where(eq(aiAnalysisResults.id, id));
    return result || undefined;
  }

  async createAiAnalysisResult(result: InsertAiAnalysisResult): Promise<AiAnalysisResult> {
    const [newResult] = await db
      .insert(aiAnalysisResults)
      .values(result)
      .returning();
    return newResult;
  }

  // Seasonal Plans
  async getSeasonalPlans(): Promise<SeasonalPlan[]> {
    return await db.select().from(seasonalPlans);
  }

  async getSeasonalPlan(id: number): Promise<SeasonalPlan | undefined> {
    const [plan] = await db.select().from(seasonalPlans).where(eq(seasonalPlans.id, id));
    return plan || undefined;
  }

  async createSeasonalPlan(plan: InsertSeasonalPlan): Promise<SeasonalPlan> {
    const [newPlan] = await db
      .insert(seasonalPlans)
      .values(plan)
      .returning();
    return newPlan;
  }

  async updateSeasonalPlan(id: number, plan: Partial<InsertSeasonalPlan>): Promise<SeasonalPlan | undefined> {
    const [updatedPlan] = await db
      .update(seasonalPlans)
      .set(plan)
      .where(eq(seasonalPlans.id, id))
      .returning();
    return updatedPlan || undefined;
  }

  async deleteSeasonalPlan(id: number): Promise<boolean> {
    const result = await db.delete(seasonalPlans).where(eq(seasonalPlans.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Scheduled Applications
  async getScheduledApplications(): Promise<ScheduledApplication[]> {
    return await db.select().from(scheduledApplications);
  }

  async getScheduledApplicationsByPlan(planId: number): Promise<ScheduledApplication[]> {
    return await db.select().from(scheduledApplications).where(eq(scheduledApplications.seasonalPlanId, planId));
  }

  async getScheduledApplication(id: number): Promise<ScheduledApplication | undefined> {
    const [application] = await db.select().from(scheduledApplications).where(eq(scheduledApplications.id, id));
    return application || undefined;
  }

  async createScheduledApplication(application: InsertScheduledApplication): Promise<ScheduledApplication> {
    const [newApplication] = await db
      .insert(scheduledApplications)
      .values(application)
      .returning();
    return newApplication;
  }

  async updateScheduledApplication(id: number, application: Partial<InsertScheduledApplication>): Promise<ScheduledApplication | undefined> {
    const [updatedApplication] = await db
      .update(scheduledApplications)
      .set(application)
      .where(eq(scheduledApplications.id, id))
      .returning();
    return updatedApplication || undefined;
  }

  async deleteScheduledApplication(id: number): Promise<boolean> {
    const result = await db.delete(scheduledApplications).where(eq(scheduledApplications.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Industry News
  async getIndustryNews(): Promise<IndustryNews[]> {
    return await db.select().from(industryNews).orderBy(industryNews.publishedDate);
  }

  async getIndustryNewsByCategory(category: string): Promise<IndustryNews[]> {
    return await db.select().from(industryNews).where(eq(industryNews.category, category)).orderBy(industryNews.publishedDate);
  }

  async getIndustryNewsItem(id: number): Promise<IndustryNews | undefined> {
    const [news] = await db.select().from(industryNews).where(eq(industryNews.id, id));
    return news || undefined;
  }

  async createIndustryNews(news: InsertIndustryNews): Promise<IndustryNews> {
    const [newNews] = await db.insert(industryNews).values(news).returning();
    return newNews;
  }

  async updateIndustryNews(id: number, news: Partial<InsertIndustryNews>): Promise<IndustryNews | undefined> {
    const [updatedNews] = await db.update(industryNews)
      .set(news)
      .where(eq(industryNews.id, id))
      .returning();
    return updatedNews || undefined;
  }

  async updateIndustryNewsCategory(id: number, category: string): Promise<IndustryNews | undefined> {
    const [updatedNews] = await db.update(industryNews)
      .set({ category })
      .where(eq(industryNews.id, id))
      .returning();
    return updatedNews || undefined;
  }

  async updateIndustryNewsReadStatus(id: number, isRead: boolean): Promise<IndustryNews | undefined> {
    const [updatedNews] = await db.update(industryNews)
      .set({ isRead })
      .where(eq(industryNews.id, id))
      .returning();
    return updatedNews || undefined;
  }

  async updateIndustryNewsFavouriteStatus(id: number, isFavourited: boolean): Promise<IndustryNews | undefined> {
    const [updatedNews] = await db.update(industryNews)
      .set({ isFavourited })
      .where(eq(industryNews.id, id))
      .returning();
    return updatedNews || undefined;
  }

  async deleteIndustryNews(id: number): Promise<boolean> {
    const result = await db.delete(industryNews).where(eq(industryNews.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Staff Management Implementation
  async getStaffMembers(): Promise<StaffMember[]> {
    return await db.select().from(staffMembers);
  }

  async getStaffMember(id: number): Promise<StaffMember | undefined> {
    const [member] = await db.select().from(staffMembers).where(eq(staffMembers.id, id));
    return member || undefined;
  }

  async createStaffMember(member: InsertStaffMember): Promise<StaffMember> {
    const [newMember] = await db.insert(staffMembers).values(member).returning();
    return newMember;
  }

  async updateStaffMember(id: number, member: Partial<InsertStaffMember>): Promise<StaffMember | undefined> {
    const [updated] = await db.update(staffMembers).set(member).where(eq(staffMembers.id, id)).returning();
    return updated || undefined;
  }

  async deleteStaffMember(id: number): Promise<boolean> {
    const result = await db.delete(staffMembers).where(eq(staffMembers.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Staff Rota Implementation
  async getStaffRota(): Promise<any[]> {
    return await db.select().from(rotaShifts);
  }

  async getStaffRotaByDate(startDate: Date, endDate: Date): Promise<any[]> {
    return await db.select()
      .from(rotaShifts)
      .where(
        and(
          gte(rotaShifts.date, startDate),
          lte(rotaShifts.date, endDate)
        )
      );
  }

  async getStaffRotaByMember(staffId: number): Promise<any[]> {
    return await db.select().from(rotaShifts).where(eq(rotaShifts.staffId, staffId));
  }

  async createStaffRotaEntry(entry: any): Promise<any> {
    const [newEntry] = await db.insert(rotaShifts).values(entry).returning();
    return newEntry;
  }

  async updateStaffRotaEntry(id: number, entry: any): Promise<any> {
    const [updated] = await db.update(rotaShifts).set(entry).where(eq(rotaShifts.id, id)).returning();
    return updated || undefined;
  }

  async deleteStaffRotaEntry(id: number): Promise<boolean> {
    const result = await db.delete(rotaShifts).where(eq(rotaShifts.id, id));
    return (result.rowCount || 0) > 0;
  }

  async clearAllStaffRotaEntries(): Promise<boolean> {
    try {
      await db.delete(rotaShifts);
      return true;
    } catch (error) {
      console.error('Failed to clear all rota shifts:', error);
      return false;
    }
  }

  // Saved Rotas Implementation
  async getSavedRotas(): Promise<SavedRota[]> {
    return await db.select().from(savedRotas);
  }

  async getSavedRota(id: number): Promise<SavedRota | undefined> {
    const [rota] = await db.select().from(savedRotas).where(eq(savedRotas.id, id));
    return rota;
  }

  async createSavedRota(rota: InsertSavedRota): Promise<SavedRota> {
    const [created] = await db.insert(savedRotas).values(rota).returning();
    return created;
  }

  async updateSavedRota(id: number, rota: Partial<InsertSavedRota>): Promise<SavedRota | undefined> {
    const [updated] = await db.update(savedRotas)
      .set(rota)
      .where(eq(savedRotas.id, id))
      .returning();
    return updated;
  }

  async deleteSavedRota(id: number): Promise<boolean> {
    const result = await db.delete(savedRotas).where(eq(savedRotas.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Rota Shifts Implementation
  async getRotaShifts(rotaId: number): Promise<RotaShift[]> {
    return await db.select().from(rotaShifts).where(eq(rotaShifts.rotaId, rotaId));
  }

  async getRotaShiftsByDate(startDate: Date, endDate: Date): Promise<RotaShift[]> {
    return await db.select()
      .from(rotaShifts)
      .where(
        and(
          gte(rotaShifts.date, startDate),
          lte(rotaShifts.date, endDate)
        )
      );
  }

  async createRotaShift(shift: InsertRotaShift): Promise<RotaShift> {
    const [created] = await db.insert(rotaShifts).values(shift).returning();
    return created;
  }

  async updateRotaShift(id: number, shift: Partial<InsertRotaShift>): Promise<RotaShift | undefined> {
    const [updated] = await db.update(rotaShifts)
      .set(shift)
      .where(eq(rotaShifts.id, id))
      .returning();
    return updated;
  }

  async deleteRotaShift(id: number): Promise<boolean> {
    const result = await db.delete(rotaShifts).where(eq(rotaShifts.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Holiday Bookings Implementation
  async getHolidayBookings(staffId?: number): Promise<HolidayBooking[]> {
    if (staffId) {
      return await db.select().from(holidayBookings).where(eq(holidayBookings.staffId, staffId));
    }
    return await db.select().from(holidayBookings);
  }

  async getHolidayBooking(id: number): Promise<HolidayBooking | undefined> {
    const [booking] = await db.select().from(holidayBookings).where(eq(holidayBookings.id, id));
    return booking;
  }

  async createHolidayBooking(booking: InsertHolidayBooking): Promise<HolidayBooking> {
    const [created] = await db.insert(holidayBookings).values(booking).returning();
    return created;
  }

  async updateHolidayBooking(id: number, booking: Partial<InsertHolidayBooking>): Promise<HolidayBooking | undefined> {
    const [updated] = await db.update(holidayBookings)
      .set(booking)
      .where(eq(holidayBookings.id, id))
      .returning();
    return updated;
  }

  async deleteHolidayBooking(id: number): Promise<boolean> {
    const result = await db.delete(holidayBookings).where(eq(holidayBookings.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Time Off Requests
  async getTimeOffRequests(staffId: number): Promise<TimeOffRequest[]> {
    const requests = await db.select().from(timeOffRequests).where(eq(timeOffRequests.staffId, staffId));
    return requests;
  }

  async getTimeOffRequest(id: number): Promise<TimeOffRequest | undefined> {
    const [request] = await db.select().from(timeOffRequests).where(eq(timeOffRequests.id, id));
    return request || undefined;
  }

  async createTimeOffRequest(request: InsertTimeOffRequest): Promise<TimeOffRequest> {
    const [created] = await db
      .insert(timeOffRequests)
      .values(request)
      .returning();
    return created;
  }

  async updateTimeOffRequest(id: number, request: Partial<InsertTimeOffRequest>): Promise<TimeOffRequest | undefined> {
    const [updated] = await db
      .update(timeOffRequests)
      .set(request)
      .where(eq(timeOffRequests.id, id))
      .returning();
    return updated;
  }

  async deleteTimeOffRequest(id: number): Promise<boolean> {
    const result = await db.delete(timeOffRequests).where(eq(timeOffRequests.id, id));
    return (result.rowCount || 0) > 0;
  }

  // User Management
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUserPassword(userId: number, newPasswordHash: string): Promise<void> {
    await db.update(users)
      .set({ passwordHash: newPasswordHash })
      .where(eq(users.id, userId));
  }

  // Club Management
  async getClub(id: number): Promise<Club | undefined> {
    const [club] = await db.select().from(clubs).where(eq(clubs.id, id));
    return club || undefined;
  }

  async createClub(club: InsertClub): Promise<Club> {
    const [newClub] = await db.insert(clubs).values(club).returning();
    return newClub;
  }
}

export const storage = new DatabaseStorage();
