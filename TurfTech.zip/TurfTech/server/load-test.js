// Load Testing Script for Golf Course Management Platform
// Tests simultaneous multi-user sessions during peak usage (tournament prep)

import http from 'http';
import https from 'https';

class LoadTester {
  constructor(baseUrl = 'http://localhost:5000') {
    this.baseUrl = baseUrl;
    this.results = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      averageResponseTime: 0,
      errors: []
    };
  }

  async makeRequest(endpoint, method = 'GET', data = null) {
    return new Promise((resolve) => {
      const startTime = Date.now();
      const url = new URL(endpoint, this.baseUrl);
      const options = {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname + url.search,
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'LoadTester/1.0'
        }
      };

      if (data) {
        const postData = JSON.stringify(data);
        options.headers['Content-Length'] = Buffer.byteLength(postData);
      }

      const client = url.protocol === 'https:' ? https : http;
      const req = client.request(options, (res) => {
        let responseData = '';
        res.on('data', (chunk) => responseData += chunk);
        res.on('end', () => {
          const endTime = Date.now();
          const responseTime = endTime - startTime;
          
          this.results.totalRequests++;
          if (res.statusCode >= 200 && res.statusCode < 300) {
            this.results.successfulRequests++;
          } else {
            this.results.failedRequests++;
            this.results.errors.push(`${endpoint}: ${res.statusCode}`);
          }
          
          resolve({
            statusCode: res.statusCode,
            responseTime: responseTime,
            data: responseData
          });
        });
      });

      req.on('error', (error) => {
        this.results.totalRequests++;
        this.results.failedRequests++;
        this.results.errors.push(`${endpoint}: ${error.message}`);
        resolve({
          statusCode: 0,
          responseTime: Date.now() - startTime,
          error: error.message
        });
      });

      if (data) {
        req.write(JSON.stringify(data));
      }
      req.end();
    });
  }

  // Simulate tournament preparation day usage patterns
  async simulateTournamentPrepDay(concurrentUsers = 10, duration = 60000) {
    console.log(`🏌️ Starting tournament prep load test:`);
    console.log(`- Concurrent users: ${concurrentUsers}`);
    console.log(`- Duration: ${duration/1000} seconds`);
    console.log(`- Simulating: Tank mix calculations, weather checks, staff scheduling`);
    
    const userSessions = [];
    const endTime = Date.now() + duration;

    // Create concurrent user sessions
    for (let i = 0; i < concurrentUsers; i++) {
      userSessions.push(this.simulateUserSession(i, endTime));
    }

    await Promise.all(userSessions);
    return this.generateReport();
  }

  async simulateUserSession(userId, endTime) {
    const sessionActions = [
      () => this.makeRequest('/api/spray-products'),
      () => this.makeRequest('/api/weather'),
      () => this.makeRequest('/api/weather/annual-stats'),
      () => this.makeRequest('/api/turf-areas'),
      () => this.makeRequest('/api/industry-news'),
      () => this.makeRequest('/api/suggest-products', 'POST', {
        area: 'fairways',
        issue: 'growth regulation',
        weatherConditions: { temperature: 16, humidity: 88 }
      }),
      () => this.makeRequest('/api/calculate-tank-mix', 'POST', {
        products: [
          { id: 1, ratePerHa: 1.5, unit: 'L' }
        ],
        areaId: 1,
        tankSize: 1000
      })
    ];

    while (Date.now() < endTime) {
      // Random action selection (realistic user behavior)
      const action = sessionActions[Math.floor(Math.random() * sessionActions.length)];
      await action();
      
      // Random delay between actions (1-5 seconds)
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 4000));
    }
  }

  generateReport() {
    const successRate = (this.results.successfulRequests / this.results.totalRequests * 100).toFixed(2);
    
    return {
      summary: {
        totalRequests: this.results.totalRequests,
        successfulRequests: this.results.successfulRequests,
        failedRequests: this.results.failedRequests,
        successRate: `${successRate}%`,
        requestsPerSecond: (this.results.totalRequests / 60).toFixed(2)
      },
      errors: this.results.errors.slice(0, 10), // Show first 10 errors
      status: successRate >= 95 ? 'PASS' : 'NEEDS_ATTENTION'
    };
  }
}

// Export for use in automated testing
export { LoadTester };

// Run load test if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const tester = new LoadTester();
  
  tester.simulateTournamentPrepDay(15, 30000) // 15 users for 30 seconds
    .then(report => {
      console.log('\n📊 Load Test Results:');
      console.log('====================');
      console.log(`Total Requests: ${report.summary.totalRequests}`);
      console.log(`Success Rate: ${report.summary.successRate}`);
      console.log(`Requests/Second: ${report.summary.requestsPerSecond}`);
      console.log(`Status: ${report.status}`);
      
      if (report.errors.length > 0) {
        console.log('\n⚠️ Errors encountered:');
        report.errors.forEach(error => console.log(`  - ${error}`));
      }
      
      process.exit(report.status === 'PASS' ? 0 : 1);
    })
    .catch(error => {
      console.error('Load test failed:', error);
      process.exit(1);
    });
}