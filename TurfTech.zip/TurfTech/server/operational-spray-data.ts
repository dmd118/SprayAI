// Real-world operational spray parameters for John Deere 4610 tractor
// Based on actual field conditions and nozzle specifications

export interface OperationalSprayParams {
  targetArea: string;
  tractorSpeedKmh: number;
  recommendedNozzleType: string;
  nozzleFlowRateLMin: number;
  sprayWidthMeters: number;
  maxApplicationRateLHa: number;
}

// John Deere 4610 operational spray parameters - Fixed 7 km/h speed for all applications
export const OPERATIONAL_SPRAY_DATA: OperationalSprayParams[] = [
  {
    targetArea: "greens",
    tractorSpeedKmh: 7.0, // Standard speed - precision controlled by nozzle selection
    recommendedNozzleType: "red",
    nozzleFlowRateLMin: 1.2, // Low flow for precision
    sprayWidthMeters: 2.5,
    maxApplicationRateLHa: 400
  },
  {
    targetArea: "tees", 
    tractorSpeedKmh: 7.0, // Standard speed
    recommendedNozzleType: "yellow",
    nozzleFlowRateLMin: 1.8,
    sprayWidthMeters: 3.0,
    maxApplicationRateLHa: 350
  },
  {
    targetArea: "fairways",
    tractorSpeedKmh: 7.0, // Standard speed
    recommendedNozzleType: "white",
    nozzleFlowRateLMin: 2.5, // Higher flow for coverage
    sprayWidthMeters: 4.0,
    maxApplicationRateLHa: 300
  },
  {
    targetArea: "rough",
    tractorSpeedKmh: 7.0, // Standard speed
    recommendedNozzleType: "white", 
    nozzleFlowRateLMin: 2.8,
    sprayWidthMeters: 4.5,
    maxApplicationRateLHa: 250
  }
];

export interface TankMixCalculationResult {
  tankSize: number;
  waterVolume: number;
  totalArea: number;
  applicationRate: number;
  tanksNeeded: number;
  totalWaterNeeded: number;
  products: Array<{
    name: string;
    type: string;
    ratePerHa: number;
    totalAmount: number;
    perTankAmount: number;
    unit: string;
  }>;
  totalJobSummary: Array<{
    productName: string;
    totalAmount: number;
    perTankAmount: number;
    unit: string;
  }>;
  operationalConstraints: {
    recommendedNozzleType: string;
    tractorSpeedKmh: number;
    sprayWidthMeters: number;
    maxNozzleCapacityLHa: number;
    applicationRateFeasible: boolean;
    nozzleCapacityWarning?: string;
    effectiveApplicationRate: number;
    sprayTimePerTankMinutes: number;
    totalSprayTimeMinutes: number;
  };
  costAnalysis?: {
    totalCostGBP: number;
    costPerHectare: number;
    costOptimizationFlag: boolean;
    alternatives?: string[];
  };
}

export function calculateOperationalSprayParams(
  targetAreaType: string,
  totalAreaHa: number,
  requestedApplicationRate: number,
  tractorSpeedKmh: number = 7,
  nozzleType: string = "white"
): TankMixCalculationResult['operationalConstraints'] {
  
  // Use user-selected parameters instead of fixed data
  const nozzleFlowRates: { [key: string]: number } = {
    "red": 0.8,    // L/min for red nozzles (fine)
    "yellow": 1.0, // L/min for yellow nozzles (medium)
    "white": 1.2   // L/min for white nozzles (standard)
  };
  
  const sprayWidth = 4; // meters (4m boom width)
  const selectedNozzleFlow = nozzleFlowRates[nozzleType as keyof typeof nozzleFlowRates] || 1.2;
  
  // Calculate actual nozzle capacity based on user-selected flow rate, speed, and width
  // Formula: (Flow L/min × 60 min/hr × Width m) ÷ (Speed km/h × 1000 m/km ÷ 10000 m²/ha)
  const nozzleCapacityLHa = (selectedNozzleFlow * 60 * sprayWidth * 10000) / 
    (tractorSpeedKmh * 1000); // Proper L/ha conversion
  
  const applicationRateFeasible = requestedApplicationRate <= nozzleCapacityLHa;
  const effectiveApplicationRate = Math.min(requestedApplicationRate, nozzleCapacityLHa);
  
  // Calculate spray time correctly
  // Formula: Area coverage per hour = speed (km/h) × width (m) × 0.1 (to convert to hectares)
  const hectaresPerHour = (tractorSpeedKmh * sprayWidth) * 0.1;
  const timePerHectareMinutes = 60 / hectaresPerHour;
  const totalSprayTimeMinutes = totalAreaHa * timePerHectareMinutes;
  
  // Calculate area covered per tank (based on 300L working load)
  const areaCoveredPerTank = 300 / requestedApplicationRate;
  const timePerTankMinutes = areaCoveredPerTank * timePerHectareMinutes;
  
  let nozzleCapacityWarning;
  if (!applicationRateFeasible) {
    nozzleCapacityWarning = `Warning: Requested ${requestedApplicationRate}L/ha exceeds ${nozzleType} nozzle capacity of ${Math.round(nozzleCapacityLHa)}L/ha at ${tractorSpeedKmh}km/h. Consider slower speed or different nozzle type.`;
  }
  
  return {
    recommendedNozzleType: nozzleType,
    tractorSpeedKmh: tractorSpeedKmh,
    sprayWidthMeters: sprayWidth,
    maxNozzleCapacityLHa: Math.round(nozzleCapacityLHa),
    applicationRateFeasible,
    nozzleCapacityWarning,
    effectiveApplicationRate: Math.round(effectiveApplicationRate),
    sprayTimePerTankMinutes: Math.round(timePerTankMinutes),
    totalSprayTimeMinutes: Math.round(totalSprayTimeMinutes)
  };
}

// Backend Formula Pack Implementation
export function calculateAreaCoveredPerTank(tankSizeL: number, waterRateLHa: number): number {
  // Operational approach: Use practical working loads based on tank size
  // Default 300L working load but adjustable for different sprayer configurations
  const targetWorkingLoadL = 300; // Configurable working load
  const practicalTankLoad = Math.min(tankSizeL, targetWorkingLoadL);
  return practicalTankLoad / waterRateLHa;
}

export function calculateTotalWaterNeeded(areaHa: number, waterRateLHa: number): number {
  return areaHa * waterRateLHa;
}

export function calculateTotalProductNeeded(areaHa: number, productRatePerHa: number): number {
  return areaHa * productRatePerHa;
}

export function calculateTanksNeeded(totalWaterL: number, tankSizeL: number): number {
  // Operational approach: Use configurable working loads for flexibility
  const targetWorkingLoadL = 300; // Configurable working load
  const practicalTankLoad = Math.min(tankSizeL, targetWorkingLoadL);
  
  // Calculate exact tanks needed based on practical load size
  const exactTanks = totalWaterL / practicalTankLoad;
  
  console.log(`DEBUG: Tank calculation - Total water: ${totalWaterL}L, Practical load: ${practicalTankLoad}L, Exact tanks: ${exactTanks}`);
  
  // Return precise number (e.g., 2.5 tanks) for practical planning
  const result = Math.max(1, Math.round(exactTanks * 10) / 10);
  console.log(`DEBUG: Final tanks needed: ${result}`);
  
  return result;
}

export function calculateProductPerTank(totalProduct: number, tanksNeeded: number): number {
  return totalProduct / tanksNeeded;
}

export function getWaterRateForTargetArea(targetArea: string): number {
  const areaType = targetArea.toLowerCase();
  
  // Backend locked water rates based on target area
  if (areaType.includes('green')) {
    return 500; // L/ha - Higher precision for greens
  } else if (areaType.includes('tee')) {
    return 400; // L/ha - Medium rate for tees  
  } else if (areaType.includes('fairway')) {
    return 300; // L/ha - Standard fairway rate
  } else if (areaType.includes('rough')) {
    return 250; // L/ha - Lower rate for rough areas
  }
  
  return 300; // Default to fairway rate
}

export function calculateOptimalTankCount(
  totalAreaHa: number,
  tankSizeL: number,
  applicationRateL: number,
  targetAreaType: string
): number {
  // Use the precise backend formulas
  const totalWaterNeeded = calculateTotalWaterNeeded(totalAreaHa, applicationRateL);
  const tanksNeeded = calculateTanksNeeded(totalWaterNeeded, tankSizeL);
  
  return tanksNeeded;
}