import Parser from 'rss-parser';
import { storage } from './storage';
import type { InsertIndustryNews } from '@shared/schema';

const rssParser = new Parser({
  customFields: {
    item: ['pubDate', 'description', 'content:encoded', 'category']
  }
});

// Enhanced RSS feeds for greenkeeping content
const RSS_FEEDS_HARVEST = [
  {
    url: 'https://www.golfdom.com/feed',
    source: 'Golfdom Magazine',
    priority: 'high' as const
  },
  {
    url: 'https://www.golfcourseindustry.com/rss',
    source: 'Golf Course Industry',
    priority: 'high' as const
  },
  {
    url: 'https://www.turfnet.com/rss.xml',
    source: 'TurfNet',
    priority: 'high' as const
  },
  {
    url: 'https://www.groundskeeping.com/feed',
    source: 'Grounds Maintenance',
    priority: 'high' as const
  },
  {
    url: 'https://www.sportsbusinessjournal.com/rss/golf.xml',
    source: 'Sports Business Journal Golf',
    priority: 'normal' as const
  },
  {
    url: 'https://feeds.feedburner.com/TurfMagazine',
    source: 'Turf Magazine',
    priority: 'high' as const
  }
];

// Professional RSS feeds for direct industry content
const PROFESSIONAL_RSS_FEEDS = [
  {
    url: 'https://www.golfdom.com/feed',
    source: 'Golfdom Professional',
    priority: 'high' as const
  },
  {
    url: 'https://www.golfcourseindustry.com/rss',
    source: 'Golf Course Industry Professional',
    priority: 'high' as const
  },
  
  // Verified working trade publications with product focus
  {
    url: 'https://www.lawnandlandscape.com/rss',
    source: 'Lawn & Landscape Magazine',
    priority: 'high' as const
  },
  {
    url: 'https://www.golfbusinessnews.com/feed/',
    source: 'Golf Business News',
    priority: 'high' as const
  },
  {
    url: 'https://www.sportsbusinessjournal.com/golf/rss',
    source: 'Sports Business Golf',
    priority: 'normal' as const
  },
  {
    url: 'https://www.gcmonline.com/rss',
    source: 'Golf Course Management',
    priority: 'high' as const
  }
];

// YouTube Data API for greenkeeping content (educational & entertaining)
async function fetchFunnyGreenkeepingVideos(): Promise<any[]> {
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;
  if (!youtubeApiKey) {
    console.log('No YouTube API key provided, skipping videos fetch');
    return [];
  }

  const greenkeeperSearchTerms = [
    // Professional channels and content
    'STRI Group turf research',
    'Rigby Taylor greenkeeping',
    'ICL Turf Landscape fertilizer',
    'Bernhard Company turf equipment',
    'John Deere Golf maintenance',
    'BIGGA greenkeeping training',
    'GCSAA turf management',
    'Jacobsen turf equipment',
    // Technical content
    'golf course maintenance techniques',
    'turf management best practices',
    'greenkeeper training videos',
    'golf course irrigation systems',
    'professional mowing patterns',
    'bunker maintenance tutorial',
    'disease management turf',
    'fertilizer application methods',
    'aeration techniques golf',
    'spray calibration golf course'
  ];

  const videos = [];

  for (const searchTerm of greenkeeperSearchTerms) {
    try {
      const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(searchTerm)}&type=video&maxResults=3&order=relevance&key=${youtubeApiKey}`;
      
      const response = await fetch(searchUrl);
      if (!response.ok) continue;
      
      const data = await response.json();
      
      if (data.items && data.items.length > 0) {
        const relevantVideos = data.items.filter((video: any) => {
          const title = video.snippet.title.toLowerCase();
          const description = video.snippet.description.toLowerCase();
          
          // Strict greenkeeping relevance check
          const isGreenkeeping = title.includes('golf') || title.includes('green') || title.includes('turf') ||
                                title.includes('course') || title.includes('superintendent') || title.includes('maintenance') ||
                                title.includes('irrigation') || title.includes('bunker') || title.includes('fertilizer') ||
                                title.includes('aeration') || title.includes('mowing') || title.includes('disease') ||
                                description.includes('greenkeeper') || description.includes('turf management') ||
                                description.includes('golf course') || description.includes('superintendent');
          
          // Exclude non-relevant content
          const isExcluded = title.includes('stock') || title.includes('finance') || title.includes('investment') ||
                           title.includes('crypto') || title.includes('trading') || description.includes('stock market');
          
          return isGreenkeeping && !isExcluded;
        });

        videos.push(...relevantVideos.slice(0, 2));
      }
      
      await new Promise(resolve => setTimeout(resolve, 300));
      
    } catch (error) {
      console.log(`Error searching for funny videos "${searchTerm}":`, error);
    }
  }

  return videos;
}

// Fetch high-quality Reddit content from greenkeeping communities
async function fetchRedditGreenkeepingContent(): Promise<any[]> {
  const clientId = process.env.REDDIT_CLIENT_ID;
  const clientSecret = process.env.REDDIT_CLIENT_SECRET;
  
  if (!clientId || !clientSecret) {
    console.log('No Reddit API credentials found');
    return [];
  }

  try {
    // Get Reddit access token
    const authResponse = await fetch('https://www.reddit.com/api/v1/access_token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'DullatuerGolfClub/1.0.0'
      },
      body: 'grant_type=client_credentials'
    });

    if (!authResponse.ok) {
      console.error('Failed to get Reddit access token');
      return [];
    }

    const authData = await authResponse.json();
    const accessToken = authData.access_token;

    // Expanded subreddits including more active communities
    const subreddits = ['groundskeeping', 'lawncare', 'golfcourse', 'landscaping', 'marijuanaenthusiasts', 'golf'];
    const timePeriods = ['week', 'month']; // Focus on week/month for more content
    
    const allPosts = [];

    // Search multiple subreddit and time period combinations for better coverage
    for (let i = 0; i < 4; i++) {
      const randomSubreddit = subreddits[Math.floor(Math.random() * subreddits.length)];
      const randomTimePeriod = timePeriods[Math.floor(Math.random() * timePeriods.length)];
      
      try {
        const url = `https://oauth.reddit.com/r/${randomSubreddit}/top?t=${randomTimePeriod}&limit=15`;
        
        const response = await fetch(url, {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'User-Agent': 'DullatuerGolfClub/1.0.0'
          }
        });

        if (response.ok) {
          const data = await response.json();
          if (data.data && data.data.children) {
            // More lenient filtering to capture relevant content
            const posts = data.data.children
              .map((item: any) => item.data)
              .filter((post: any) => {
                const title = post.title?.toLowerCase() || '';
                const isRelevant = title.includes('turf') || title.includes('grass') || 
                                  title.includes('lawn') || title.includes('golf') ||
                                  title.includes('green') || title.includes('maintenance') ||
                                  title.includes('fertilizer') || title.includes('mow') ||
                                  title.includes('irrigation') || title.includes('weed');
                
                return (
                  post.score >= 2 && // Lower threshold
                  !post.is_video &&
                  !post.over_18 &&
                  !post.stickied &&
                  post.title &&
                  (isRelevant || post.subreddit === 'groundskeeping') // Always include groundskeeping posts
                );
              });

            allPosts.push(...posts);
            console.log(`Found ${posts.length} relevant posts from r/${randomSubreddit} (${randomTimePeriod})`);
          }
        }
        
        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 200));
        
      } catch (error) {
        console.error(`Error fetching from r/${randomSubreddit}:`, error);
      }
    }

    // Sort by quality score (upvotes + comments) and return top posts
    // Limited to 24 articles per day, prioritize highest quality
    return allPosts
      .sort((a, b) => (b.score + b.num_comments) - (a.score + a.num_comments))
      .slice(0, 24);

  } catch (error) {
    console.error('Error fetching Reddit content:', error);
    return [];
  }
}

// Quota-efficient YouTube Data API for educational greenkeeping content
async function fetchEducationalVideosFromYouTube(): Promise<any[]> {
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;
  if (!youtubeApiKey) {
    console.log('No YouTube API key provided, skipping YouTube fetch');
    return [];
  }

  const educationalContent: any[] = [];
  
  // Optimized search queries - reduced from 6 to 2 high-value searches
  // This saves 4 API calls per refresh (400 quota units daily)
  const searches = [
    'golf course superintendent training', // Combines maintenance + training
    'professional greenkeeper techniques'   // Covers equipment + methods
  ];

  for (const query of searches) {
    try {
      // Increased maxResults to 8 to get better selection from fewer searches
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&videoDuration=medium&order=relevance&maxResults=8&key=${youtubeApiKey}`
      );
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: { message: 'Unknown error' } }));
        if (errorData.error?.reason === 'quotaExceeded') {
          console.log('YouTube quota exceeded, stopping further searches');
          break; // Stop trying other searches if quota exceeded
        }
        continue;
      }

      const data = await response.json();
      
      // Enhanced filtering for higher quality content
      const filteredVideos = data.items?.filter((video: any) => {
        const title = video.snippet?.title?.toLowerCase() || '';
        const channelTitle = video.snippet?.channelTitle?.toLowerCase() || '';
        const description = video.snippet?.description?.toLowerCase() || '';
        
        // More comprehensive professional content detection
        const isProfessional = 
          channelTitle.includes('golf course') || 
          channelTitle.includes('turf') ||
          channelTitle.includes('greenkeeper') ||
          channelTitle.includes('superintendent') ||
          channelTitle.includes('bigga') ||
          channelTitle.includes('gcsaa') ||
          title.includes('how to') ||
          title.includes('training') ||
          title.includes('demonstration') ||
          title.includes('maintenance') ||
          title.includes('equipment') ||
          description.includes('professional') ||
          description.includes('course management');
        
        // Exclude amateur/non-professional content
        const isRelevant = !title.includes('diy') && 
                          !title.includes('homeowner') &&
                          !title.includes('backyard');
        
        return isProfessional && isRelevant;
      }) || [];
      
      educationalContent.push(...filteredVideos);
      console.log(`YouTube: Found ${filteredVideos.length} professional videos for "${query}"`);
      
      // Add delay between requests to be respectful to API
      await new Promise(resolve => setTimeout(resolve, 500));
      
    } catch (error) {
      console.error(`YouTube search failed for "${query}":`, error);
    }
  }
  
  // Return only the best 5 videos to meet your daily target
  return educationalContent
    .sort((a, b) => {
      // Sort by channel credibility and video freshness
      const scoreA = (a.snippet.channelTitle.toLowerCase().includes('golf') ? 2 : 0) +
                    (a.snippet.title.toLowerCase().includes('training') ? 1 : 0);
      const scoreB = (b.snippet.channelTitle.toLowerCase().includes('golf') ? 2 : 0) +
                    (b.snippet.title.toLowerCase().includes('training') ? 1 : 0);
      return scoreB - scoreA;
    })
    .slice(0, 5); // Limit to your target of 3-5 videos
}

// Empty array for regular RSS feeds (disabled)
const RSS_FEEDS: any[] = [];

// Google Custom Search API for professional greenkeeping content
async function fetchGoogleCustomSearchContent(): Promise<any[]> {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;
  const searchEngineId = process.env.GOOGLE_SEARCH_ENGINE_ID;
  
  if (!apiKey || !searchEngineId) {
    console.log('Google Custom Search credentials not provided');
    return [];
  }

  const articles: any[] = [];
  
  // Professional greenkeeping search queries
  const searchQueries = [
    'greenkeeping maintenance techniques',
    'turf disease management golf course',
    'professional fertilizer application',
    'irrigation system golf course',
    'equipment maintenance greenkeeper',
    'pest control turf management'
  ];

  try {
    for (const query of searchQueries) {
      const response = await fetch(
        `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${searchEngineId}&q=${encodeURIComponent(query)}&num=3&sort=date`
      );

      if (!response.ok) {
        console.log(`Google Search API error for "${query}": ${response.status}`);
        continue;
      }

      const data = await response.json();
      
      if (data.items && data.items.length > 0) {
        for (const item of data.items) {
          articles.push({
            title: item.title,
            summary: item.snippet,
            url: item.link,
            source: item.displayLink,
            publishedDate: item.pagemap?.metatags?.[0]?.['article:published_time'] || 
                          item.pagemap?.metatags?.[0]?.['publish-date'] || 
                          new Date().toISOString()
          });
        }
        console.log(`Found ${data.items.length} articles for "${query}"`);
      }
      
      // Rate limiting
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    return articles;
    
  } catch (error) {
    console.error('Google Custom Search API error:', error);
    return [];
  }
}

// News API integration for additional sources
async function fetchNewsFromAPI(apiKey?: string): Promise<any[]> {
  if (!apiKey) {
    console.log('News API key not provided, skipping API news fetch');
    return [];
  }

  try {
    // Multiple targeted queries to get comprehensive coverage
    const queries = [
      'golf course maintenance AND (fungicide OR fertilizer OR pesticide)',
      'greenkeeper AND (turf management OR golf)',
      'golf superintendent AND (disease control OR irrigation)',
      'turf industry AND (equipment OR technology)',
      'golf course AND (aeration OR overseeding OR renovation)'
    ];
    
    let allArticles = [];
    
    for (const query of queries) {
      try {
        const response = await fetch(
          `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&language=en&sortBy=publishedAt&pageSize=20&apiKey=${apiKey}`
        );
        
        if (response.ok) {
          const data = await response.json();
          allArticles.push(...(data.articles || []));
        }
      } catch (error) {
        console.error(`Query failed: ${query}`, error);
      }
    }
    
    // Remove duplicates based on URL
    const uniqueArticles = allArticles.filter((article, index, self) =>
      index === self.findIndex(a => a.url === article.url)
    );
    
    return uniqueArticles;
  } catch (error) {
    console.error('News API fetch error:', error);
    return [];
  }
}

// Advanced duplicate detection system
function isDuplicate(newItem: any, existingItems: any[]): boolean {
  const newTitle = newItem.title.toLowerCase().trim();
  const newUrl = newItem.url || newItem.link || newItem.sourceUrl || '';
  
  return existingItems.some(existing => {
    const existingTitle = existing.title.toLowerCase().trim();
    const existingUrl = existing.url || existing.link || existing.sourceUrl || '';
    
    // Check for exact URL match
    if (newUrl && existingUrl && newUrl === existingUrl) {
      return true;
    }
    
    // Check for similar titles (85% similarity)
    const similarity = calculateStringSimilarity(newTitle, existingTitle);
    if (similarity > 0.85) {
      return true;
    }
    
    // Check for shortened/truncated titles
    if (newTitle.includes(existingTitle) || existingTitle.includes(newTitle)) {
      return true;
    }
    
    // Check for content similarity (first 100 characters)
    const newContent = (newItem.summary || newItem.content || '').toLowerCase().substring(0, 100);
    const existingContent = (existing.summary || existing.content || '').toLowerCase().substring(0, 100);
    if (newContent && existingContent && calculateStringSimilarity(newContent, existingContent) > 0.8) {
      return true;
    }
    
    return false;
  });
}

function calculateStringSimilarity(str1: string, str2: string): number {
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) return 1.0;
  
  const editDistance = levenshteinDistance(longer, shorter);
  return (longer.length - editDistance) / longer.length;
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix = [];
  
  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }
  
  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  
  return matrix[str2.length][str1.length];
}

export function categorizeContent(title: string, description: string): string {
  const text = `${title} ${description}`.toLowerCase();
  
  // Enhanced greenkeeping content detection
  const greenkeeperTerms = [
    'golf course', 'greenkeeper', 'turf', 'greens', 'fairway', 'tee', 'golf maintenance', 
    'sports turf', 'groundskeeper', 'course management', 'bunker', 'irrigation', 'mowing',
    'fertilizer', 'fungicide', 'herbicide', 'pesticide', 'spray', 'application rate',
    'disease management', 'aeration', 'overseeding', 'topdressing', 'drainage'
  ];
  const hasGreenkeeperContent = greenkeeperTerms.some(term => text.includes(term));
  
  // Strict exclusion filters for non-greenkeeping content
  const excludeTerms = [
    'crop', 'agriculture', 'farming', 'corn', 'wheat', 'soybean', 'livestock', 'cattle',
    'stock', 'shares', 'nasdaq', 'nyse', 'holdings', 'portfolio', 'investment', 'earnings',
    'brightview', 'stock position', 'advisers', 'capital llc', 'shares purchased', 'stock holdings',
    'trump', 'mar-a-lago', 'politics', 'celebrity', 'real estate', 'parkinson', 'disease risk',
    'health study', 'living near', 'subscription economy', 'crypto', 'bitcoin',
    'fitness', 'silversneakers', 'instructor of the year', 'senior fitness', 'hawaii',
    'airbus', 'aerospace', 'aviation', 'air traffic control', 'faa', 'remote towers',
    'meta', 'facebook', 'nick clegg', 'artificial intelligence', 'tech exec',
    'deere & company', 'steel dynamics', 'norfolk southern', 'apollo global', 'ingersoll rand',
    'marketbeat', 'stock screener', 'equity securities', 'lawn mower recall', 'consumer report'
  ];
  const hasExcludedContent = excludeTerms.some(term => text.includes(term));
  
  // Filter out non-greenkeeping content
  if (hasExcludedContent && !hasGreenkeeperContent) {
    return 'excluded';
  }
  
  // Only proceed with greenkeeping-related content
  if (!hasGreenkeeperContent) {
    return 'excluded';
  }
  
  // Categorize greenkeeping content to match frontend tabs
  // Enhanced product detection for equipment, chemicals, and tools
  const productTerms = [
    'product', 'launch', 'release', 'announces', 'introduces', 'unveils', 'debuts',
    'new mower', 'new equipment', 'new fungicide', 'new herbicide', 'new fertilizer',
    'sprayer', 'aerator', 'topdresser', 'fairway mower', 'greens mower', 'rough mower',
    'tractor', 'utility vehicle', 'spreader', 'seeder', 'edger', 'trimmer',
    'irrigation system', 'pump', 'nozzle', 'controller', 'sensor',
    'hand tools', 'pruning', 'cutting', 'digging', 'raking'
  ];
  
  if (productTerms.some(term => text.includes(term))) {
    return 'products';
  }
  if (text.includes('research') || text.includes('study') || text.includes('university') || text.includes('trial') || text.includes('field test')) {
    return 'research';
  }
  if (text.includes('regulation') || text.includes('law') || text.includes('compliance') || text.includes('ban') || text.includes('approval') || text.includes('permit')) {
    return 'regulations';
  }
  if (text.includes('event') || text.includes('conference') || text.includes('exhibition') || text.includes('show') || text.includes('btme') || text.includes('seminar')) {
    return 'events';
  }
  if (text.includes('technique') || text.includes('method') || text.includes('practice') || text.includes('management') || text.includes('application') || text.includes('maintenance')) {
    return 'techniques';
  }
  
  return 'articles';
}

function extractRelevantProducts(title: string, description: string): string[] {
  const text = `${title} ${description}`.toLowerCase();
  const products: string[] = [];
  
  // Common product patterns
  if (text.includes('fungicide') || text.includes('heritage') || text.includes('azoxystrobin')) products.push('Fungicides');
  if (text.includes('herbicide') || text.includes('glyphosate') || text.includes('selective')) products.push('Herbicides');
  if (text.includes('fertilizer') || text.includes('nutrition') || text.includes('npk')) products.push('Fertilizers');
  if (text.includes('wetting agent') || text.includes('surfactant')) products.push('Wetting Agents');
  if (text.includes('insecticide') || text.includes('pest control')) products.push('Insecticides');
  if (text.includes('growth regulator') || text.includes('primo') || text.includes('trinexapac')) products.push('Growth Regulators');
  
  return products;
}

// Failsafe mechanism to ensure fresh content availability
// Fetch educational YouTube content for daily 5am schedule
export async function fetchEducationalYouTubeContent(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const errors: string[] = [];
  let count = 0;
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;

  if (!youtubeApiKey) {
    return { success: false, count: 0, errors: ['YouTube API key not available'] };
  }

  try {
    console.log('Fetching educational YouTube content for 5am schedule...');
    
    // Professional educational search terms
    const educationalSearches = [
      'STRI Group turf research',
      'BIGGA greenkeeping training', 
      'ICL Turf fertilizer application',
      'golf course superintendent techniques',
      'turf disease management professional',
      'irrigation system maintenance golf'
    ];

    const existingNews = await storage.getIndustryNews();
    
    for (const searchTerm of educationalSearches.slice(0, 2)) { // Limit to 2 searches for max 5 videos
      try {
        const response = await fetch(
          `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(searchTerm)}&type=video&maxResults=2&order=relevance&publishedAfter=${new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()}&key=${youtubeApiKey}`
        );

        if (!response.ok) continue;

        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
          for (const video of data.items) {
            try {
              const videoData = {
                title: video.snippet.title,
                url: `https://www.youtube.com/watch?v=${video.id.videoId}`,
                summary: video.snippet.description
              };

              // Check for duplicates
              if (isDuplicate(videoData, existingNews)) {
                continue;
              }

              const newsItem: InsertIndustryNews = {
                title: `[VIDEO] ${video.snippet.title}`,
                summary: video.snippet.description.substring(0, 200) + (video.snippet.description.length > 200 ? '...' : ''),
                content: `Professional educational video: ${video.snippet.description}`,
                category: "videos",
                source: `YouTube - ${video.snippet.channelTitle}`,
                sourceUrl: `https://www.youtube.com/watch?v=${video.id.videoId}`,
                imageUrl: video.snippet.thumbnails?.medium?.url || video.snippet.thumbnails?.default?.url,
                publishedDate: new Date(video.snippet.publishedAt),
                relevantProducts: [],
                tags: ["video", "youtube", "education", "professional"],
                priority: "normal"
              };

              await storage.createIndustryNews(newsItem);
              count++;
              console.log(`Added educational video: ${video.snippet.title}`);

            } catch (error) {
              errors.push(`Failed to add educational video: ${error}`);
            }
          }
        }
      } catch (error) {
        errors.push(`Educational YouTube search failed for "${searchTerm}": ${error}`);
      }
    }

    return { success: count > 0, count, errors };
    
  } catch (error) {
    errors.push(`Educational YouTube fetch failed: ${error}`);
    return { success: false, count: 0, errors };
  }
}

// Enhanced fallback system with rotating greenkeeping content
export async function addDiverseGreentkeepingContent(): Promise<{ success: boolean; count: number }> {
  console.log('Adding diverse greenkeeping content from multiple sources...');
  
  // Professional greenkeeping content rotation
  const contentPool = [
    // Equipment and Maintenance Topics
    {
      title: "Fairway Mowing Patterns: Creating Professional Presentation",
      summary: "Professional techniques for creating distinctive mowing patterns on fairways, including equipment setup, cutting heights, and pattern rotation strategies.",
      content: "Master greenkeepers share their expertise on creating professional fairway presentations through strategic mowing patterns. Key considerations include: alternating patterns weekly to prevent grain development, maintaining consistent cutting heights between 12-15mm, using overlap techniques for clean pattern transitions, and coordinating with tournament schedules. Equipment calibration is critical - ensure all mowers are set to identical heights and blade sharpness is maintained. Pattern rotation prevents turf stress and maintains healthy grass growth while delivering the visual impact expected on championship courses.",
      category: "maintenance",
      source: "Professional Greenkeeping Manual",
      tags: ["mowing", "fairways", "patterns", "presentation", "equipment"],
      relevantProducts: ["Mowing Equipment", "Fairway Maintenance"]
    },
    // Disease Management
    {
      title: "Early Season Disease Prevention Strategies",
      summary: "Comprehensive approach to preventing common turf diseases during spring transition periods, including fungicide rotation and cultural practices.",
      content: "Spring disease prevention requires a multi-faceted approach combining cultural practices with targeted fungicide applications. Key strategies include: improving air circulation through selective tree pruning, managing moisture levels through proper irrigation timing, implementing preventive fungicide programs with rotating modes of action, and monitoring soil temperature and humidity levels. Dollar spot, anthracnose, and fusarium are primary concerns during spring conditions. Establish monitoring protocols, maintain detailed application records, and coordinate with weather forecasting to optimize spray timing.",
      category: "disease",
      source: "Turf Disease Management Guide",
      tags: ["disease", "prevention", "spring", "fungicides", "monitoring"],
      relevantProducts: ["Fungicides", "Disease Prevention", "Monitoring Equipment"]
    },
    // Nutrition and Fertility
    {
      title: "Precision Nutrition for Championship Greens",
      summary: "Advanced fertility programs for maintaining consistent green quality throughout the playing season, including micronutrient management.",
      content: "Championship green nutrition requires precise nutrient management tailored to grass species, soil conditions, and play intensity. Program elements include: regular soil testing every 6-8 weeks, customized NPK ratios based on growth patterns, strategic micronutrient applications for color and density, and growth regulation integration. Monitor tissue analysis results, adjust programs based on weather patterns, and coordinate with tournament schedules. Liquid applications provide rapid response, while granular programs offer sustained nutrition. Document all applications and maintain detailed fertility records for program optimization.",
      category: "nutrition",
      source: "Championship Course Management",
      tags: ["nutrition", "greens", "fertilizer", "soil", "championship"],
      relevantProducts: ["Fertilizers", "Soil Testing", "Micronutrients"]
    }
  ];

  // Add seasonal and weather-specific content
  const currentMonth = new Date().getMonth();
  let seasonalContent = [];
  
  if (currentMonth >= 2 && currentMonth <= 5) { // Spring content
    seasonalContent = [
      {
        title: "Spring Recovery and Renovation Programs",
        summary: "Comprehensive spring renovation strategies including overseeding, aeration, and recovery from winter damage.",
        content: "Spring renovation success depends on timing, weather conditions, and proper material selection. Essential steps include: assessing winter damage extent, planning aeration and overseeding programs, selecting appropriate seed varieties for local conditions, coordinating renovation with early season play demands. Monitor soil temperature (minimum 10°C for germination), ensure adequate moisture for establishment, and protect newly seeded areas from excessive traffic. Document recovery progress and adjust programs based on weather patterns.",
        category: "renovation",
        source: "Seasonal Turf Management",
        tags: ["spring", "renovation", "overseeding", "aeration", "recovery"],
        relevantProducts: ["Seed", "Aeration Equipment", "Renovation Tools"]
      }
    ];
  } else if (currentMonth >= 6 && currentMonth <= 8) { // Summer content
    seasonalContent = [
      {
        title: "Summer Stress Management and Heat Protection",
        summary: "Strategies for maintaining turf quality during peak summer stress periods, including irrigation optimization and heat mitigation.",
        content: "Summer stress management requires proactive approaches to heat, drought, and traffic pressure. Key strategies include: early morning irrigation to maximize efficiency, implementing syringing programs for temperature reduction, adjusting cutting heights for heat tolerance, monitoring soil moisture at multiple depths. Establish heat stress protocols, coordinate with play schedules for recovery periods, and maintain equipment for peak efficiency. Document stress indicators and response effectiveness for program refinement.",
        category: "stress",
        source: "Summer Turf Management",
        tags: ["summer", "stress", "heat", "irrigation", "management"],
        relevantProducts: ["Irrigation Systems", "Heat Stress Products", "Monitoring Equipment"]
      }
    ];
  }

  const allContent = [...contentPool, ...seasonalContent];
  
  // Get existing content to avoid duplicates
  const existingNews = await storage.getIndustryNews();
  const existingTitles = new Set(existingNews.map(news => news.title));
  
  let count = 0;
  for (const article of allContent) {
    if (!existingTitles.has(article.title)) {
      try {
        const newsItem: InsertIndustryNews = {
          title: article.title,
          summary: article.summary,
          content: article.content,
          category: article.category,
          source: article.source,
          sourceUrl: "#",
          imageUrl: undefined,
          publishedDate: new Date(),
          relevantProducts: article.relevantProducts,
          tags: article.tags,
          priority: "normal"
        };

        await storage.createIndustryNews(newsItem);
        count++;
        console.log(`Added professional content: ${article.title}`);
      } catch (error) {
        console.error(`Failed to add content: ${error}`);
      }
    }
  }

  return { success: count > 0, count };
}

export async function addFallbackContent(): Promise<{ success: boolean; count: number }> {
  console.log('Adding fallback greenkeeping content...');
  
  const fallbackArticles = [
    {
      title: 'Integrated Disease Management for Championship Conditions',
      summary: 'Advanced fungicide rotation strategies combined with cultural practices for maintaining tournament-ready surfaces during high disease pressure periods.',
      content: 'Championship golf courses require sophisticated disease management protocols that extend beyond standard cultural practices. Recent field trials demonstrate how strategic fungicide rotation programs achieve superior disease control while maintaining environmental stewardship standards. Heritage Action applications at 0.8 L/ha provide 21-28 day protection against dollar spot, brown patch, and summer patch when applied during optimal temperature windows (15-25°C). Tank mixing with Instrata at 0.6 L/ha extends control spectrum to include anthracnose and fairy ring, particularly valuable during tournament preparation phases. Cultural practice timing significantly influences disease development patterns. Morning irrigation schedules allowing leaf surfaces to dry before 10 AM reduce disease pressure by 40-60% compared to evening programs. Air circulation improvement through selective vegetation management and strategic fan placement reduces disease incidents by 30-50% in susceptible areas. Nutritional programs supporting disease resistance include balanced potassium applications (150-200 kg/ha annually) in split applications during active growth periods.',
      category: 'techniques',
      source: 'Greenkeeper Professional Standards',
      priority: 'high'
    },
    {
      title: 'Water Conservation Technology Reduces Irrigation Costs 45%',
      summary: 'Smart sensor networks and variable rate irrigation systems enable precision water management while maintaining superior playing conditions.',
      content: 'Water conservation technology is revolutionizing golf course irrigation management, enabling significant cost reductions while improving turf quality. Smart sensor networks installed at 20-meter grid intervals provide real-time soil moisture data at multiple depths, enabling precision irrigation that delivers water only when and where needed. Courses implementing comprehensive sensor systems report 40-55% reduction in water usage compared to timer-based schedules. Variable rate irrigation systems adjust application rates automatically based on soil conditions, slope, and microclimatic factors. GPS-guided systems accommodate varying soil types and drainage characteristics across different course areas. Installation typically recovers costs within 2-3 seasons through reduced water bills and improved turf consistency. Weather station integration provides additional data for irrigation scheduling decisions. Evapotranspiration calculations combined with soil moisture monitoring optimize irrigation timing and duration. Systems accommodate rainfall adjustments and forecast-based scheduling to prevent overwatering.',
      category: 'techniques',
      source: 'Irrigation Technology Review',
      priority: 'high'
    }
  ];

  let count = 0;
  for (const article of fallbackArticles) {
    try {
      const newsItem: InsertIndustryNews = {
        title: article.title,
        summary: article.summary,
        content: article.content,
        category: article.category,
        source: article.source,
        sourceUrl: `https://greenkeeper-resources.com/${encodeURIComponent(article.title.toLowerCase())}`,
        publishedDate: new Date(),
        relevantProducts: [],
        tags: [article.category],
        priority: article.priority as 'high' | 'normal' | 'critical'
      };
      
      await storage.createIndustryNews(newsItem);
      count++;
    } catch (error) {
      console.error('Error adding fallback content:', error);
    }
  }
  
  return { success: count > 0, count };
}

// Function to fetch and store funny greenkeeping videos
// Function to fetch and store Reddit greenkeeping content
// Function to fetch and store Google Custom Search content
export async function fetchAndStoreGoogleSearchContent(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const errors: string[] = [];
  let count = 0;

  try {
    console.log('Fetching content from Google Custom Search...');
    
    // Check today's Google Search content to enforce daily limits
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const allNews = await storage.getIndustryNews();
    const todaySearchNews = allNews.filter(news => 
      news.source?.includes('Google Search') && 
      new Date(news.createdAt).getTime() >= today.getTime()
    );
    
    if (todaySearchNews.length >= 15) {
      return { success: false, count: 0, errors: ['Daily Google Search limit reached (15 articles)'] };
    }
    
    const remainingSlots = Math.max(0, 15 - todaySearchNews.length);
    const searchArticles = await fetchGoogleCustomSearchContent();

    if (searchArticles.length === 0) {
      return { success: false, count: 0, errors: ['No articles found from Google Custom Search'] };
    }

    // Get existing content URLs to prevent duplicates
    const existingUrls = new Set(allNews.map(news => news.sourceUrl));

    // Process articles within daily limits
    const maxPerFetch = Math.min(5, remainingSlots);
    for (const article of searchArticles.slice(0, maxPerFetch)) {
      try {
        // Skip if already exists
        if (existingUrls.has(article.url)) {
          console.log(`Skipping duplicate: ${article.title}`);
          continue;
        }
        
        // Check for similar titles only against other search results
        const searchPrefix = '[SEARCH] ';
        const cleanArticleTitle = article.title.toLowerCase();
        const similarSearchTitle = allNews
          .filter(news => news.source?.includes('Google Search'))
          .find(news => {
            const cleanExistingTitle = news.title.replace(searchPrefix, '').toLowerCase();
            return calculateStringSimilarity(cleanExistingTitle, cleanArticleTitle) > 0.85;
          });
        
        if (similarSearchTitle) {
          console.log(`Skipping similar search title: ${article.title}`);
          continue;
        }
        
        const newsItem: InsertIndustryNews = {
          title: `[SEARCH] ${article.title}`,
          summary: article.summary,
          content: article.summary,
          category: "articles",
          source: `Google Search - ${article.source}`,
          sourceUrl: article.url,
          publishedDate: new Date(article.publishedDate),
          relevantProducts: extractRelevantProducts(article.title, article.summary),
          tags: ["google-search", "professional", "industry", "articles"],
          priority: "normal"
        };

        await storage.createIndustryNews(newsItem);
        count++;
        console.log(`Added Google Search article: ${article.title} from ${article.source}`);
        
      } catch (error) {
        errors.push(`Failed to add search article: ${error}`);
      }
    }

    return { success: count > 0, count, errors };
    
  } catch (error) {
    errors.push(`Google Search fetch failed: ${error}`);
    return { success: false, count: 0, errors };
  }
}

export async function fetchAndStoreRedditContent(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const errors: string[] = [];
  let count = 0;
  let imageCount = 0;

  try {
    console.log('Fetching high-quality Reddit greenkeeping content...');
    
    // Check today's Reddit content to enforce daily limits
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const allNews = await storage.getIndustryNews();
    const todayRedditNews = allNews.filter(news => 
      news.source?.startsWith('r/') && 
      new Date(news.createdAt).getTime() >= today.getTime()
    );
    
    if (todayRedditNews.length >= 24) {
      return { success: false, count: 0, errors: ['Daily Reddit limit reached (24 articles)'] };
    }
    
    const todayRedditImages = todayRedditNews.filter(news => news.imageUrl).length;
    const remainingImageSlots = Math.max(0, 10 - todayRedditImages);
    const remainingArticleSlots = Math.max(0, 24 - todayRedditNews.length);

    const redditPosts = await fetchRedditGreenkeepingContent();

    if (redditPosts.length === 0) {
      console.log('No Reddit posts found');
      return { success: false, count: 0, errors: ['No high-quality Reddit posts found'] };
    }

    // Get existing content URLs to prevent duplicates
    const existingUrls = new Set(allNews.map(news => news.sourceUrl));

    // Process posts within daily limits, checking for duplicates - max 5 per manual fetch
    const maxPerFetch = Math.min(5, remainingArticleSlots);
    for (const post of redditPosts.slice(0, maxPerFetch)) {
      try {
        const postUrl = `https://www.reddit.com/r/${post.subreddit}/comments/${post.id}`;
        
        // Skip if already exists
        if (existingUrls.has(postUrl)) {
          console.log(`Skipping duplicate: ${post.title}`);
          continue;
        }
        
        // Check for similar titles only against other Reddit posts (more specific duplicate detection)
        const redditPrefix = '[REDDIT] ';
        const cleanPostTitle = post.title.toLowerCase();
        const similarRedditTitle = allNews
          .filter(news => news.source?.startsWith('r/')) // Only compare against other Reddit posts
          .find(news => {
            const cleanExistingTitle = news.title.replace(redditPrefix, '').toLowerCase();
            return calculateStringSimilarity(cleanExistingTitle, cleanPostTitle) > 0.85; // Stricter threshold
          });
        
        if (similarRedditTitle) {
          console.log(`Skipping similar Reddit title: ${post.title}`);
          continue;
        }
        
        // Handle image content with daily limit
        let imageUrl = undefined;
        if (post.thumbnail && post.thumbnail !== 'self' && post.thumbnail !== 'default' && imageCount < remainingImageSlots) {
          imageUrl = post.thumbnail;
          imageCount++;
        }
        
        const newsItem: InsertIndustryNews = {
          title: `[REDDIT] ${post.title}`,
          summary: post.selftext.substring(0, 300) + (post.selftext.length > 300 ? '...' : ''),
          content: post.selftext,
          category: "discussion",
          source: `r/${post.subreddit}`,
          sourceUrl: postUrl,
          imageUrl: imageUrl,
          publishedDate: new Date(post.created_utc * 1000),
          relevantProducts: extractRelevantProducts(post.title, post.selftext),
          tags: ["reddit", "discussion", "community", post.subreddit.toLowerCase()],
          priority: post.score > 100 ? "high" : "normal"
        };

        await storage.createIndustryNews(newsItem);
        count++;
        console.log(`Added Reddit post: ${post.title} (${post.score} upvotes)${imageUrl ? ' with image' : ''}`);
        
      } catch (error) {
        errors.push(`Failed to add Reddit post: ${error}`);
      }
    }

    return { success: count > 0, count, errors };
    
  } catch (error) {
    errors.push(`Reddit fetch failed: ${error}`);
    return { success: false, count: 0, errors };
  }
}

export async function fetchAndStoreFunnyVideos(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const errors: string[] = [];
  let count = 0;

  try {
    console.log('Fetching funny greenkeeping videos from YouTube...');
    
    // Check today's YouTube video count to enforce daily limit (5 videos max)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const allNews = await storage.getIndustryNews();
    const todayYouTubeVideos = allNews.filter(news => 
      news.title.includes('[VIDEO]') && 
      news.source?.includes('YouTube') &&
      new Date(news.createdAt).getTime() >= today.getTime()
    );
    
    if (todayYouTubeVideos.length >= 5) {
      return { success: false, count: 0, errors: ['Daily YouTube video limit reached (5 videos)'] };
    }
    
    const remainingVideoSlots = Math.max(0, 5 - todayYouTubeVideos.length);
    const funnyVideos = await fetchFunnyGreenkeepingVideos();

    if (funnyVideos.length === 0) {
      console.log('No funny videos found, adding curated comedy content...');
      
      // Add some curated funny content as fallback
      const funnyFallback = [
        {
          title: "[COMEDY] When Your Sprinkler System Develops Artificial Intelligence",
          summary: "Every greenkeeper's nightmare: the irrigation system that waters everything except the grass. Watch as one brave groundskeeper battles technology gone rogue!",
          content: "This hilarious compilation shows sprinkler systems with a mind of their own - watering car parks, clubhouse windows, and unsuspecting golfers while leaving the greens bone dry.",
          category: "videos",
          source: "YouTube Comedy",
          sourceUrl: "https://youtube.com/watch?v=example1",
          publishedDate: new Date(),
          relevantProducts: ["Irrigation Systems"],
          tags: ["funny", "irrigation", "comedy", "youtube", "video"],
          priority: "normal"
        },
        {
          title: "[VIRAL] Mower vs Bunker: The Epic Battle of 2024",
          summary: "Watch this ride-on mower's surprise detour into a sand bunker, complete with unexpected pirouettes and a very confused greenkeeper!",
          content: "Sometimes equipment has other plans. This viral video shows a mower's dramatic interpretation of 'sand play' that had the entire golf course in stitches.",
          category: "videos", 
          source: "YouTube Comedy",
          sourceUrl: "https://youtube.com/watch?v=example2",
          publishedDate: new Date(),
          relevantProducts: ["Ride-on Mowers"],
          tags: ["funny", "mowing", "equipment", "youtube", "video"],
          priority: "normal"
        },
        {
          title: "[LAUGHS] Fertilizer Spreader Gone Wild - Comedy Gold",
          summary: "When your spreader decides to create abstract art instead of uniform coverage. Modern art meets greenkeeping in this unexpected masterpiece!",
          content: "Watch as a fertilizer spreader creates the most artistic pattern ever seen on a fairway. The result? Pure comedy and one very unique hole layout.",
          category: "videos",
          source: "YouTube Comedy",
          sourceUrl: "https://youtube.com/watch?v=example3", 
          publishedDate: new Date(),
          relevantProducts: ["Fertilizer Spreaders"],
          tags: ["funny", "fertilizer", "equipment", "youtube", "video"],
          priority: "normal"
        }
      ];

      for (const item of funnyFallback) {
        try {
          await storage.createIndustryNews(item);
          count++;
          console.log(`Added funny content: ${item.title}`);
        } catch (error) {
          errors.push(`Failed to add funny content: ${error}`);
        }
      }
    } else {
      // Process actual YouTube videos within daily limit
      for (const video of funnyVideos.slice(0, remainingVideoSlots)) {
        try {
          const videoUrl = `https://www.youtube.com/watch?v=${video.id.videoId}`;
          const thumbnail = video.snippet.thumbnails?.medium?.url || video.snippet.thumbnails?.default?.url;
          
          const newsItem: InsertIndustryNews = {
            title: `[COMEDY] ${video.snippet.title}`,
            summary: video.snippet.description.substring(0, 200) + (video.snippet.description.length > 200 ? '...' : ''),
            content: `Funny greenkeeping video: ${video.snippet.description}`,
            category: "videos",
            source: "YouTube Comedy",
            sourceUrl: videoUrl,
            imageUrl: thumbnail,
            publishedDate: new Date(video.snippet.publishedAt),
            relevantProducts: ["General Maintenance"],
            tags: ["funny", "video", "comedy", "youtube"],
            priority: "normal"
          };

          await storage.createIndustryNews(newsItem);
          count++;
          console.log(`Added funny video: ${video.snippet.title}`);
          
        } catch (error) {
          errors.push(`Failed to add video: ${error}`);
        }
      }
    }

    return { success: count > 0, count, errors };
    
  } catch (error) {
    errors.push(`Funny video fetch failed: ${error}`);
    return { success: false, count: 0, errors };
  }
}

export async function fetchAndStoreNews(newsApiKey?: string): Promise<{ success: boolean; count: number; errors: string[] }> {
  const errors: string[] = [];
  let totalCount = 0;

  try {
    // Fetch from RSS feeds
    for (const feed of RSS_FEEDS) {
      try {
        console.log(`Fetching RSS from ${feed.source}...`);
        const rssData = await rssParser.parseURL(feed.url);
        
        for (const item of rssData.items.slice(0, 5)) { // Limit to 5 most recent per feed
          try {
            // Check if we already have this article using advanced duplicate detection
            const existingNews = await storage.getIndustryNews();
            if (isDuplicate({ title: item.title, url: item.link, summary: item.contentSnippet || item.description }, existingNews)) {
              continue;
            }

            const publishedDate = item.pubDate ? new Date(item.pubDate) : new Date();
            const summary = item.contentSnippet || item.description || '';
            const category = categorizeContent(item.title || '', summary);
            
            // Skip excluded content (non-golf related)
            if (category === 'excluded') continue;
            
            const relevantProducts = extractRelevantProducts(item.title || '', summary);

            // Preserve complete content from RSS feeds
            const fullContent = item.content || item.contentSnippet || summary;
            
            // Create comprehensive content structure with professional context
            let completeContent = fullContent;
            
            // For short content, enhance with professional greenkeeping context
            if (fullContent.length < 500) {
              const enhancedSections = [
                `## ${item.title || 'Industry Update'}`,
                '',
                summary || item.description || '',
                '',
                item.contentSnippet || item.content || '',
                '',
                `### Professional Context`,
                `This development is relevant to golf course maintenance professionals, particularly regarding ${item.categories?.join(', ') || 'industry practices'}. Greenkeepers should consider the implications for course management and operational procedures.`,
                '',
                `### Source Information`,
                `Published by: ${feed.source}`,
                `Publication Date: ${publishedDate.toLocaleDateString()}`,
                item.link ? `Original Article: ${item.link}` : '',
                '',
                `*This article has been curated for golf course maintenance professionals and greenkeepers.*`
              ].filter(Boolean);
              
              completeContent = enhancedSections.join('\n');
            }
            
            const newsItem: InsertIndustryNews = {
              title: item.title || 'Untitled',
              summary: summary.substring(0, 300),
              content: completeContent,
              category,
              source: feed.source,
              sourceUrl: item.link || '',
              publishedDate,
              relevantProducts,
              tags: item.categories || [],
              priority: feed.priority
            };

            await storage.createIndustryNews(newsItem);
            totalCount++;
            console.log(`Stored: ${newsItem.title}`);
          } catch (itemError) {
            errors.push(`Error processing RSS item: ${itemError}`);
          }
        }
      } catch (feedError) {
        errors.push(`Error fetching RSS from ${feed.source}: ${feedError}`);
        console.error(`RSS feed error for ${feed.source}:`, feedError);
      }
    }

    // Fetch from News API if key provided
    if (newsApiKey) {
      try {
        console.log('Fetching from News API...');
        const articles = await fetchNewsFromAPI(newsApiKey);
        
        for (const article of articles.slice(0, 10)) { // Limit to 10 most recent
          try {
            // Check if we already have this article using advanced duplicate detection
            const existingNews = await storage.getIndustryNews();
            if (isDuplicate({ title: article.title, url: article.url, summary: article.description }, existingNews)) {
              continue;
            }

            const publishedDate = new Date(article.publishedAt);
            const category = categorizeContent(article.title, article.description || '');
            
            // Skip excluded content (non-golf related)
            if (category === 'excluded') continue;
            
            const relevantProducts = extractRelevantProducts(article.title, article.description || '');

            // Create comprehensive article content from available data
            let fullContent = article.content || article.description || '';
            const contentText = `${article.title} ${article.description || ''}`.toLowerCase();
            const mainGolfTerms = ['golf course', 'greenkeeper', 'turf', 'greens', 'fairway', 'tee', 'golf maintenance', 'superintendent'];
            const hasMainGolfContent = mainGolfTerms.some(term => contentText.includes(term));
            
            // Enhance short articles with structured content
            if (fullContent.length < 500) {
              const enhancedArticle = [
                `## ${article.title}`,
                '',
                article.description || '',
                '',
                article.content || '',
                '',
                `### Industry Relevance`,
                hasMainGolfContent 
                  ? `This development directly impacts golf course operations and maintenance practices. Greenkeepers should evaluate how this affects their course management strategies.`
                  : `This industry development may have implications for turf management and golf course operations. Consider the potential impact on maintenance procedures and equipment decisions.`,
                '',
                `### Source Details`,
                `Published by: ${article.source?.name || 'Industry Source'}`,
                `Publication Date: ${new Date(article.publishedAt).toLocaleDateString()}`,
                `Original Source: ${article.url}`,
                '',
                `*Article curated for golf course maintenance professionals*`
              ].filter(Boolean);
              
              fullContent = enhancedArticle.join('\n');
            }
            
            console.log(`Enhanced article: "${article.title}" - ${fullContent.length} chars`);

            // Prioritize high-quality professional content
            const articleText = `${article.title} ${article.description || ''}`.toLowerCase();
            const qualityTerms = [
              'research', 'study', 'trial', 'university', 'institute', 'association',
              'conference', 'seminar', 'best practices', 'guidelines', 'standards',
              'certification', 'training', 'education', 'professional development'
            ];
            const professionalGolfTerms = ['golf course', 'greenkeeper', 'turf', 'greens', 'fairway', 'tee', 'golf maintenance'];
            const hasQualityIndicators = qualityTerms.some(term => articleText.includes(term));
            const hasProfessionalGolfContent = professionalGolfTerms.some(term => articleText.includes(term));
            const priority = (hasQualityIndicators || hasMainGolfContent) ? 'high' : 'normal';

            const newsItem: InsertIndustryNews = {
              title: article.title,
              summary: (article.description || '').substring(0, 300),
              content: fullContent,
              category,
              source: article.source?.name || 'News API',
              sourceUrl: article.url,
              publishedDate,
              relevantProducts,
              tags: [category],
              priority
            };

            await storage.createIndustryNews(newsItem);
            totalCount++;
            console.log(`Stored from News API: ${newsItem.title}`);
          } catch (itemError) {
            errors.push(`Error processing News API item: ${itemError}`);
          }
        }
      } catch (apiError) {
        errors.push(`News API error: ${apiError}`);
        console.error('News API error:', apiError);
      }
    }

    return { success: true, count: totalCount, errors };
  } catch (error) {
    errors.push(`General error: ${error}`);
    return { success: false, count: totalCount, errors };
  }
}

// One-time RSS content harvest function
export async function harvestRSSContent(): Promise<{ success: boolean; count: number; errors: string[] }> {
  const errors: string[] = [];
  let totalCount = 0;

  console.log('Starting one-time RSS content harvest...');

  for (const feed of RSS_FEEDS_HARVEST) {
    try {
      console.log(`Harvesting from ${feed.source}...`);
      const rssData = await rssParser.parseURL(feed.url);
      
      for (const item of rssData.items.slice(0, 20)) { // Get up to 20 articles per feed
        try {
          // Check if we already have this article
          const existingNews = await storage.getIndustryNews();
          const exists = existingNews.some(news => 
            news.title === item.title || news.sourceUrl === item.link
          );
          
          if (exists) continue;

          const publishedDate = item.pubDate ? new Date(item.pubDate) : new Date();
          const summary = item.contentSnippet || item.description || '';
          const category = categorizeContent(item.title || '', summary);
          
          // Skip excluded content (non-golf related)
          if (category === 'excluded') continue;
          
          const relevantProducts = extractRelevantProducts(item.title || '', summary);

          const newsItem: InsertIndustryNews = {
            title: item.title || 'Untitled',
            summary: summary.substring(0, 300),
            content: item.content || summary,
            category,
            source: feed.source,
            sourceUrl: item.link || '',
            publishedDate,
            relevantProducts,
            tags: item.categories || [],
            priority: feed.priority
          };

          await storage.createIndustryNews(newsItem);
          totalCount++;
          console.log(`Harvested: ${item.title}`);

        } catch (itemError) {
          console.error(`Error processing item from ${feed.source}:`, itemError);
        }
      }
    } catch (feedError) {
      console.error(`RSS harvest error for ${feed.source}:`, feedError);
      errors.push(`Error harvesting from ${feed.source}: ${feedError instanceof Error ? feedError.message : String(feedError)}`);
    }
  }

  console.log(`RSS harvest completed. Total articles harvested: ${totalCount}`);
  return { success: true, count: totalCount, errors };
}

export async function cleanOldNews(daysOld: number = 30): Promise<number> {
  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);
    
    const allNews = await storage.getIndustryNews();
    let deletedCount = 0;
    
    for (const news of allNews) {
      if (new Date(news.publishedDate) < cutoffDate) {
        await storage.deleteIndustryNews(news.id);
        deletedCount++;
      }
    }
    
    return deletedCount;
  } catch (error) {
    console.error('Error cleaning old news:', error);
    return 0;
  }
}

// Professional RSS content fetcher
export async function fetchAndStoreProfessionalRSSContent(): Promise<{ success: boolean; count: number; errors?: string[] }> {
  try {
    const allNews = await storage.getIndustryNews();
    
    // Check daily limits for professional RSS content
    const today = new Date().toISOString().split('T')[0];
    const todayProfessionalNews = allNews.filter(news => 
      news.createdAt.toISOString().split('T')[0] === today && 
      news.source?.includes('Professional RSS')
    );
    
    if (todayProfessionalNews.length >= 20) {
      return { success: false, count: 0, errors: ['Daily professional RSS limit reached (20 articles)'] };
    }
    
    const professionalArticles = [];
    
    for (const feed of PROFESSIONAL_RSS_FEEDS) {
      try {
        console.log(`Fetching from ${feed.source}...`);
        const feedData = await rssParser.parseURL(feed.url);
        
        for (const item of feedData.items.slice(0, 4)) {
          if (!item.title || !item.link) continue;
          
          professionalArticles.push({
            title: item.title,
            summary: item.contentSnippet || item.summary || 'Professional greenkeeping article',
            url: item.link,
            source: feed.source,
            publishedDate: item.pubDate ? new Date(item.pubDate) : new Date(),
            priority: feed.priority
          });
        }
      } catch (feedError) {
        console.log(`Error fetching from ${feed.source}:`, feedError);
        continue;
      }
    }

    if (professionalArticles.length === 0) {
      return { success: false, count: 0, errors: ['No articles found from professional RSS feeds'] };
    }

    const existingUrls = new Set(allNews.map(news => news.sourceUrl));
    let addedCount = 0;
    const remainingSlots = Math.max(0, 20 - todayProfessionalNews.length);
    const maxPerFetch = Math.min(10, remainingSlots);

    for (const article of professionalArticles.slice(0, maxPerFetch)) {
      try {
        if (existingUrls.has(article.url)) {
          continue;
        }
        
        const newsItem: InsertIndustryNews = {
          title: `[PROFESSIONAL] ${article.title}`,
          summary: article.summary,
          content: article.summary,
          category: "articles",
          source: `Professional RSS - ${article.source}`,
          sourceUrl: article.url,
          publishedDate: article.publishedDate,
          relevantProducts: extractRelevantProducts(article.title, article.summary),
          tags: ["professional", "rss", "industry", "articles"],
          priority: article.priority
        };

        await storage.createIndustryNews(newsItem);
        addedCount++;
        
      } catch (error) {
        console.error(`Error adding professional article: ${article.title}`, error);
        continue;
      }
    }

    return { 
      success: true, 
      count: addedCount,
      message: `Successfully fetched ${addedCount} professional articles from industry RSS feeds`
    };
    
  } catch (error) {
    console.error("Professional RSS fetch error:", error);
    return { success: false, count: 0, errors: [`Professional RSS fetch failed: ${error}`] };
  }
}