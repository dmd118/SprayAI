import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { storage } from './storage';
import type { User, Club } from '@shared/schema';

const JWT_SECRET = process.env.JWT_SECRET || 'dullatur_golf_secret_key_2025';
const SALT_ROUNDS = 12;

export interface AuthToken {
  userId: number;
  clubId: number;
  username: string;
  clubName: string;
  subscriptionStatus: string;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(payload: AuthToken, rememberMe = false): string {
  const expiresIn = rememberMe ? '30d' : '7d';
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

export function verifyToken(token: string): AuthToken | null {
  try {
    return jwt.verify(token, JWT_SECRET) as AuthToken;
  } catch {
    return null;
  }
}

export async function authenticateUser(usernameOrEmail: string, password: string, rememberMe = false): Promise<{ token: string; user: User; club: Club } | null> {
  try {
    // Try to find user by username first
    let user = await storage.getUserByUsername(usernameOrEmail);
    
    // If not found by username, try by email
    if (!user) {
      user = await storage.getUserByEmail(usernameOrEmail);
    }
    
    if (!user) return null;

    const isValidPassword = await verifyPassword(password, user.passwordHash);
    if (!isValidPassword) return null;

    const club = await storage.getClub(user.clubId);
    if (!club) return null;

    const tokenPayload: AuthToken = {
      userId: user.id,
      clubId: user.clubId,
      username: user.username,
      clubName: club.name,
      subscriptionStatus: club.subscriptionStatus
    };

    const token = generateToken(tokenPayload, rememberMe);
    return { token, user, club };
  } catch (error) {
    console.error('Authentication error:', error);
    return null;
  }
}

export function requireAuth(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authentication required' });
  }

  const token = authHeader.substring(7);
  const decoded = verifyToken(token);
  
  if (!decoded) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }

  req.user = decoded;
  next();
}

export function requireActiveSubscription(req: any, res: any, next: any) {
  const user = req.user as AuthToken;
  
  if (!user) {
    return res.status(401).json({ message: 'Authentication required' });
  }

  // Allow grandfathered accounts and active subscriptions
  if (user.subscriptionStatus === 'grandfathered_active' || user.subscriptionStatus === 'active') {
    return next();
  }

  return res.status(403).json({ 
    message: 'Active subscription required',
    subscriptionStatus: user.subscriptionStatus
  });
}