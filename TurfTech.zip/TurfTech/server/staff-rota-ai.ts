// AI-Powered Staff Rota Management System
import { storage } from './storage';
import type { StaffMember, InsertStaffRota, RotaConfig } from '@shared/schema';

interface RotaParameters {
  totalStaff: number;
  annualHours: number;
  weekendStartTime: string;
  weekendEndTime: string;
  christmasStartDate: Date;
  christmasEndDate: Date;
  minimumStaffOnDuty: number;
}

interface WeekendShift {
  date: Date;
  staffId: number;
  staffName: string;
  startTime: string;
  endTime: string;
  hoursWorked: number;
}

export class StaffRotaAI {
  
  /**
   * Determine seasonal staffing requirements using weather API
   */
  private async getSeasonalStaffingRequirement(date: Date, params: RotaParameters): Promise<{
    season: string;
    staffCount: number;
    reasoning: string;
  }> {
    try {
      // Check if it's Christmas period first
      const isChristmasWeek = (
        date >= params.christmasStartDate && 
        date <= params.christmasEndDate
      );
      
      if (isChristmasWeek) {
        return {
          season: 'Christmas',
          staffCount: 1,
          reasoning: 'Christmas period requires minimum coverage'
        };
      }
      
      // Get weather data to determine season
      const weatherResponse = await fetch('http://localhost:5000/api/weather');
      if (!weatherResponse.ok) {
        // Fallback to date-based logic if weather API unavailable
        const month = date.getMonth();
        const isSummer = month >= 2 && month <= 8; // March to September
        return {
          season: isSummer ? 'Summer' : 'Winter',
          staffCount: isSummer ? 4 : 2,
          reasoning: 'Weather API unavailable, using date-based logic'
        };
      }
      
      const weatherData = await weatherResponse.json();
      const currentTemp = weatherData.weather?.temperature || 0;
      
      // Determine season based on temperature and date
      const month = date.getMonth() + 1; // 1-12
      const isDaytimeGrowingSeason = currentTemp >= 10 && (month >= 3 && month <= 9);
      
      if (isDaytimeGrowingSeason) {
        return {
          season: 'Summer',
          staffCount: 4, // 2 Full-time + 2 Seasonal
          reasoning: `Growing season detected: ${currentTemp}°C, month ${month}`
        };
      } else {
        return {
          season: 'Winter',
          staffCount: 2, // 2 Full-time only
          reasoning: `Dormant season: ${currentTemp}°C, month ${month}`
        };
      }
      
    } catch (error) {
      console.error('Error determining seasonal requirements:', error);
      // Safe fallback
      const month = date.getMonth();
      const isSummer = month >= 2 && month <= 8;
      return {
        season: isSummer ? 'Summer' : 'Winter',
        staffCount: isSummer ? 4 : 2,
        reasoning: 'Error occurred, using safe fallback logic'
      };
    }
  }
  
  /**
   * Generate a full year's weekend rota with AI optimization
   */
  async generateOptimalRota(params: RotaParameters): Promise<{
    success: boolean;
    rota: WeekendShift[];
    fairnessReport: {
      staffId: number;
      name: string;
      weekendsAssigned: number;
      hoursWorked: number;
      timeOffOwed: number;
    }[];
    christmasCoverage: WeekendShift[];
  }> {
    try {
      // Use the predefined staff structure: 1-6 FE, 7 F, 8-11 S
      const activeStaff = [
        { id: 1, name: "1 FE", role: "Full Experience", isActive: true },
        { id: 2, name: "2 FE", role: "Full Experience", isActive: true },
        { id: 3, name: "3 FE", role: "Full Experience", isActive: true },
        { id: 4, name: "4 FE", role: "Full Experience", isActive: true },
        { id: 5, name: "5 FE", role: "Full Experience", isActive: true },
        { id: 6, name: "6 FE", role: "Full Experience", isActive: true },
        { id: 7, name: "7 F", role: "Full Time", isActive: true },
        { id: 8, name: "8 S", role: "Seasonal", isActive: true },
        { id: 9, name: "9 S", role: "Seasonal", isActive: true },
        { id: 10, name: "10 S", role: "Seasonal", isActive: true },
        { id: 11, name: "11 S", role: "Seasonal", isActive: true }
      ];
      
      if (activeStaff.length === 0) {
        throw new Error("No active staff members found");
      }

      // Calculate weekend dates for the year
      const weekendDates = this.generateWeekendDates(new Date().getFullYear());
      console.log(`Generated ${weekendDates.length} weekend dates for year ${new Date().getFullYear()}`);
      
      // Separate Christmas period dates
      const christmasWeekends = weekendDates.filter(date => 
        date >= params.christmasStartDate && date <= params.christmasEndDate
      );
      
      const regularWeekends = weekendDates.filter(date => 
        date < params.christmasStartDate || date > params.christmasEndDate
      );
      
      console.log(`Regular weekends: ${regularWeekends.length}, Christmas weekends: ${christmasWeekends.length}`);

      // Calculate hours per weekend shift
      const shiftHours = this.calculateShiftHours(params.weekendStartTime, params.weekendEndTime);
      
      // Initialize staff workload tracking
      const staffWorkload = activeStaff.map(member => ({
        staffId: member.id,
        name: member.name,
        weekendsAssigned: 0,
        hoursWorked: 0,
        timeOffOwed: 0,
        lastWeekendWorked: null as Date | null,
        consecutiveWeekends: 0
      }));

      const rota: WeekendShift[] = [];

      // Assign regular weekends using proper weekend pairs and rotation
      let lastWeekendStaff: number[] = []; // Track who worked the previous weekend to avoid consecutive assignments
      
      for (let i = 0; i < regularWeekends.length; i += 2) {
        const saturday = regularWeekends[i];
        const sunday = regularWeekends[i + 1];
        
        if (!saturday || !sunday) continue; // Skip incomplete weekend pairs
        
        // Apply clear seasonal rules based on weather data: Summer=4, Winter=2, Christmas=1
        const seasonalRequirement = await this.getSeasonalStaffingRequirement(saturday, params);
        let requiredStaff = seasonalRequirement.staffCount;
        
        console.log(`Season: ${seasonalRequirement.season}, Required staff: ${requiredStaff}`);
        
        // Add strong randomization to ensure varied schedules on each generation
        const generationSeed = Date.now() + Math.random() * 10000;
        const weekendSeed = saturday.getTime() + generationSeed + (i * 777);
        
        // DEBUG: Log the selection process
        console.log(`\n=== Weekend ${i/2 + 1}: ${saturday.toDateString()} ===`);
        console.log(`Last weekend staff:`, lastWeekendStaff);
        console.log(`Required staff: ${requiredStaff}`);
        
        // Log current workload distribution before selection
        console.log(`Current workload distribution:`);
        staffWorkload.forEach((staff, idx) => {
          console.log(`  ${idx}: ${staff.name} - ${staff.weekendsAssigned} weekends, ${staff.hoursWorked} hours`);
        });
        
        // Select staff for this weekend, avoiding those who worked last weekend
        const assignedStaff = this.selectOptimalStaff(staffWorkload, saturday, requiredStaff, lastWeekendStaff, weekendSeed);
        
        console.log(`Selected staff indices:`, assignedStaff);
        console.log(`Selected staff names:`, assignedStaff.map(idx => staffWorkload[idx]?.name));
        console.log(`Length of assignedStaff array:`, assignedStaff.length);
        
        // Assign the same staff to both Saturday and Sunday
        for (const weekendDay of [saturday, sunday]) {
          console.log(`Assigning staff for ${weekendDay.toDateString()}:`);
          for (const staffIndex of assignedStaff) {
            const staffMember = staffWorkload[staffIndex];
            console.log(`  - Assigning ${staffMember.name} (ID: ${staffMember.staffId})`);
            
            rota.push({
              date: weekendDay,
              staffId: staffMember.staffId,
              staffName: staffMember.name,
              startTime: "05:00",
              endTime: "09:00", 
              hoursWorked: 4
            });
          }
        }
        
        // Update workload tracking for the weekend (count as one weekend assignment per person)
        for (const staffIndex of assignedStaff) {
          const staffMember = staffWorkload[staffIndex];
          
          staffMember.weekendsAssigned++;
          staffMember.hoursWorked += 8; // 4 hours × 2 days = 8 hours per weekend
          staffMember.lastWeekendWorked = sunday; // Use Sunday as the last day worked
          
          // Track consecutive weekends
          if (lastWeekendStaff.includes(staffIndex)) {
            staffMember.consecutiveWeekends = (staffMember.consecutiveWeekends || 0) + 1;
          } else {
            staffMember.consecutiveWeekends = 1;
          }
        }
        
        // Remember who worked this weekend for next iteration
        lastWeekendStaff = [...assignedStaff];
      }

      // Handle Christmas period with special coverage
      const christmasCoverage = this.assignChristmasCoverage(
        staffWorkload, 
        christmasWeekends, 
        params, 
        shiftHours
      );

      rota.push(...christmasCoverage);

      // Calculate fairness adjustments
      const avgWeekends = rota.length / activeStaff.length;
      const fairnessReport = staffWorkload.map(staff => {
        const extraWeekends = staff.weekendsAssigned - Math.floor(avgWeekends);
        const timeOffOwed = extraWeekends > 1 ? (extraWeekends - 1) * shiftHours : 0;
        
        return {
          staffId: staff.staffId,
          name: staff.name,
          weekendsAssigned: staff.weekendsAssigned,
          hoursWorked: staff.hoursWorked,
          timeOffOwed
        };
      });

      return {
        success: true,
        rota: rota.sort((a, b) => a.date.getTime() - b.date.getTime()),
        fairnessReport,
        christmasCoverage
      };

    } catch (error) {
      console.error('Staff rota generation failed:', error);
      return {
        success: false,
        rota: [],
        fairnessReport: [],
        christmasCoverage: []
      };
    }
  }

  /**
   * Select optimal staff for a weekend using enhanced leapfrog rotation algorithm
   */
  private selectOptimalStaff(
    staffWorkload: any[], 
    weekendDate: Date, 
    requiredStaff: number,
    lastWeekendStaff: number[] = [],
    seed?: number
  ): number[] {
    const month = weekendDate.getMonth();
    const isSummerPeriod = month >= 3 && month <= 9;
    
    // Separate ALL experienced staff (FE + F) from seasonal staff (S)
    const experiencedStaff = staffWorkload
      .map((staff, index) => ({ ...staff, index }))
      .filter(staff => {
        const name = staff.name.toUpperCase();
        // Include ALL experienced staff: "1 FE" through "6 FE", plus "7 F" 
        return (name.includes(' FE') || 
                name.includes(' F')) &&
               !name.includes(' S') && // Exclude seasonal staff
               !lastWeekendStaff.includes(staff.index);
      });
    
    const seasonalStaff = staffWorkload
      .map((staff, index) => ({ ...staff, index }))
      .filter(staff => {
        const name = staff.name.toUpperCase();
        // Only seasonal staff: "8 S" through "11 S"
        // AND only available March-September in current year (2025)
        const year = weekendDate.getFullYear();
        const month = weekendDate.getMonth() + 1; // 1-12
        const isSeasonalPeriod = year === 2025 && month >= 3 && month <= 9;
        return name.includes(' S') &&
               isSeasonalPeriod &&
               !lastWeekendStaff.includes(staff.index);
      });

    let selectedStaff: number[] = [];

    if (requiredStaff === 4) {
      // Summer: EXACTLY 2 experienced (FE) + 2 seasonal (S) - no more, no less
      
      // AGGRESSIVE LOAD BALANCING: Always pick the least worked staff
      // Sort all experienced staff by hours worked (ascending)
      const allExperiencedSorted = experiencedStaff.sort((a, b) => a.hoursWorked - b.hoursWorked);
      const allSeasonalSorted = seasonalStaff.sort((a, b) => a.hoursWorked - b.hoursWorked);
      
      console.log(`Experienced staff sorted by hours:`, allExperiencedSorted.map(s => `${s.name}: ${s.hoursWorked}h`));
      console.log(`Seasonal staff sorted by hours:`, allSeasonalSorted.map(s => `${s.name}: ${s.hoursWorked}h`));
      
      // Filter out those who worked last weekend, but prioritize load balancing
      const availableExperienced = allExperiencedSorted.filter(staff => !lastWeekendStaff.includes(staff.index));
      const availableSeasonal = allSeasonalSorted.filter(staff => !lastWeekendStaff.includes(staff.index));
      
      let selectedExperienced: any[] = [];
      let selectedSeasonal: any[] = [];
      
      // Select 2 experienced staff with absolute lowest hours
      if (availableExperienced.length >= 2) {
        // Take the 2 with absolutely lowest hours
        selectedExperienced = availableExperienced.slice(0, 2);
        console.log(`Selected experienced (from available):`, selectedExperienced.map(s => `${s.name}: ${s.hoursWorked}h`));
      } else if (availableExperienced.length === 1) {
        // Take the 1 available, then take lowest from all others
        selectedExperienced.push(availableExperienced[0]);
        const remaining = allExperiencedSorted.filter(s => s.index !== availableExperienced[0].index);
        selectedExperienced.push(remaining[0]);
        console.log(`Selected experienced (mixed):`, selectedExperienced.map(s => `${s.name}: ${s.hoursWorked}h`));
      } else {
        // No one available (all worked last weekend), take 2 lowest hour staff anyway
        selectedExperienced = allExperiencedSorted.slice(0, 2);
        console.log(`Selected experienced (forced):`, selectedExperienced.map(s => `${s.name}: ${s.hoursWorked}h`));
      }
      
      // Select 2 seasonal staff with absolute lowest hours
      if (availableSeasonal.length >= 2) {
        selectedSeasonal = availableSeasonal.slice(0, 2);
        console.log(`Selected seasonal (from available):`, selectedSeasonal.map(s => `${s.name}: ${s.hoursWorked}h`));
      } else if (availableSeasonal.length === 1) {
        selectedSeasonal.push(availableSeasonal[0]);
        const remaining = allSeasonalSorted.filter(s => s.index !== availableSeasonal[0].index);
        selectedSeasonal.push(remaining[0]);
        console.log(`Selected seasonal (mixed):`, selectedSeasonal.map(s => `${s.name}: ${s.hoursWorked}h`));
      } else {
        selectedSeasonal = allSeasonalSorted.slice(0, 2);
        console.log(`Selected seasonal (forced):`, selectedSeasonal.map(s => `${s.name}: ${s.hoursWorked}h`));
      }
      
      selectedStaff = [
        ...selectedExperienced.map(s => s.index),
        ...selectedSeasonal.map(s => s.index)
      ];
      
      // If we don't have enough, fill with available staff who didn't work last weekend
      if (selectedStaff.length < 4) {
        const availableStaff = staffWorkload
          .map((staff, index) => ({ ...staff, index }))
          .filter(staff => !lastWeekendStaff.includes(staff.index) && !selectedStaff.includes(staff.index));
        
        const sortedAvailable = this.sortStaffByRotation(availableStaff, weekendDate, seed);
        const needed = 4 - selectedStaff.length;
        selectedStaff.push(...sortedAvailable.slice(0, needed).map(s => s.index));
      }
    } else {
      // Winter: Need 2 experienced (FE) staff only
      const availableExperienced = experiencedStaff.filter(staff => !lastWeekendStaff.includes(staff.index));
      const sortedExperienced = this.sortStaffByRotation(availableExperienced, weekendDate, seed);
      
      if (sortedExperienced.length >= requiredStaff) {
        selectedStaff = sortedExperienced.slice(0, requiredStaff).map(s => s.index);
      } else {
        // Fallback: use any available staff who didn't work last weekend
        const availableStaff = staffWorkload
          .map((staff, index) => ({ ...staff, index }))
          .filter(staff => !lastWeekendStaff.includes(staff.index));
        
        const sortedAvailable = this.sortStaffByRotation(availableStaff, weekendDate, seed);
        selectedStaff = sortedAvailable.slice(0, Math.min(requiredStaff, sortedAvailable.length)).map(s => s.index);
      }
    }

    return selectedStaff;
  }

  /**
   * Shuffle array using true randomization for varied results
   */
  private shuffleArray(array: any[], seed?: number): any[] {
    const shuffled = [...array];
    
    // Use true Math.random() for unpredictable results
    for (let i = shuffled.length - 1; i > 0; i--) {
      const randomIndex = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[randomIndex]] = [shuffled[randomIndex], shuffled[i]];
    }
    
    return shuffled;
  }

  /**
   * Sort staff by rotation priority (leapfrog pattern)
   */
  private sortStaffByRotation(staff: any[], weekendDate: Date, seed?: number): any[] {
    // Use seed to create reproducible but varied randomization
    const randomSeed = seed || weekendDate.getTime();
    let seedIndex = 0;
    
    return staff
      .map(s => ({
        ...s,
        rotationScore: this.calculateLeapfrogScore(s, weekendDate),
        randomFactor: ((randomSeed + seedIndex++ * 1234) % 1000) / 200 // Controlled variation
      }))
      .sort((a, b) => {
        // First priority: avoid consecutive weekends
        const aConsecutive = a.consecutiveWeekends || 0;
        const bConsecutive = b.consecutiveWeekends || 0;
        if (aConsecutive !== bConsecutive) {
          return aConsecutive - bConsecutive;
        }
        // Second priority: rotation score (with random variation)
        const aTotal = a.rotationScore + a.randomFactor;
        const bTotal = b.rotationScore + b.randomFactor;
        return aTotal - bTotal;
      });
  }

  /**
   * Calculate leapfrog rotation score for staff assignment
   */
  private calculateLeapfrogScore(staff: any, weekendDate: Date): number {
    let score = 0;

    // Base score on current workload (lower workload = lower score = higher priority)
    score += staff.weekendsAssigned * 10;
    
    // Heavy penalty for consecutive weekends (promotes leapfrog pattern)
    if (staff.consecutiveWeekends >= 1) {
      score += staff.consecutiveWeekends * 50;
    }
    
    // Bonus for staff who haven't worked recently (encourages rotation)
    if (staff.lastWeekendWorked) {
      const daysSinceLastWork = Math.floor((weekendDate.getTime() - staff.lastWeekendWorked.getTime()) / (1000 * 60 * 60 * 24));
      if (daysSinceLastWork >= 14) {
        score -= 20; // Lower score = higher priority for those who haven't worked in 2+ weeks
      }
      if (daysSinceLastWork >= 7) {
        score -= 10; // Bonus for 1+ week gap
      }
    } else {
      score -= 15; // High priority for staff who haven't worked yet
    }

    return score;
  }

  /**
   * Calculate fairness score for staff assignment (legacy method)
   */
  private calculateFairnessScore(staff: any, weekendDate: Date): number {
    let score = 0;

    // Base score on current workload (lower workload = lower score = higher priority)
    score += staff.weekendsAssigned * 10;

    // Bonus for having time off recently
    if (staff.lastWeekendWorked) {
      const daysSinceLastShift = Math.floor(
        (weekendDate.getTime() - staff.lastWeekendWorked.getTime()) / (1000 * 60 * 60 * 24)
      );
      
      if (daysSinceLastShift > 14) {
        score -= 15; // Bonus for having time off
      }
    }

    return score;
  }

  /**
   * Assign Christmas period coverage ensuring 1 staff member on duty
   */
  private assignChristmasCoverage(
    staffWorkload: any[], 
    christmasWeekends: Date[], 
    params: RotaParameters, 
    shiftHours: number
  ): WeekendShift[] {
    const christmasRota: WeekendShift[] = [];
    
    // Rotate through staff for Christmas coverage
    christmasWeekends.forEach((date, index) => {
      const staffIndex = index % staffWorkload.length;
      const staff = staffWorkload[staffIndex];
      
      christmasRota.push({
        date,
        staffId: staff.staffId,
        staffName: staff.name,
        startTime: params.weekendStartTime,
        endTime: params.weekendEndTime,
        hoursWorked: shiftHours
      });

      // Update workload
      staff.weekendsAssigned++;
      staff.hoursWorked += shiftHours;
    });

    return christmasRota;
  }

  /**
   * Generate all weekend dates for a year (both Saturday and Sunday)
   */
  private generateWeekendDates(year: number): Date[] {
    const weekends: Date[] = [];
    const start = new Date(year, 0, 1);
    const end = new Date(year, 11, 31);

    // Find first Saturday of the year
    let currentDate = new Date(start);
    while (currentDate.getDay() !== 6) {
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Generate Saturday-Sunday pairs for the entire year
    while (currentDate <= end) {
      // Add Saturday
      weekends.push(new Date(currentDate));
      
      // Add Sunday (next day)
      const sunday = new Date(currentDate);
      sunday.setDate(sunday.getDate() + 1);
      weekends.push(sunday);
      
      // Move to next Saturday (add 7 days to current Saturday)
      currentDate.setDate(currentDate.getDate() + 7);
    }

    return weekends;
  }

  /**
   * Calculate shift hours from time strings
   */
  private calculateShiftHours(startTime: string, endTime: string): number {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    
    return (endMinutes - startMinutes) / 60;
  }

  /**
   * Check if two dates are consecutive weekends
   */
  private isConsecutiveWeekend(lastDate: Date, currentDate: Date): boolean {
    const daysDiff = Math.floor(
      (currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    return daysDiff <= 7;
  }

  /**
   * Save generated rota to database
   */
  async saveRotaToDatabase(rota: WeekendShift[]): Promise<boolean> {
    try {
      for (const shift of rota) {
        await storage.createStaffRotaEntry({
          staffId: shift.staffId,
          staffName: shift.staffName,
          date: shift.date,
          shiftType: this.getShiftType(shift.date),
          startTime: shift.startTime,
          endTime: shift.endTime,
          hoursWorked: shift.hoursWorked,
          status: 'Scheduled'
        });
      }

      return true;
    } catch (error) {
      console.error('Failed to save rota to database:', error);
      return false;
    }
  }

  /**
   * Clear all rota entries from database
   */
  async clearRotaFromDatabase(): Promise<boolean> {
    try {
      await storage.clearAllStaffRotaEntries();
      return true;
    } catch (error) {
      console.error('Failed to clear rota from database:', error);
      return false;
    }
  }

  /**
   * Determine shift type based on date
   */
  private getShiftType(date: Date): string {
    const month = date.getMonth();
    const day = date.getDate();
    
    // Christmas period (December)
    if (month === 11 && day >= 20 && day <= 31) {
      return 'Christmas';
    }
    
    // New Year period (January 1-3)
    if (month === 0 && day <= 3) {
      return 'New Year';
    }
    
    return 'Weekend';
  }
}

export const staffRotaAI = new StaffRotaAI();