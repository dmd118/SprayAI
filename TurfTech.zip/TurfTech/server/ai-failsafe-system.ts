// Comprehensive failsafe system for AI assistant data access
import { storage } from './storage';

interface SystemHealth {
  database: boolean;
  weather: boolean;
  products: boolean;
  areas: boolean;
  news: boolean;
  timestamp: number;
}

interface BackupData {
  products: any[];
  areas: any[];
  news: any[];
  applicationRecords: any[];
  lastUpdate: number;
}

class AIFailsafeSystem {
  private backupData: BackupData = {
    products: [],
    areas: [],
    news: [],
    applicationRecords: [],
    lastUpdate: 0
  };
  
  private systemHealth: SystemHealth = {
    database: true,
    weather: true,
    products: true,
    areas: true,
    news: true,
    timestamp: Date.now()
  };

  // Create backup data every 5 minutes
  async createBackup(): Promise<void> {
    try {
      console.log('[AI-Failsafe] Creating data backup...');
      
      const [products, areas, news, records] = await Promise.allSettled([
        storage.getSprayProducts(),
        storage.getTurfAreas(),
        storage.getIndustryNews(),
        storage.getApplicationRecords()
      ]);

      this.backupData = {
        products: products.status === 'fulfilled' ? products.value : this.backupData.products,
        areas: areas.status === 'fulfilled' ? areas.value : this.backupData.areas,
        news: news.status === 'fulfilled' ? news.value : this.backupData.news,
        applicationRecords: records.status === 'fulfilled' ? records.value : this.backupData.applicationRecords,
        lastUpdate: Date.now()
      };

      console.log(`[AI-Failsafe] Backup created: ${this.backupData.products.length} products, ${this.backupData.areas.length} areas`);
    } catch (error) {
      console.error('[AI-Failsafe] Backup creation failed:', error);
    }
  }

  // Get data with automatic fallback to backup
  async getReliableData(): Promise<{
    products: any[];
    areas: any[];
    news: any[];
    applicationRecords: any[];
    weatherResponse: any;
    health: SystemHealth;
  }> {
    let products = [], areas = [], news = [], applicationRecords = [], weatherResponse = null;

    // Test all systems and use backup if needed
    try {
      const dataPromises = await Promise.allSettled([
        storage.getSprayProducts(),
        storage.getTurfAreas(),
        storage.getIndustryNews(),
        storage.getApplicationRecords(),
        fetch('http://localhost:5000/api/weather').then(res => res.json()).catch(() => null)
      ]);

      products = dataPromises[0].status === 'fulfilled' ? dataPromises[0].value : this.backupData.products;
      areas = dataPromises[1].status === 'fulfilled' ? dataPromises[1].value : this.backupData.areas;
      news = dataPromises[2].status === 'fulfilled' ? dataPromises[2].value : this.backupData.news;
      applicationRecords = dataPromises[3].status === 'fulfilled' ? dataPromises[3].value : this.backupData.applicationRecords;
      weatherResponse = dataPromises[4].status === 'fulfilled' ? dataPromises[4].value : null;

      // Update system health
      this.systemHealth = {
        database: dataPromises[0].status === 'fulfilled',
        weather: dataPromises[4].status === 'fulfilled',
        products: dataPromises[0].status === 'fulfilled',
        areas: dataPromises[1].status === 'fulfilled',
        news: dataPromises[2].status === 'fulfilled',
        timestamp: Date.now()
      };

    } catch (error) {
      console.error('[AI-Failsafe] Data fetch failed, using backup:', error);
      products = this.backupData.products;
      areas = this.backupData.areas;
      news = this.backupData.news;
      applicationRecords = this.backupData.applicationRecords;
    }

    return {
      products,
      areas,
      news,
      applicationRecords,
      weatherResponse,
      health: this.systemHealth
    };
  }

  // Start continuous monitoring and backup system
  startMonitoring(): void {
    console.log('[AI-Failsafe] Starting continuous monitoring system...');
    
    // Create initial backup
    this.createBackup();
    
    // Create backup every 30 minutes to reduce system load
    setInterval(() => {
      this.createBackup();
    }, 30 * 60 * 1000);

    // Health check every 10 minutes to reduce server stress
    setInterval(() => {
      this.checkSystemHealth();
    }, 10 * 60 * 1000);
  }

  private async checkSystemHealth(): Promise<void> {
    try {
      const healthCheck = await Promise.allSettled([
        storage.getSprayProducts().then(() => true).catch(() => false),
        fetch('http://localhost:5000/api/weather').then(() => true).catch(() => false)
      ]);

      const newHealth = {
        database: healthCheck[0].status === 'fulfilled' && healthCheck[0].value,
        weather: healthCheck[1].status === 'fulfilled' && healthCheck[1].value,
        products: healthCheck[0].status === 'fulfilled' && healthCheck[0].value,
        areas: healthCheck[0].status === 'fulfilled' && healthCheck[0].value,
        news: healthCheck[0].status === 'fulfilled' && healthCheck[0].value,
        timestamp: Date.now()
      };

      // Only log significant system changes to reduce noise
      const hasSignificantChange = Object.keys(newHealth).some(key => {
        if (key === 'timestamp') return false;
        return newHealth[key as keyof typeof newHealth] !== this.systemHealth[key as keyof typeof this.systemHealth];
      });
      
      if (hasSignificantChange) {
        console.log('[AI-Failsafe] System health changed:', newHealth);
      }

      this.systemHealth = newHealth;
    } catch (error) {
      console.error('[AI-Failsafe] Health check failed:', error);
    }
  }

  getSystemStatus(): string {
    const upSystems = Object.values(this.systemHealth).filter(v => v === true).length - 1; // -1 for timestamp
    return `AI Assistant Status: ALWAYS AVAILABLE (${upSystems}/5 systems active, backup protection enabled)`;
  }
}

export const aiFailsafeSystem = new AIFailsafeSystem();