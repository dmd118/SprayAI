import { db } from "./db";
import { staffMembers, savedRotas, rotaShifts, holidayBookings } from "@shared/schema";
import { eq, and, gte, lte } from "drizzle-orm";

interface RotaGenerationParams {
  startDate: Date;
  endDate: Date;
  rotaName: string;
  notes?: string;
}

interface StaffAvailability {
  id: number;
  name: string;
  staffType: 'F' | 'S'; // F = full-time, S = seasonal
  holidayDaysAccrued: number;
  holidayDaysTaken: number;
  weekendShiftsWorked: number;
  lastWeekendWorked: Date | null;
  consecutiveWeekends: number;
  isActive: boolean;
  bookedHolidays: { startDate: Date; endDate: Date; daysBooked: number }[];
}

interface GeneratedShift {
  staffId: number;
  staffName: string;
  date: Date;
  dayOfWeek: string;
  shiftType: 'weekday' | 'weekend' | 'holiday' | 'monday_off';
  startTime: string | null;
  endTime: string | null;
  hoursWorked: number;
  isHoliday: boolean;
  isMondayOff: boolean;
  notes?: string;
}

export class RotaGenerator {
  private scottishBankHolidays2025 = [
    new Date(2025, 0, 1),  // New Year's Day
    new Date(2025, 0, 2),  // 2nd January
    new Date(2025, 3, 18), // Good Friday
    new Date(2025, 3, 21), // Easter Monday
    new Date(2025, 4, 5),  // Early May Bank Holiday
    new Date(2025, 4, 26), // Spring Bank Holiday
    new Date(2025, 7, 4),  // Summer Bank Holiday
    new Date(2025, 10, 30), // St. Andrew's Day
    new Date(2025, 11, 25), // Christmas Day
    new Date(2025, 11, 26), // Boxing Day
  ];

  private christmasPeriod = {
    start: new Date(2025, 11, 23), // Dec 23rd
    end: new Date(2026, 0, 5)      // Jan 5th
  };

  /**
   * Generate a complete rota following all Scottish employment rules
   */
  async generateRota(params: RotaGenerationParams): Promise<{ rotaId: number; shifts: GeneratedShift[] }> {
    console.log(`\n🔄 Generating rota: ${params.rotaName}`);
    console.log(`📅 Period: ${params.startDate.toDateString()} to ${params.endDate.toDateString()}`);

    // Get all staff and their availability
    const staff = await this.loadStaffAvailability(params.startDate, params.endDate);
    console.log(`👥 Loaded ${staff.length} staff members (${staff.filter(s => s.staffType === 'F').length}F + ${staff.filter(s => s.staffType === 'S').length}S)`);

    // Initialize the 11 staff members as per your specification
    await this.ensureStaffSetup();

    // Generate all shifts for the period
    const shifts = this.generateAllShifts(staff, params.startDate, params.endDate);
    console.log(`📋 Generated ${shifts.length} total shifts`);

    // Save rota to database
    const rotaId = await this.saveRotaToDatabase(params, shifts);
    console.log(`💾 Saved rota with ID: ${rotaId}`);

    return { rotaId, shifts };
  }

  /**
   * Ensure we have the correct 11 staff members set up with privacy format
   */
  private async ensureStaffSetup(): Promise<void> {
    const requiredStaff = [
      { name: '1F', staffType: 'F' }, { name: '2F', staffType: 'F' }, { name: '3F', staffType: 'F' },
      { name: '4F', staffType: 'F' }, { name: '5F', staffType: 'F' }, { name: '6F', staffType: 'F' },
      { name: '7S', staffType: 'S' }, { name: '8S', staffType: 'S' }, { name: '9S', staffType: 'S' },
      { name: '10S', staffType: 'S' }, { name: '11S', staffType: 'S' }
    ];

    for (const staff of requiredStaff) {
      const existing = await db.select()
        .from(staffMembers)
        .where(eq(staffMembers.name, staff.name))
        .limit(1);

      if (existing.length === 0) {
        await db.insert(staffMembers).values({
          name: staff.name,
          staffType: staff.staffType as 'F' | 'S',
          startDate: new Date(2025, 0, 1),
          holidayDaysAccrued: 30, // Standard starting allowance
          holidayDaysTaken: 0,
          isActive: true
        });
        console.log(`✅ Created staff member: ${staff.name}`);
      }
    }
  }

  /**
   * Load all staff with their current availability and holiday bookings
   */
  private async loadStaffAvailability(startDate: Date, endDate: Date): Promise<StaffAvailability[]> {
    const staffData = await db.select().from(staffMembers).where(eq(staffMembers.isActive, true));
    
    const staffWithHolidays: StaffAvailability[] = [];

    for (const staff of staffData) {
      const holidays = await db.select()
        .from(holidayBookings)
        .where(
          and(
            eq(holidayBookings.staffId, staff.id),
            eq(holidayBookings.status, 'approved'),
            gte(holidayBookings.endDate, startDate),
            lte(holidayBookings.startDate, endDate)
          )
        );

      staffWithHolidays.push({
        id: staff.id,
        name: staff.name,
        staffType: staff.staffType as 'F' | 'S',
        holidayDaysAccrued: staff.holidayDaysAccrued,
        holidayDaysTaken: staff.holidayDaysTaken,
        weekendShiftsWorked: staff.weekendShiftsWorked,
        lastWeekendWorked: staff.lastWeekendWorked,
        consecutiveWeekends: staff.consecutiveWeekends,
        isActive: staff.isActive,
        bookedHolidays: holidays.map(h => ({
          startDate: h.startDate,
          endDate: h.endDate,
          daysBooked: h.daysBooked
        }))
      });
    }

    return staffWithHolidays;
  }

  /**
   * Generate all shifts for the entire period
   */
  private generateAllShifts(staff: StaffAvailability[], startDate: Date, endDate: Date): GeneratedShift[] {
    const shifts: GeneratedShift[] = [];
    const current = new Date(startDate);
    
    let weekendWorkers: number[] = []; // Track who worked last weekend
    
    while (current <= endDate) {
      const dayOfWeek = this.getDayName(current);
      const isWeekend = dayOfWeek === 'Saturday' || dayOfWeek === 'Sunday';
      const isBankHoliday = this.isBankHoliday(current);
      const isChristmas = this.isChristmasWeek(current);
      const isSummer = this.isSummerPeriod(current);

      if (isWeekend) {
        // Weekend shifts: Apply your specific rules
        const weekendShifts = this.generateWeekendShifts(staff, current, dayOfWeek, weekendWorkers, isSummer, isChristmas);
        shifts.push(...weekendShifts);
        
        // Update weekend workers tracking
        if (dayOfWeek === 'Sunday') {
          weekendWorkers = weekendShifts.map(s => s.staffId);
        }
      } else {
        // Weekday shifts
        const weekdayShifts = this.generateWeekdayShifts(staff, current, dayOfWeek, isBankHoliday, weekendWorkers);
        shifts.push(...weekdayShifts);
      }

      // Move to next day
      current.setDate(current.getDate() + 1);
    }

    return shifts;
  }

  /**
   * Generate weekend shifts following your specific rules
   */
  private generateWeekendShifts(
    staff: StaffAvailability[], 
    date: Date, 
    dayOfWeek: string,
    lastWeekendWorkers: number[],
    isSummer: boolean,
    isChristmas: boolean
  ): GeneratedShift[] {
    const shifts: GeneratedShift[] = [];
    
    // Apply your rules: Summer=4 (2F+2S), Winter=2, Christmas=1
    let requiredStaff: number;
    if (isChristmas) {
      requiredStaff = 1;
    } else if (isSummer) {
      requiredStaff = 4; // Must be 2F + 2S
    } else {
      requiredStaff = 2; // Winter: 2F only
    }

    // Select staff avoiding consecutive weekends
    const availableStaff = staff.filter(s => {
      const isOnHoliday = this.isStaffOnHoliday(s, date);
      const workedLastWeekend = lastWeekendWorkers.includes(s.id);
      const isSeasonalInWinter = s.staffType === 'S' && !isSummer;
      
      return !isOnHoliday && !workedLastWeekend && !isSeasonalInWinter;
    });

    let selectedStaff: StaffAvailability[] = [];

    if (isSummer && requiredStaff === 4) {
      // Summer: Exactly 2F + 2S
      const fullTime = availableStaff.filter(s => s.staffType === 'F').slice(0, 2);
      const seasonal = availableStaff.filter(s => s.staffType === 'S').slice(0, 2);
      selectedStaff = [...fullTime, ...seasonal];
    } else {
      // Winter/Christmas: Full-time only
      selectedStaff = availableStaff.filter(s => s.staffType === 'F').slice(0, requiredStaff);
    }

    // Create weekend shifts (same staff work both Saturday and Sunday)
    for (const staffMember of selectedStaff) {
      shifts.push({
        staffId: staffMember.id,
        staffName: staffMember.name,
        date: new Date(date),
        dayOfWeek,
        shiftType: 'weekend',
        startTime: '05:00', // Your specified weekend hours
        endTime: '09:00',
        hoursWorked: 4,
        isHoliday: false,
        isMondayOff: false,
        notes: `Weekend shift - ${isSummer ? 'Summer' : 'Winter'} period`
      });
    }

    return shifts;
  }

  /**
   * Generate weekday shifts with Monday offs after weekend work
   */
  private generateWeekdayShifts(
    staff: StaffAvailability[],
    date: Date,
    dayOfWeek: string,
    isBankHoliday: boolean,
    weekendWorkers: number[]
  ): GeneratedShift[] {
    const shifts: GeneratedShift[] = [];
    const isSummer = this.isSummerPeriod(date);

    // Monday offs for weekend workers
    if (dayOfWeek === 'Monday') {
      for (const staffId of weekendWorkers) {
        const staffMember = staff.find(s => s.id === staffId);
        if (staffMember) {
          shifts.push({
            staffId: staffMember.id,
            staffName: staffMember.name,
            date: new Date(date),
            dayOfWeek,
            shiftType: 'monday_off',
            startTime: null,
            endTime: null,
            hoursWorked: 0,
            isHoliday: false,
            isMondayOff: true,
            notes: 'Monday off after weekend work'
          });
        }
      }
    }

    // Regular weekday shifts for available staff
    for (const staffMember of staff) {
      const isOnHoliday = this.isStaffOnHoliday(staffMember, date);
      const hasMonday = weekendWorkers.includes(staffMember.id) && dayOfWeek === 'Monday';
      const isSeasonalInWinter = staffMember.staffType === 'S' && !isSummer;
      const isSeasonalFridayAfternoon = staffMember.staffType === 'S' && dayOfWeek === 'Friday';

      if (!isOnHoliday && !hasMonday && !isSeasonalInWinter) {
        let endTime = '17:00';
        let hoursWorked = 8;
        
        // Seasonal staff finish at 09:30 on Fridays
        if (isSeasonalFridayAfternoon) {
          endTime = '09:30';
          hoursWorked = 1.5;
        }

        shifts.push({
          staffId: staffMember.id,
          staffName: staffMember.name,
          date: new Date(date),
          dayOfWeek,
          shiftType: isBankHoliday ? 'holiday' : 'weekday',
          startTime: '08:00',
          endTime,
          hoursWorked,
          isHoliday: isBankHoliday,
          isMondayOff: false,
          notes: isSeasonalFridayAfternoon ? 'Early finish (S staff)' : undefined
        });
      }
    }

    return shifts;
  }

  /**
   * Save the generated rota to the database
   */
  private async saveRotaToDatabase(params: RotaGenerationParams, shifts: GeneratedShift[]): Promise<number> {
    // Create the main rota record
    const [rota] = await db.insert(savedRotas).values({
      name: params.rotaName,
      startDate: params.startDate,
      endDate: params.endDate,
      notes: params.notes,
      status: 'active'
    }).returning();

    // Insert all shifts
    const shiftRecords = shifts.map(shift => ({
      rotaId: rota.id,
      staffId: shift.staffId,
      staffName: shift.staffName,
      date: shift.date,
      dayOfWeek: shift.dayOfWeek || this.getDayName(shift.date), // Ensure dayOfWeek is never null
      shiftType: shift.shiftType,
      startTime: shift.startTime,
      endTime: shift.endTime,
      hoursWorked: shift.hoursWorked,
      isHoliday: shift.isHoliday,
      isMonday: shift.isMondayOff,
      notes: shift.notes
    }));

    await db.insert(rotaShifts).values(shiftRecords);

    console.log(`💾 Saved rota "${params.rotaName}" with ${shifts.length} shifts`);
    return rota.id;
  }

  // Helper methods
  private getDayName(date: Date): string {
    return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][date.getDay()];
  }

  private isSummerPeriod(date: Date): boolean {
    const month = date.getMonth();
    return month >= 2 && month <= 8; // March to September
  }

  private isChristmasWeek(date: Date): boolean {
    return date >= this.christmasPeriod.start && date <= this.christmasPeriod.end;
  }

  private isBankHoliday(date: Date): boolean {
    return this.scottishBankHolidays2025.some(holiday => 
      holiday.toDateString() === date.toDateString()
    );
  }

  private isStaffOnHoliday(staff: StaffAvailability, date: Date): boolean {
    return staff.bookedHolidays.some(holiday => 
      date >= holiday.startDate && date <= holiday.endDate
    );
  }
}

export const rotaGenerator = new RotaGenerator();