// Seed realistic golf course staff data
import { Pool } from '@neondatabase/serverless';

async function seedStaffData() {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  
  // Golf course staff - 11 total (7 work winter season)
  const staffMembers = [
    // Year-round core staff (5 FE experienced + 2 additional winter staff)
    { name: "1 FE", position: "Head Greenkeeper", isActive: true, winterStaff: true, startDate: "2020-03-15", contactInfo: "1fe@dullatur.com" },
    { name: "2 FE", position: "Deputy Head Greenkeeper", isActive: true, winterStaff: true, startDate: "2021-05-10", contactInfo: "2fe@dullatur.com" },
    { name: "3 FE", position: "Senior Greenkeeper", isActive: true, winterStaff: true, startDate: "2019-08-20", contactInfo: "3fe@dullatur.com" },
    { name: "4 FE", position: "Greenkeeper", isActive: true, winterStaff: true, startDate: "2022-02-12", contactInfo: "4fe@dullatur.com" },
    { name: "5 FE", position: "Greenkeeper", isActive: true, winterStaff: true, startDate: "2021-09-05", contactInfo: "5fe@dullatur.com" },
    { name: "6 F", position: "Mechanic/Greenkeeper", isActive: true, winterStaff: true, startDate: "2020-11-30", contactInfo: "6f@dullatur.com" },
    { name: "7 F", position: "Groundsman", isActive: true, winterStaff: true, startDate: "2023-01-18", contactInfo: "7f@dullatur.com" },
    
    // Seasonal staff (4 - April to September only)
    { name: "8 S", position: "Seasonal Greenkeeper", isActive: true, winterStaff: false, startDate: "2024-04-01", contactInfo: "8s@dullatur.com" },
    { name: "9 S", position: "Seasonal Greenkeeper", isActive: true, winterStaff: false, startDate: "2024-04-01", contactInfo: "9s@dullatur.com" },
    { name: "10 S", position: "Assistant Greenkeeper", isActive: true, winterStaff: false, startDate: "2024-04-15", contactInfo: "10s@dullatur.com" },
    { name: "11 S", position: "Seasonal Groundsman", isActive: true, winterStaff: false, startDate: "2024-04-01", contactInfo: "11s@dullatur.com" }
  ];

  try {
    console.log('Seeding staff members...');
    
    for (let i = 0; i < staffMembers.length; i++) {
      const staff = staffMembers[i];
      
      await pool.query(`
        INSERT INTO staff_members (
          name, 
          position, 
          is_active, 
          winter_staff, 
          start_date, 
          contact_info,
          annual_leave_days,
          skills_certifications
        ) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (name) DO NOTHING
      `, [
        staff.name,
        staff.position,
        staff.isActive,
        staff.winterStaff,
        staff.startDate,
        staff.contactInfo,
        25, // Standard UK annual leave
        staff.position.includes('Head') ? ['Management', 'Spray Certification', 'Health & Safety'] :
        staff.position.includes('Mechanic') ? ['Equipment Maintenance', 'Spray Certification'] :
        staff.position.includes('Senior') ? ['Spray Certification', 'Course Management'] :
        ['Basic Greenkeeping']
      ]);
      
      console.log(`✓ Added ${staff.name} - ${staff.position}`);
    }

    // Create initial rota configuration
    await pool.query(`
      INSERT INTO rota_config (
        weekend_start_time,
        weekend_end_time,
        christmas_start_date,
        christmas_end_date,
        minimum_staff_on_duty,
        annual_hours_target,
        created_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, NOW())
      ON CONFLICT DO NOTHING
    `, [
      '08:00',
      '16:00', 
      '2024-12-20',
      '2025-01-03',
      1,
      2080
    ]);

    console.log('✅ Staff data seeded successfully!');
    console.log(`📊 Total staff: ${staffMembers.length}`);
    console.log(`❄️  Winter staff: ${staffMembers.filter(s => s.winterStaff).length}`);
    console.log(`🌞 Summer additional: ${staffMembers.filter(s => !s.winterStaff).length}`);
    
  } catch (error) {
    console.error('❌ Error seeding staff data:', error);
  } finally {
    await pool.end();
  }
}

seedStaffData();