// Disease Pressure Forecasting System
interface DiseaseConditions {
  name: string;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  confidence: number;
  peakRiskHours: number;
  description: string;
  preventativeTreatments: string[];
  optimalApplicationWindow: string;
}

interface DiseaseRiskAssessment {
  timestamp: number;
  overallRisk: 'Low' | 'Medium' | 'High' | 'Critical';
  diseases: DiseaseConditions[];
  recommendations: string[];
  nextAssessment: number;
}

export class DiseasePressureForecaster {
  
  public assessDiseaseRisk(weatherData: any): DiseaseRiskAssessment {
    const current = weatherData.weather;
    const forecast = weatherData.forecast || [];
    
    const diseases: DiseaseConditions[] = [
      this.assessAnthracnose(current, forecast),
      this.assessDollarSpot(current, forecast),
      this.assessFusarium(current, forecast),
      this.assessPythium(current, forecast),
      this.assessRedThread(current, forecast),
      this.assessBrownPatch(current, forecast),
      this.assessSnowMould(current, forecast)
    ].filter(disease => disease.riskLevel !== 'Low');

    const overallRisk = this.calculateOverallRisk(diseases);
    const recommendations = this.generateRecommendations(diseases, current);

    return {
      timestamp: Date.now(),
      overallRisk,
      diseases,
      recommendations,
      nextAssessment: Date.now() + (6 * 60 * 60 * 1000) // 6 hours
    };
  }

  private assessAnthracnose(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    const rainfall = this.calculateRainfall(forecast, 48);
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Anthracnose thrives in hot, humid conditions (25-30°C, >85% humidity)
    if (temp >= 25 && temp <= 30 && humidity >= 85) {
      riskLevel = 'High';
      confidence = 0.85;
      peakRiskHours = 48;
    } else if (temp >= 22 && temp <= 32 && humidity >= 75) {
      riskLevel = 'Medium';
      confidence = 0.65;
      peakRiskHours = 72;
    } else if (temp >= 20 && humidity >= 70) {
      riskLevel = 'Low';
      confidence = 0.45;
    }

    // Increase risk with recent rainfall
    if (rainfall > 5) {
      riskLevel = this.elevateRisk(riskLevel);
      confidence += 0.1;
    }

    return {
      name: 'Anthracnose',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' : 
        `Favorable conditions for anthracnose development. Warm temperatures (${temp}°C) and high humidity (${humidity}%) create ideal infection environment.`,
      preventativeTreatments: [
        'Propiconazole-based fungicide',
        'Chlorothalonil',
        'Azoxystrobin',
        'Improve air circulation',
        'Reduce irrigation frequency'
      ],
      optimalApplicationWindow: 'Early morning before dew formation or evening after 6 PM'
    };
  }

  private assessDollarSpot(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    const dewPoint = this.calculateDewPoint(temp, humidity);
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Dollar spot favors 16-27°C with prolonged leaf wetness
    if (temp >= 16 && temp <= 27 && humidity >= 80 && dewPoint > 12) {
      riskLevel = 'High';
      confidence = 0.82;
      peakRiskHours = 36;
    } else if (temp >= 14 && temp <= 29 && humidity >= 70) {
      riskLevel = 'Medium';
      confidence = 0.62;
      peakRiskHours = 48;
    }

    // Check for prolonged leaf wetness conditions
    const prolongedWetness = this.checkProlongedWetness(forecast);
    if (prolongedWetness) {
      riskLevel = this.elevateRisk(riskLevel);
      confidence += 0.15;
    }

    return {
      name: 'Dollar Spot',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' :
        `Moderate temperatures (${temp}°C) with extended leaf wetness periods create prime dollar spot conditions.`,
      preventativeTreatments: [
        'Propiconazole',
        'Tebuconazole',
        'Proper nitrogen management',
        'Morning irrigation to reduce leaf wetness',
        'Improve soil drainage'
      ],
      optimalApplicationWindow: 'Late evening after 7 PM when dew begins to form'
    };
  }

  private assessFusarium(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Fusarium patch active in cooler conditions 10-20°C
    if (temp >= 10 && temp <= 20 && humidity >= 85) {
      riskLevel = 'High';
      confidence = 0.78;
      peakRiskHours = 72;
    } else if (temp >= 8 && temp <= 22 && humidity >= 75) {
      riskLevel = 'Medium';
      confidence = 0.58;
      peakRiskHours = 96;
    }

    return {
      name: 'Fusarium Patch',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' :
        `Cool, wet conditions (${temp}°C, ${humidity}% humidity) favor fusarium patch development.`,
      preventativeTreatments: [
        'Iprodione',
        'Fludioxonil',
        'Reduce thatch buildup',
        'Improve drainage',
        'Avoid excessive nitrogen in autumn'
      ],
      optimalApplicationWindow: 'Early morning or late evening during calm conditions'
    };
  }

  private assessPythium(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    const rainfall = this.calculateRainfall(forecast, 24);
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Pythium thrives in very wet, warm conditions >25°C
    if (temp >= 25 && humidity >= 90 && rainfall > 3) {
      riskLevel = 'Critical';
      confidence = 0.88;
      peakRiskHours = 24;
    } else if (temp >= 20 && humidity >= 85 && rainfall > 1) {
      riskLevel = 'High';
      confidence = 0.72;
      peakRiskHours = 36;
    } else if (temp >= 18 && humidity >= 80) {
      riskLevel = 'Medium';
      confidence = 0.52;
      peakRiskHours = 48;
    }

    return {
      name: 'Pythium Blight',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' :
        `Extremely wet conditions with warm temperatures (${temp}°C) create critical pythium risk.`,
      preventativeTreatments: [
        'Metalaxyl',
        'Propamocarb',
        'Fosetyl-aluminium',
        'Improve drainage immediately',
        'Reduce irrigation',
        'Increase air circulation'
      ],
      optimalApplicationWindow: 'Immediate application recommended during dry periods'
    };
  }

  private assessRedThread(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Red thread common in UK conditions 15-24°C, high humidity
    if (temp >= 15 && temp <= 24 && humidity >= 85) {
      riskLevel = 'High';
      confidence = 0.75;
      peakRiskHours = 48;
    } else if (temp >= 12 && temp <= 26 && humidity >= 75) {
      riskLevel = 'Medium';
      confidence = 0.55;
      peakRiskHours = 72;
    }

    return {
      name: 'Red Thread',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' :
        `Typical UK conditions (${temp}°C, ${humidity}% humidity) favor red thread development.`,
      preventativeTreatments: [
        'Chlorothalonil',
        'Iprodione',
        'Balanced fertilization',
        'Improve nitrogen availability',
        'Reduce leaf wetness periods'
      ],
      optimalApplicationWindow: 'Early morning before 9 AM or evening after 6 PM'
    };
  }

  private assessBrownPatch(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Brown patch loves hot, humid nights >20°C nighttime
    if (temp >= 20 && humidity >= 85) {
      riskLevel = 'High';
      confidence = 0.80;
      peakRiskHours = 48;
    } else if (temp >= 18 && humidity >= 75) {
      riskLevel = 'Medium';
      confidence = 0.60;
      peakRiskHours = 72;
    }

    return {
      name: 'Brown Patch',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' :
        `Warm nights (${temp}°C) with high humidity (${humidity}%) create brown patch conditions.`,
      preventativeTreatments: [
        'Propiconazole',
        'Azoxystrobin',
        'Reduce nitrogen fertilization',
        'Improve air circulation',
        'Water early morning only'
      ],
      optimalApplicationWindow: 'Late evening application for overnight protection'
    };
  }

  private assessSnowMould(current: any, forecast: any[]): DiseaseConditions {
    const temp = current.temperature;
    const humidity = current.humidity;
    
    let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    let confidence = 0;
    let peakRiskHours = 0;

    // Snow mould risk increases in late autumn/winter conditions
    if (temp >= 0 && temp <= 10 && humidity >= 90) {
      riskLevel = 'High';
      confidence = 0.70;
      peakRiskHours = 168; // 7 days
    } else if (temp >= -2 && temp <= 12 && humidity >= 80) {
      riskLevel = 'Medium';
      confidence = 0.50;
      peakRiskHours = 240; // 10 days
    }

    return {
      name: 'Snow Mould',
      riskLevel,
      confidence: Math.min(confidence, 0.95),
      peakRiskHours,
      description: riskLevel === 'Low' ? '' :
        `Cold, wet conditions (${temp}°C) with extended coverage periods favor snow mould.`,
      preventativeTreatments: [
        'Iprodione (autumn application)',
        'Chlorothalonil',
        'Ensure good drainage',
        'Avoid late nitrogen fertilization',
        'Remove leaf debris'
      ],
      optimalApplicationWindow: 'Late autumn before first frost or snow'
    };
  }

  private calculateRainfall(forecast: any[], hours: number): number {
    if (!forecast || !forecast.length) return 0;
    
    const cutoff = Date.now() + (hours * 60 * 60 * 1000);
    return forecast
      .filter(f => new Date(f.time).getTime() <= cutoff)
      .reduce((total, f) => total + (f.precipitation || 0), 0);
  }

  private calculateDewPoint(temp: number, humidity: number): number {
    // Simplified dew point calculation
    const a = 17.27;
    const b = 237.7;
    const alpha = ((a * temp) / (b + temp)) + Math.log(humidity / 100);
    return (b * alpha) / (a - alpha);
  }

  private checkProlongedWetness(forecast: any[]): boolean {
    if (!forecast || !forecast.length) return false;
    
    // Check for extended periods of high humidity (>12 hours)
    let consecutiveWetHours = 0;
    for (const period of forecast.slice(0, 24)) {
      if (period.humidity >= 85) {
        consecutiveWetHours++;
        if (consecutiveWetHours >= 12) return true;
      } else {
        consecutiveWetHours = 0;
      }
    }
    return false;
  }

  private elevateRisk(currentRisk: 'Low' | 'Medium' | 'High' | 'Critical'): 'Low' | 'Medium' | 'High' | 'Critical' {
    switch (currentRisk) {
      case 'Low': return 'Medium';
      case 'Medium': return 'High';
      case 'High': return 'Critical';
      case 'Critical': return 'Critical';
    }
  }

  private calculateOverallRisk(diseases: DiseaseConditions[]): 'Low' | 'Medium' | 'High' | 'Critical' {
    if (diseases.some(d => d.riskLevel === 'Critical')) return 'Critical';
    if (diseases.some(d => d.riskLevel === 'High')) return 'High';
    if (diseases.some(d => d.riskLevel === 'Medium')) return 'Medium';
    return 'Low';
  }

  private generateRecommendations(diseases: DiseaseConditions[], current: any): string[] {
    const recommendations: string[] = [];
    
    if (diseases.length === 0) {
      recommendations.push('Current conditions show low disease pressure - maintain normal monitoring schedule');
      return recommendations;
    }

    // Time-sensitive recommendations
    const criticalDiseases = diseases.filter(d => d.riskLevel === 'Critical');
    const highRiskDiseases = diseases.filter(d => d.riskLevel === 'High');

    if (criticalDiseases.length > 0) {
      recommendations.push('🚨 IMMEDIATE ACTION REQUIRED - Critical disease conditions detected');
      recommendations.push('Apply preventative treatments within next 12-24 hours');
    }

    if (highRiskDiseases.length > 0) {
      recommendations.push('🟡 High disease pressure - implement preventative measures within 48 hours');
    }

    // Environmental management
    if (current.humidity >= 85) {
      recommendations.push('Reduce irrigation frequency and improve air circulation to lower humidity');
    }

    if (diseases.some(d => d.name.includes('Pythium') || d.name.includes('Fusarium'))) {
      recommendations.push('Focus on drainage improvements in affected areas');
    }

    // Application timing
    const morningApplications = diseases.filter(d => 
      d.optimalApplicationWindow.includes('morning')
    );
    const eveningApplications = diseases.filter(d => 
      d.optimalApplicationWindow.includes('evening')
    );

    if (morningApplications.length > 0) {
      recommendations.push('Schedule morning applications (6-9 AM) for optimal efficacy');
    }
    if (eveningApplications.length > 0) {
      recommendations.push('Evening applications (6-8 PM) recommended for sustained protection');
    }

    return recommendations;
  }
}

export const diseasePressureForecaster = new DiseasePressureForecaster();