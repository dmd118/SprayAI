interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  description: string;
  condition: string;
  pressure: number;
  precipitation?: number;
  totalRainfall?: number;
  feelsLike?: number;
  visibility?: number;
  dewPoint?: number;
  uvIndex?: number;
  forecast?: ForecastData[];
  forecastDay?: string;
  ukTime?: string;
  currentHour?: number;
  greenkeepingCommentary?: string;
}

interface AnnualWeatherStats {
  totalRainfall2025: number;
  averageTemperature2025: number;
  totalSunshineHours: number;
  totalEvapotranspiration: number;
  monthlyTemperatures: number[];
  monthlyRainfall: number[];
  monthlyDaytimeHighs: number[];
  monthlySoilTemperatures: number[];
}

interface ForecastData {
  time: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  description: string;
}

function generateGreenkeepingCommentary(weather: {
  temperature: number;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  condition: string;
  pressure: number;
  visibility: number;
  totalRainfall: number;
  forecast: any[];
}): string {
  const { temperature, humidity, windSpeed, precipitation, condition, pressure, totalRainfall, forecast } = weather;
  
  let commentary = "";
  const currentTime = new Date();
  const currentHour = currentTime.getHours();
  const dayOfWeek = currentTime.toLocaleDateString('en-GB', { weekday: 'long' });
  
  // Dynamic time-based opening
  if (currentHour < 6) {
    commentary += `Early ${dayOfWeek} morning conditions indicate `;
  } else if (currentHour < 12) {
    commentary += `${dayOfWeek} morning operations show `;
  } else if (currentHour < 15) {
    commentary += `${dayOfWeek} afternoon conditions present `;
  } else {
    commentary += `Late ${dayOfWeek} assessment for tomorrow's planning: `;
  }
  
  // Real-time precipitation analysis
  if (precipitation >= 80) {
    if (totalRainfall < 1) {
      commentary += "high precipitation probability but limited accumulation expected. Brief shower interruptions likely. ";
    } else if (totalRainfall < 3) {
      commentary += "moderate rainfall with intermittent dry spells suitable for covered maintenance work. ";
    } else {
      commentary += "significant rainfall accumulation requiring indoor operations and equipment protection. ";
    }
  } else if (precipitation >= 50) {
    commentary += "scattered shower activity providing natural course irrigation. Plan flexible scheduling. ";
  } else if (precipitation >= 20) {
    commentary += "minimal precipitation risk with excellent working conditions maintained. ";
  } else {
    commentary += "stable dry conditions ideal for all greenkeeping operations. ";
  }
  
  // Temperature-specific daily advice
  if (temperature < 5) {
    commentary += `At ${temperature}°C, frost protection protocols required. Delay start until ground temperature rises. Equipment may require warming. `;
  } else if (temperature < 12) {
    commentary += `Cool ${temperature}°C conditions perfect for intensive maintenance without turf stress. Peak efficiency window. `;
  } else if (temperature < 20) {
    commentary += `Optimal ${temperature}°C temperature range supports all course operations with minimal environmental stress. `;
  } else if (temperature < 25) {
    commentary += `Warm ${temperature}°C conditions require hydration monitoring. Consider early completion of strenuous tasks. `;
  } else {
    commentary += `High ${temperature}°C temperatures demand heat stress protocols. Early morning scheduling essential. `;
  }
  
  // Dynamic wind impact assessment
  if (windSpeed > 25) {
    commentary += `Strong ${windSpeed} km/h winds create hazardous spray conditions. Cancel chemical applications and secure loose equipment. `;
  } else if (windSpeed > 15) {
    commentary += `Moderate ${windSpeed} km/h winds require drift management. Use low-drift nozzles and reduce boom height. `;
  } else if (windSpeed < 5) {
    commentary += `Calm ${windSpeed} km/h conditions provide precision application opportunities. Ideal for sensitive treatments. `;
  } else {
    commentary += `Manageable ${windSpeed} km/h winds allow normal operations with standard drift precautions. `;
  }
  
  // Humidity-based disease pressure
  if (humidity > 85) {
    commentary += `High ${humidity}% humidity elevates fungal disease risk. Increase surveillance for early symptoms. `;
  } else if (humidity < 40) {
    commentary += `Low ${humidity}% humidity may stress turf. Monitor irrigation needs and avoid unnecessary traffic. `;
  } else {
    commentary += `Moderate ${humidity}% humidity supports healthy turf conditions. `;
  }
  
  // Pressure trend analysis
  if (pressure < 1005) {
    commentary += "Falling pressure suggests deteriorating conditions ahead. Complete critical outdoor tasks promptly. ";
  } else if (pressure > 1020) {
    commentary += "High pressure indicates settled weather patterns continuing. Reliable conditions for planning. ";
  }
  
  // Course-specific daily conclusion
  commentary += `Dullatur's parkland setting with these conditions `;
  if (precipitation < 30 && temperature > 8 && temperature < 22 && windSpeed < 15) {
    commentary += "presents premium greenkeeping opportunities. Execute comprehensive maintenance schedule.";
  } else if (precipitation > 70 || windSpeed > 20 || temperature < 5) {
    commentary += "requires adaptation to challenging conditions. Focus on equipment maintenance and planning.";
  } else {
    commentary += "supports standard operations with appropriate weather considerations applied.";
  }
  
  return commentary.trim();
}

export async function getHistoricalWeather(location: string, date: Date): Promise<WeatherData | null> {
  const weatherApiKey = process.env.WEATHERAPI_KEY;
  if (!weatherApiKey) {
    console.log("Weather API key not found");
    return null;
  }

  try {
    // Use Dullatur Golf Club coordinates for accuracy
    const lat = 55.9469;
    const lon = -4.0181;
    
    // Format date as YYYY-MM-DD for WeatherAPI.com historical endpoint
    const dateStr = date.toISOString().split('T')[0];
    const historyUrl = `https://api.weatherapi.com/v1/history.json?key=${weatherApiKey}&q=${lat},${lon}&dt=${dateStr}`;
    
    console.log(`Fetching historical weather for Dullatur Golf Club on ${dateStr}`);
    
    const response = await fetch(historyUrl);
    if (!response.ok) {
      console.error(`Historical weather API failed: ${response.status}`);
      return null;
    }
    
    const data = await response.json();
    
    if (data.forecast && data.forecast.forecastday && data.forecast.forecastday[0]) {
      const dayData = data.forecast.forecastday[0].day;
      const hourData = data.forecast.forecastday[0].hour;
      
      // Get the hour closest to application time (assume 7-10am typical spray window)
      const morningHour = hourData[8] || hourData[7] || hourData[9] || hourData[10] || hourData[0];
      
      return {
        temperature: Math.round(dayData.avgtemp_c),
        humidity: Math.round(dayData.avghumidity),
        windSpeed: Math.round(dayData.maxwind_kph),
        condition: dayData.condition.text,
        description: dayData.condition.text,
        pressure: morningHour?.pressure_mb || 1013,
        precipitation: dayData.totalprecip_mm,
        feelsLike: Math.round(dayData.avgtemp_c),
        visibility: dayData.avgvis_km,
        uvIndex: dayData.uv
      };
    }
    
    return null;
  } catch (error) {
    console.error("Error fetching historical weather:", error);
    return null;
  }
}

export async function getCurrentWeather(location: string = "Cumbernauld, Scotland, GB"): Promise<WeatherData | null> {
  try {
    const weatherApiKey = process.env.WEATHERAPI_KEY;
    if (!weatherApiKey) {
      console.error("WeatherAPI key not found");
      return null;
    }

    // Use Dullatur Golf Club coordinates directly for maximum accuracy
    const lat = 55.9469;
    const lon = -4.0181;

    // Single reliable API call to WeatherAPI.com for all data
    const weatherUrl = `https://api.weatherapi.com/v1/forecast.json?key=${weatherApiKey}&q=${lat},${lon}&days=3&aqi=no&alerts=no`;
    const weatherResponse = await fetch(weatherUrl);
    
    if (!weatherResponse.ok) {
      console.error("Failed to get weather data from WeatherAPI");
      return null;
    }

    const data = await weatherResponse.json();
    const current = data.current;
    
    // Get accurate current UK time
    const now = new Date();
    const ukDateTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/London"}));
    const currentHour = ukDateTime.getHours();
    
    // Smart forecast timing: current day 6am-3pm, then tomorrow 6am-3pm after 3pm
    let targetDateIndex = 0;
    if (currentHour >= 15) {
      targetDateIndex = 1; // Tomorrow's forecast
    }
    
    // Get forecast for target date
    const targetDayForecast = data.forecast?.forecastday?.[targetDateIndex];
    let forecastData: ForecastData[] = [];
    
    if (targetDayForecast?.hour) {
      // Get key greenkeeping hours: 6am, 9am, 12pm, 3pm
      const keyTimes = [6, 9, 12, 15];
      forecastData = keyTimes.map((hourIndex) => {
        const hourData = targetDayForecast.hour[hourIndex];
        if (!hourData) return null;
        
        return {
          time: `${hourIndex.toString().padStart(2, '0')}:00`,
          temperature: Math.round(hourData.temp_c),
          humidity: hourData.humidity,
          windSpeed: Math.round(hourData.wind_kph),
          precipitation: Math.round(hourData.chance_of_rain),
          description: hourData.condition.text.toLowerCase()
        };
      }).filter((item): item is ForecastData => item !== null);
    }

    // Calculate total expected rainfall for the working day
    const totalRainfall = forecastData.reduce((total, hour) => {
      // Use actual precipitation data from API
      const estimatedRainfall = (hour.precipitation / 100) * 2.0; // More conservative estimate
      return total + estimatedRainfall;
    }, 0);

    // Generate professional greenkeeping commentary
    const greenkeepingCommentary = generateGreenkeepingCommentary({
      temperature: Math.round(current.temp_c),
      humidity: current.humidity,
      windSpeed: Math.round(current.wind_kph),
      precipitation: forecastData.length > 0 ? forecastData[0].precipitation : 0,
      condition: current.condition.text,
      pressure: current.pressure_mb,
      visibility: Math.round(current.vis_km),
      totalRainfall,
      forecast: forecastData
    });

    return {
      temperature: Math.round(current.temp_c),
      humidity: current.humidity,
      windSpeed: Math.round(current.wind_kph),
      description: current.condition.text.toLowerCase(),
      condition: current.condition.text,
      pressure: current.pressure_mb,
      precipitation: forecastData.length > 0 ? forecastData[0].precipitation : 0,
      totalRainfall: Math.round(totalRainfall * 10) / 10,
      feelsLike: Math.round(current.feelslike_c),
      visibility: Math.round(current.vis_km),
      dewPoint: Math.round(current.dewpoint_c),
      uvIndex: current.uv || null,
      forecast: forecastData,
      forecastDay: currentHour >= 15 ? 'tomorrow' : 'today',
      ukTime: ukDateTime.toLocaleTimeString('en-GB', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit',
        hour12: false 
      }),
      currentHour,
      greenkeepingCommentary
    };

  } catch (error) {
    console.error("Error fetching weather data:", error);
    return null;
  }
}

export function getWeatherBasedRecommendations(weather: WeatherData): string[] {
  const recommendations: string[] = [];
  
  // Temperature-based recommendations
  if (weather.temperature > 25) {
    recommendations.push("Hot conditions: Consider early morning or evening applications to reduce evaporation");
    recommendations.push("Increase water volume slightly to compensate for faster evaporation");
  } else if (weather.temperature < 5) {
    recommendations.push("Cold conditions: Ensure products are suitable for low temperature application");
    recommendations.push("Some products may have reduced efficacy in cold weather");
  }

  // Humidity recommendations
  if (weather.humidity < 30) {
    recommendations.push("Low humidity: Risk of spray drift increased, consider higher water volumes");
  } else if (weather.humidity > 85) {
    recommendations.push("High humidity: Good conditions for most applications, disease pressure may be higher");
  }

  // Wind recommendations
  if (weather.windSpeed > 15) {
    recommendations.push("Windy conditions: High risk of spray drift, consider postponing application");
  } else if (weather.windSpeed > 10) {
    recommendations.push("Moderate wind: Use appropriate nozzles and reduce boom height to minimize drift");
  }

  // Condition-specific recommendations
  if (weather.condition === "Rain" || weather.description.includes("rain")) {
    recommendations.push("Rainy conditions: Postpone application until weather improves");
  } else if (weather.condition === "Clear" && weather.temperature > 20) {
    recommendations.push("Clear, warm conditions: Ideal for most applications, monitor for heat stress");
  }

  return recommendations;
}

export async function getAnnualWeatherStats(location: string = "Cumbernauld, Scotland, GB"): Promise<AnnualWeatherStats | null> {
  try {
    // Use WeatherAPI.com for comprehensive historical weather data
    const weatherApiKey = process.env.WEATHERAPI_KEY;
    
    if (!weatherApiKey) {
      console.log("WeatherAPI key required for historical weather data");
      return null;
    }

    // Dullatur Golf Club coordinates
    const latitude = 55.9469;
    const longitude = -4.0181;
    
    // Calculate date range for 2025 year-to-date
    const currentDate = new Date();
    const startOfYear = new Date(2025, 0, 1);
    const endDate = currentDate > startOfYear ? currentDate : new Date(2025, 4, 30);
    
    // WeatherAPI.com History endpoint for authentic historical data
    let totalRainfall = 0;
    let totalTemperature = 0;
    let totalSunshineHours = 0;
    let dayCount = 0;
    const monthlyTemperatures = new Array(12).fill(0);
    const monthlyRainfall = new Array(12).fill(0);
    const monthlyDaytimeHighs = new Array(12).fill(0);
    const monthlySoilTemperatures = new Array(12).fill(0);
    const monthlyCounts = new Array(12).fill(0);
    
    // Fetch historical data month by month for 2025
    const currentMonth = endDate.getMonth() + 1; // 1-based month
    
    for (let month = 1; month <= currentMonth; month++) {
      const monthStart = new Date(2025, month - 1, 1);
      const monthEnd = new Date(2025, month, 0); // Last day of month
      
      const historyUrl = `https://api.weatherapi.com/v1/history.json?key=${weatherApiKey}&q=${latitude},${longitude}&dt=${monthStart.toISOString().split('T')[0]}&end_dt=${monthEnd.toISOString().split('T')[0]}`;
      
      try {
        const response = await fetch(historyUrl);
        
        if (!response.ok) {
          console.error(`WeatherAPI failed for month ${month}:`, response.status);
          continue;
        }
        
        const data = await response.json();
        
        if (data.forecast && data.forecast.forecastday) {
          data.forecast.forecastday.forEach((day: any) => {
            const date = new Date(day.date);
            const dayMonth = date.getMonth();
            
            // Temperature data - get authentic values from weather API
            const avgTemp = day.day.avgtemp_c || 0;
            const maxTemp = day.day.maxtemp_c || 0; // Actual daytime high
            const minTemp = day.day.mintemp_c || 0;
            
            // Estimate soil temperature (typically 2-4°C lower than air temp, more stable)
            const soilTemp = Math.max(avgTemp - 2.5, 0);
            
            totalTemperature += avgTemp;
            monthlyTemperatures[dayMonth] += avgTemp;
            monthlyDaytimeHighs[dayMonth] += maxTemp;
            monthlySoilTemperatures[dayMonth] += soilTemp;
            monthlyCounts[dayMonth]++;
            
            // Rainfall data (convert mm to ml per square meter - same value)
            const rainfall = day.day.totalprecip_mm || 0;
            totalRainfall += rainfall;
            monthlyRainfall[dayMonth] += rainfall;
            
            // Sunshine hours estimation from UV index and daylight
            const maxUv = day.day.maxtemp_c > 10 ? (day.day.maxtemp_c / 5) : 0;
            const sunshineEstimate = Math.min(12, maxUv * 1.5); // Conservative estimate
            totalSunshineHours += sunshineEstimate;
            
            dayCount++;
          });
        }
      } catch (error) {
        console.error(`Error fetching month ${month} data:`, error);
      }
      
      // Add small delay to respect API rate limits
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Calculate averages
    const averageTemperature = dayCount > 0 ? totalTemperature / dayCount : 0;
    
    // Calculate monthly averages
    for (let i = 0; i < 12; i++) {
      if (monthlyCounts[i] > 0) {
        monthlyTemperatures[i] = monthlyTemperatures[i] / monthlyCounts[i];
        monthlyDaytimeHighs[i] = monthlyDaytimeHighs[i] / monthlyCounts[i];
        monthlySoilTemperatures[i] = monthlySoilTemperatures[i] / monthlyCounts[i];
      }
    }
    
    // Calculate evapotranspiration using reference evapotranspiration formula
    // Based on temperature and estimated radiation from sunshine hours
    const estimatedEvapotranspiration = averageTemperature > 0 ? 
      (0.0023 * (averageTemperature + 17.8) * Math.sqrt(Math.abs(averageTemperature - 5)) * totalSunshineHours / 10) * dayCount : 0;
    
    return {
      totalRainfall2025: Math.round(totalRainfall * 10) / 10,
      averageTemperature2025: Math.round(averageTemperature * 10) / 10,
      totalSunshineHours: Math.round(totalSunshineHours * 10) / 10,
      totalEvapotranspiration: Math.round(estimatedEvapotranspiration),
      monthlyTemperatures: monthlyTemperatures.map(temp => Math.round(temp * 10) / 10),
      monthlyRainfall: monthlyRainfall.map(rain => Math.round(rain * 10) / 10),
      monthlyDaytimeHighs: monthlyDaytimeHighs.map(temp => Math.round(temp * 10) / 10),
      monthlySoilTemperatures: monthlySoilTemperatures.map(temp => Math.round(temp * 10) / 10)
    };
    
  } catch (error) {
    console.error("Error fetching Met Office weather statistics:", error);
    return null;
  }
}