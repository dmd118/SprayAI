// API Quota Management System
interface QuotaStatus {
  service: string;
  isExhausted: boolean;
  resetTime: Date | null;
  lastAttempt: Date;
  dailyUsage: number;
  dailyLimit: number;
}

class APIQuotaManager {
  private quotaStatus = new Map<string, QuotaStatus>();
  private retryIntervals = new Map<string, NodeJS.Timeout>();

  constructor() {
    this.initializeQuotaTracking();
  }

  private initializeQuotaTracking(): void {
    // Initialize quota tracking for all services
    const services = ['youtube', 'reddit', 'news'];
    services.forEach(service => {
      this.quotaStatus.set(service, {
        service,
        isExhausted: false,
        resetTime: null,
        lastAttempt: new Date(),
        dailyUsage: 0,
        dailyLimit: this.getDailyLimit(service)
      });
    });

    // Reset quotas daily at midnight UTC
    this.scheduleQuotaReset();
  }

  private getDailyLimit(service: string): number {
    switch (service) {
      case 'youtube': return 10000; // YouTube API quota units
      case 'reddit': return 1000;   // Reddit API requests
      case 'news': return 1000;     // News API requests
      default: return 100;
    }
  }

  private scheduleQuotaReset(): void {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
    tomorrow.setUTCHours(0, 0, 0, 0);
    
    const msUntilReset = tomorrow.getTime() - now.getTime();
    
    setTimeout(() => {
      this.resetAllQuotas();
      // Schedule next reset
      setInterval(() => this.resetAllQuotas(), 24 * 60 * 60 * 1000);
    }, msUntilReset);
  }

  private resetAllQuotas(): void {
    console.log('🔄 Resetting API quotas at midnight UTC');
    this.quotaStatus.forEach((status, service) => {
      status.isExhausted = false;
      status.resetTime = null;
      status.dailyUsage = 0;
      console.log(`✅ ${service} quota reset - ${status.dailyLimit} requests available`);
      
      // Clear any retry intervals
      const retryInterval = this.retryIntervals.get(service);
      if (retryInterval) {
        clearInterval(retryInterval);
        this.retryIntervals.delete(service);
      }
    });
  }

  public recordAPICall(service: string, cost: number = 1): void {
    const status = this.quotaStatus.get(service);
    if (status) {
      status.dailyUsage += cost;
      status.lastAttempt = new Date();
      
      if (status.dailyUsage >= status.dailyLimit * 0.9) { // 90% threshold warning
        console.warn(`⚠️ ${service} approaching quota limit: ${status.dailyUsage}/${status.dailyLimit}`);
      }
    }
  }

  public markQuotaExhausted(service: string, resetTime?: Date): void {
    const status = this.quotaStatus.get(service);
    if (status) {
      status.isExhausted = true;
      status.resetTime = resetTime || this.getNextResetTime();
      console.warn(`🚫 ${service} quota exhausted until ${status.resetTime.toISOString()}`);
      
      // Start automatic retry when quota resets
      this.scheduleQuotaRetry(service);
    }
  }

  private getNextResetTime(): Date {
    const tomorrow = new Date();
    tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
    tomorrow.setUTCHours(0, 0, 0, 0);
    return tomorrow;
  }

  private scheduleQuotaRetry(service: string): void {
    const status = this.quotaStatus.get(service);
    if (!status || !status.resetTime) return;

    const msUntilReset = status.resetTime.getTime() - Date.now();
    
    if (msUntilReset > 0) {
      // Schedule retry shortly after quota reset
      setTimeout(() => {
        console.log(`🔄 ${service} quota should be reset, attempting auto-retry...`);
        this.attemptQuotaRecovery(service);
      }, msUntilReset + 60000); // 1 minute after reset time
    }
  }

  private async attemptQuotaRecovery(service: string): Promise<void> {
    const status = this.quotaStatus.get(service);
    if (!status) return;

    try {
      // Test if quota is actually recovered with a lightweight call
      const isRecovered = await this.testQuotaRecovery(service);
      
      if (isRecovered) {
        status.isExhausted = false;
        status.resetTime = null;
        status.dailyUsage = 0;
        console.log(`✅ ${service} quota recovered and verified`);
      } else {
        // Schedule another retry in 1 hour
        setTimeout(() => this.attemptQuotaRecovery(service), 60 * 60 * 1000);
      }
    } catch (error) {
      console.error(`❌ ${service} quota recovery test failed:`, error);
      // Retry in 30 minutes
      setTimeout(() => this.attemptQuotaRecovery(service), 30 * 60 * 1000);
    }
  }

  private async testQuotaRecovery(service: string): Promise<boolean> {
    switch (service) {
      case 'youtube':
        return this.testYouTubeQuota();
      case 'reddit':
        return this.testRedditQuota();
      case 'news':
        return this.testNewsQuota();
      default:
        return false;
    }
  }

  private async testYouTubeQuota(): Promise<boolean> {
    const apiKey = process.env.YOUTUBE_API_KEY;
    if (!apiKey) return false;

    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=test&maxResults=1&key=${apiKey}`,
        { method: 'GET' }
      );
      return response.ok && !response.headers.get('x-rate-limit-remaining')?.includes('0');
    } catch {
      return false;
    }
  }

  private async testRedditQuota(): Promise<boolean> {
    const clientId = process.env.REDDIT_CLIENT_ID;
    const clientSecret = process.env.REDDIT_CLIENT_SECRET;
    if (!clientId || !clientSecret) return false;

    try {
      const response = await fetch('https://www.reddit.com/api/v1/access_token', {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'grant_type=client_credentials'
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  private async testNewsQuota(): Promise<boolean> {
    const apiKey = process.env.NEWS_API_KEY;
    if (!apiKey) return false;

    try {
      const response = await fetch(
        `https://newsapi.org/v2/everything?q=test&pageSize=1&apiKey=${apiKey}`,
        { method: 'GET' }
      );
      return response.ok;
    } catch {
      return false;
    }
  }

  public isQuotaAvailable(service: string): boolean {
    const status = this.quotaStatus.get(service);
    return status ? !status.isExhausted : true;
  }

  public getQuotaStatus(service: string): QuotaStatus | null {
    return this.quotaStatus.get(service) || null;
  }

  public getAllQuotaStatus(): Map<string, QuotaStatus> {
    return new Map(this.quotaStatus);
  }

  public getRemainingQuota(service: string): number {
    const status = this.quotaStatus.get(service);
    return status ? Math.max(0, status.dailyLimit - status.dailyUsage) : 0;
  }
}

export const quotaManager = new APIQuotaManager();