// 24/7 Uptime Optimization System
import { Express } from 'express';

interface UptimeConfig {
  healthCheckInterval: number;
  memoryThreshold: number;
  requestTimeout: number;
  maxRetries: number;
}

class UptimeOptimizer {
  private config: UptimeConfig = {
    healthCheckInterval: 5 * 60 * 1000, // 5 minutes to reduce load
    memoryThreshold: 800 * 1024 * 1024, // 800MB higher threshold
    requestTimeout: 30000, // 30 seconds
    maxRetries: 3
  };

  private healthStats = {
    lastCheck: new Date(),
    consecutiveSuccesses: 0,
    totalRequests: 0,
    failedRequests: 0,
    uptime: process.uptime()
  };

  constructor(private app: Express) {}

  public initializeOptimizations(): void {
    this.setupGracefulShutdown();
    this.setupMemoryMonitoring();
    this.setupRequestOptimization();
    this.setupHealthEndpoint();
    this.startUptimeMonitoring();
    
    console.log('🚀 24/7 Uptime optimization activated');
    console.log('📊 Monitoring: Memory, Health, Performance');
  }

  private setupGracefulShutdown(): void {
    const gracefulShutdown = (signal: string) => {
      console.log(`📡 Received ${signal}, starting graceful shutdown...`);
      
      // Give existing requests time to complete
      setTimeout(() => {
        console.log('✅ Graceful shutdown complete');
        process.exit(0);
      }, 5000);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }

  private setupMemoryMonitoring(): void {
    setInterval(() => {
      const usage = process.memoryUsage();
      const heapUsed = usage.heapUsed;
      
      if (heapUsed > this.config.memoryThreshold) {
        console.warn(`⚠️ High memory usage: ${Math.round(heapUsed / 1024 / 1024)}MB`);
        
        // Force garbage collection if available
        if (global.gc) {
          global.gc();
          console.log('🧹 Garbage collection triggered');
        }
      }
    }, 60000); // Check every minute
  }

  private setupRequestOptimization(): void {
    // Add request timeout middleware
    this.app.use((req, res, next) => {
      const timeout = setTimeout(() => {
        if (!res.headersSent) {
          res.status(408).json({ error: 'Request timeout' });
        }
      }, this.config.requestTimeout);

      res.on('finish', () => clearTimeout(timeout));
      res.on('close', () => clearTimeout(timeout));
      
      next();
    });

    // Add request tracking
    this.app.use((req, res, next) => {
      this.healthStats.totalRequests++;
      
      res.on('finish', () => {
        if (res.statusCode >= 400) {
          this.healthStats.failedRequests++;
        }
      });
      
      next();
    });
  }

  private setupHealthEndpoint(): void {
    this.app.get('/health', (req, res) => {
      const memUsage = process.memoryUsage();
      const uptime = process.uptime();
      
      const health = {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`,
        memory: {
          used: Math.round(memUsage.heapUsed / 1024 / 1024),
          total: Math.round(memUsage.heapTotal / 1024 / 1024),
          external: Math.round(memUsage.external / 1024 / 1024)
        },
        requests: {
          total: this.healthStats.totalRequests,
          failed: this.healthStats.failedRequests,
          successRate: this.healthStats.totalRequests > 0 
            ? Math.round(((this.healthStats.totalRequests - this.healthStats.failedRequests) / this.healthStats.totalRequests) * 100)
            : 100
        }
      };

      // Return 503 if system is unhealthy
      if (memUsage.heapUsed > this.config.memoryThreshold * 1.5) {
        res.status(503).json({ ...health, status: 'unhealthy', reason: 'High memory usage' });
      } else {
        res.json(health);
      }
    });
  }

  private startUptimeMonitoring(): void {
    setInterval(async () => {
      try {
        // Self health check
        const response = await fetch('http://localhost:5000/health');
        
        if (response.ok) {
          this.healthStats.consecutiveSuccesses++;
          this.healthStats.lastCheck = new Date();
        } else {
          this.healthStats.consecutiveSuccesses = 0;
          console.warn('⚠️ Health check failed:', response.status);
        }
      } catch (error) {
        this.healthStats.consecutiveSuccesses = 0;
        console.error('❌ Health check error:', error);
      }
      
      // Log uptime stats every hour
      if (this.healthStats.totalRequests % 100 === 0 && this.healthStats.totalRequests > 0) {
        const uptime = process.uptime();
        const successRate = Math.round(((this.healthStats.totalRequests - this.healthStats.failedRequests) / this.healthStats.totalRequests) * 100);
        
        console.log(`📈 Uptime: ${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m | Success Rate: ${successRate}% | Requests: ${this.healthStats.totalRequests}`);
      }
    }, this.config.healthCheckInterval);
  }

  public getStats() {
    return {
      ...this.healthStats,
      uptime: process.uptime(),
      memory: process.memoryUsage()
    };
  }
}

export const uptimeOptimizer = new UptimeOptimizer(null as any);
export { UptimeOptimizer };