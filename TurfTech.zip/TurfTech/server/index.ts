import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { startNewsScheduler } from "./news-scheduler";
import { storage } from "./storage";
import { aiFailsafeSystem } from "./ai-failsafe-system";
import { healthMonitor } from "./health-monitor";
import { UptimeOptimizer } from "./uptime-optimizer";
import { ResilienceSystem } from "./resilience-system";

const app = express();

// Initialize 24/7 uptime optimization systems
const uptimeOptimizer = new UptimeOptimizer(app);
const resilienceSystem = new ResilienceSystem(app);

// Initialize reliability systems before other middleware
resilienceSystem.initialize();
uptimeOptimizer.initializeOptimizations();

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, async () => {
    log(`serving on port ${port}`);
    
    // Start news scheduler after server is running
    startNewsScheduler(process.env.NEWS_API_KEY);
    
    // Start AI assistant failsafe monitoring system
    console.log("Starting AI assistant failsafe system...");
    aiFailsafeSystem.startMonitoring();
    console.log("AI assistant protection: ALWAYS AVAILABLE with backup data systems");
    
    // Start automated health monitoring system
    console.log("Starting automated health monitoring...");
    healthMonitor.startMonitoring();
    console.log("Health monitoring: Checking external APIs every 6 hours");
    
    // Add uptime status endpoint
    app.get('/uptime-status', (req, res) => {
      const stats = uptimeOptimizer.getStats();
      const circuitStatus = resilienceSystem.getStatus();
      
      res.json({
        server: {
          uptime: process.uptime(),
          memory: process.memoryUsage(),
          pid: process.pid
        },
        requests: {
          total: stats.totalRequests,
          failed: stats.failedRequests,
          successRate: stats.totalRequests > 0 
            ? Math.round(((stats.totalRequests - stats.failedRequests) / stats.totalRequests) * 100)
            : 100
        },
        services: circuitStatus,
        timestamp: new Date().toISOString()
      });
    });
    
    // Auto-populate industry news if empty
    setTimeout(async () => {
      try {
        const response = await fetch('http://localhost:5000/api/industry-news');
        const existingNews = await response.json();
        if (existingNews.length === 0) {
          log('Auto-seeding industry news...');
          await fetch('http://localhost:5000/api/seed-industry-news', { method: 'POST' });
          log('Industry news auto-seeded successfully');
        } else {
          log(`Found ${existingNews.length} existing news articles`);
        }
      } catch (error) {
        log('Auto-seed check failed, articles available via manual trigger');
      }
    }, 2000); // Wait 2 seconds for server to be fully ready
  });
})();
