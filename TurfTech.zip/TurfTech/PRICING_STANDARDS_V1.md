# Dullatur Golf Club - Standardized Product Pricing (Version 1.0)

## Authoritative Pricing Source
All system calculations reference operational record data from actual field applications.

## Core Product Pricing (GBP)

### Growth Regulators
- **Primo Maxx II**: £52.50/L (£105/2L container)
- **Primo Maxx**: £52.50/L
- **Primo**: £52.50/L

### Iron Products & Nutritional Supplements  
- **Elevate Fe**: £7.50/L (£375/50L container)
- **Elevate Fe Iron**: £7.50/L

### Fertilizers & Adjuvants
- **Ammonium Sulphate (AMS)**: £1.20/kg (£30/25kg bag)
- **Urea**: £0.80/kg (£20/25kg bag)

### Water Cost
- **Mains Water**: £0.97/1000L

## Operational Reference
Based on Fairways-C Total application (2.5 hectares):
- Total operational cost: £304.49
- Cost per hectare: £121.79
- Application methodology: Tank mix dilution with 300L/tank working loads

## Safety Protocols
- No fallback pricing estimates permitted
- Missing product costs trigger error logging
- All calculations must reference this standardized table

## Version Control
- Version 1.0: Initial standardization (May 31, 2025)
- Future updates require operational field verification

---
**Note**: This pricing reflects real-world Dullatur Golf Club operational costs, not theoretical or market estimates.