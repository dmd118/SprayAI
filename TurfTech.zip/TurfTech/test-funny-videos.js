import { fetchAndStoreFunnyVideos } from './server/news-aggregator.js';

// Test the funny video fetching
async function testFunnyVideos() {
  console.log('Testing funny greenkeeping video fetch...');
  
  try {
    const result = await fetchAndStoreFunnyVideos();
    console.log('Result:', result);
    
    if (result.success) {
      console.log(`✅ Successfully added ${result.count} funny videos to industry news!`);
    } else {
      console.log('❌ Failed to fetch funny videos');
      if (result.errors.length > 0) {
        console.log('Errors:', result.errors);
      }
    }
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testFunnyVideos();