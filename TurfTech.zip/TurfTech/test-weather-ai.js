// Test script to verify AI assistant can read weather forecast data

async function testWeatherDataFlow() {
  try {
    // First, get the weather data directly
    console.log('1. Testing direct weather API access...');
    const weatherResponse = await fetch('http://localhost:5000/api/weather');
    const weatherData = await weatherResponse.json();
    
    console.log('Weather data structure:');
    console.log('- Current temperature:', weatherData.weather?.temperature);
    console.log('- Forecast available:', !!weatherData.weather?.forecast);
    console.log('- Forecast length:', weatherData.weather?.forecast?.length || 0);
    
    if (weatherData.weather?.forecast) {
      console.log('- Forecast times:');
      weatherData.weather.forecast.forEach(f => {
        console.log(`  ${f.time}: ${f.temperature}°C, ${f.description}, Wind: ${f.windSpeed}km/h, Humidity: ${f.humidity}%, Rain: ${f.precipitation}%`);
      });
    }
    
    // Now test the AI assistant
    console.log('\n2. Testing AI assistant weather access...');
    const aiResponse = await fetch('http://localhost:5000/api/expert-greenkeeper-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: "Based on the detailed weather forecast data in your system, what are the exact conditions for 6am?"
      })
    });
    
    const aiData = await aiResponse.json();
    console.log('AI Response:', aiData.response);
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testWeatherDataFlow();