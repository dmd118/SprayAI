// Fix the product categories from "products" to "new-products"
import { storage } from './server/storage.js';

async function fixProductCategories() {
  try {
    const allNews = await storage.getIndustryNews();
    
    // Find articles with category "products" and update to "new-products"
    const productsToFix = allNews.filter(article => article.category === 'products');
    
    console.log(`Found ${productsToFix.length} articles with "products" category to fix...`);
    
    for (const article of productsToFix) {
      await storage.updateIndustryNewsCategory(article.id, 'new-products');
      console.log(`Updated: ${article.title} -> new-products`);
    }
    
    console.log(`\nSuccessfully updated ${productsToFix.length} articles to "new-products" category`);
    
  } catch (error) {
    console.error('Error fixing categories:', error);
  }
}

fixProductCategories();