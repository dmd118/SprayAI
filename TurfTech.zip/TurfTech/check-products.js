// Check what categories our product announcements actually have
import { storage } from './server/storage.js';

async function checkProductCategories() {
  try {
    const allNews = await storage.getIndustryNews();
    
    // Find the product announcements we added
    const productTitles = [
      "Jacobsen Introduces New GP400 Wide Area Mower",
      "Syngenta Launches Heritage Action Fungicide", 
      "Toro Unveils New ProCore 648 Deep-Tine Aerator",
      "ICL Introduces Advanced Slow-Release Fertilizer"
    ];
    
    console.log('Checking for product announcements...\n');
    
    for (const title of productTitles) {
      const article = allNews.find(news => news.title.includes(title.split(' ')[0])); // Match by brand
      if (article) {
        console.log(`Found: ${article.title}`);
        console.log(`Category: "${article.category}"`);
        console.log(`Source: ${article.source}`);
        console.log('---');
      } else {
        console.log(`NOT FOUND: ${title}`);
      }
    }
    
    // Count articles by category
    const categoryCount = {};
    allNews.forEach(article => {
      categoryCount[article.category] = (categoryCount[article.category] || 0) + 1;
    });
    
    console.log('\nCategory breakdown:');
    Object.entries(categoryCount).forEach(([category, count]) => {
      console.log(`  ${category}: ${count} articles`);
    });
    
  } catch (error) {
    console.error('Error:', error);
  }
}

checkProductCategories();