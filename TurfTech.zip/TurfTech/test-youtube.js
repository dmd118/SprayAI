// Test YouTube Data API for educational greenkeeping content
const youtubeApiKey = process.env.YOUTUBE_API_KEY;

async function testYouTubeEducationalContent() {
  if (!youtubeApiKey) {
    console.log('YouTube API key not found in environment variables');
    return;
  }

  console.log('Testing YouTube Data API for educational greenkeeping content...\n');

  const searches = [
    'golf course superintendent maintenance',
    'greenkeeper training techniques',
    'turf equipment demonstration',
    'golf course irrigation system'
  ];

  let totalVideos = 0;
  let professionalVideos = 0;

  for (const query of searches) {
    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&videoDuration=medium&order=relevance&maxResults=5&key=${youtubeApiKey}`
      );
      
      if (response.ok) {
        const data = await response.json();
        const videos = data.items || [];
        totalVideos += videos.length;
        
        console.log(`=== QUERY: "${query}" ===`);
        console.log(`Videos found: ${videos.length}\n`);
        
        videos.forEach((video, i) => {
          const title = video.snippet?.title || '';
          const channelTitle = video.snippet?.channelTitle || '';
          const description = (video.snippet?.description || '').substring(0, 100);
          
          // Check if it's professional content
          const isProfessional = channelTitle.toLowerCase().includes('golf course') || 
                                channelTitle.toLowerCase().includes('turf') ||
                                channelTitle.toLowerCase().includes('greenkeeper') ||
                                channelTitle.toLowerCase().includes('superintendent') ||
                                title.toLowerCase().includes('how to') ||
                                title.toLowerCase().includes('training') ||
                                title.toLowerCase().includes('demonstration');
          
          if (isProfessional) professionalVideos++;
          
          console.log(`Video ${i + 1}:`);
          console.log(`Title: ${title}`);
          console.log(`Channel: ${channelTitle}`);
          console.log(`Professional: ${isProfessional ? 'Yes' : 'No'}`);
          console.log(`Published: ${video.snippet?.publishedAt}`);
          console.log(`Description: ${description}...`);
          console.log(`URL: https://www.youtube.com/watch?v=${video.id?.videoId}`);
          console.log('---');
        });
        console.log('\n');
      } else {
        console.log(`API error for "${query}": ${response.status} ${response.statusText}`);
      }
    } catch (error) {
      console.error(`Search failed for "${query}":`, error.message);
    }
  }
  
  console.log(`\nSUMMARY:`);
  console.log(`Total videos found: ${totalVideos}`);
  console.log(`Professional/Educational content: ${professionalVideos}`);
  console.log(`Quality ratio: ${Math.round((professionalVideos/totalVideos) * 100)}%`);
}

testYouTubeEducationalContent().catch(console.error);