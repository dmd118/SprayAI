#!/usr/bin/env node

// Comprehensive AI Advisory Testing - 50+ Scenarios
// Testing for golf course safety and calculation accuracy

const testScenarios = [
  // CATEGORY 1: PROVEN GREENKEEPER RECIPES (Tests 1-10)
  {
    id: 1,
    name: "Classic Fairway Mix",
    products: [
      {name: "Primo Maxx II", type: "Growth Regulator", activeIngredient: "Trinexapac-ethyl"},
      {name: "Heritage", type: "Fungicide", activeIngredient: "Azoxystrobin"},
      {name: "TriCure AD", type: "Wetting Agent", activeIngredient: "Alkyl polyglucoside"}
    ]
  },
  {
    id: 2,
    name: "Green Preventative Program",
    products: [
      {name: "Banner Maxx", type: "Fungicide", activeIngredient: "Propiconazole"},
      {name: "Elevate Fe", type: "Iron Supplement", activeIngredient: "Iron EDDHA 6%"},
      {name: "Urea", type: "Foliar Feed", activeIngredient: "CO(NH₂)₂ - 46% N"}
    ]
  },
  {
    id: 3,
    name: "Tee Stress Recovery",
    products: [
      {name: "Primo Maxx II", type: "Growth Regulator", activeIngredient: "Trinexapac-ethyl"},
      {name: "Ammonium Sulphate", type: "Adjuvant", activeIngredient: "(NH₄)₂SO₄ - 21% N"},
      {name: "Seaweed Extract", type: "Biostimulant", activeIngredient: "Ascophyllum nodosum"}
    ]
  },
  {
    id: 4,
    name: "Autumn Disease Control",
    products: [
      {name: "Instrata", type: "Fungicide", activeIngredient: "Chlorothalonil + Propiconazole"},
      {name: "Potassium Sulphate", type: "Fertilizer", activeIngredient: "K₂SO₄ - 50% K"},
      {name: "H2Pro", type: "Wetting Agent", activeIngredient: "Penetrant surfactant"}
    ]
  },
  {
    id: 5,
    name: "Spring Growth Management",
    products: [
      {name: "Cutless MEC", type: "Growth Regulator", activeIngredient: "Flurprimidol"},
      {name: "Iron Pro", type: "Iron Supplement", activeIngredient: "Iron Sulphate 15%"},
      {name: "Urea", type: "Nitrogen Feed", activeIngredient: "CO(NH₂)₂ - 46% N"}
    ]
  },
  {
    id: 6,
    name: "Summer Stress Package",
    products: [
      {name: "Primo Maxx II", type: "Growth Regulator", activeIngredient: "Trinexapac-ethyl"},
      {name: "Qualibra", type: "Wetting Agent", activeIngredient: "Polysaccharide"},
      {name: "Elevate Fe", type: "Iron Supplement", activeIngredient: "Iron EDDHA 6%"}
    ]
  },
  {
    id: 7,
    name: "Winter Hardening Mix",
    products: [
      {name: "Potassium Sulphate", type: "Fertilizer", activeIngredient: "K₂SO₄ - 50% K"},
      {name: "Phosphite", type: "Plant Health", activeIngredient: "Phosphorous acid"},
      {name: "Iron Sulphate", type: "Iron Feed", activeIngredient: "FeSO₄ - 20% Fe"}
    ]
  },
  {
    id: 8,
    name: "Disease Curative Treatment",
    products: [
      {name: "Medallion TL", type: "Fungicide", activeIngredient: "Fludioxonil"},
      {name: "Banner Maxx", type: "Fungicide", activeIngredient: "Propiconazole"},
      {name: "Ammonium Sulphate", type: "Adjuvant", activeIngredient: "(NH₄)₂SO₄"}
    ]
  },
  {
    id: 9,
    name: "Fairway Renovation Feed",
    products: [
      {name: "Urea", type: "Nitrogen Feed", activeIngredient: "CO(NH₂)₂ - 46% N"},
      {name: "Potassium Nitrate", type: "Fertilizer", activeIngredient: "KNO₃ - 13% N, 46% K"},
      {name: "Phosphoric Acid", type: "Acidifier", activeIngredient: "H₃PO₄ - 75%"}
    ]
  },
  {
    id: 10,
    name: "Green Speed Enhancement",
    products: [
      {name: "Primo Maxx II", type: "Growth Regulator", activeIngredient: "Trinexapac-ethyl"},
      {name: "Cutless MEC", type: "Growth Regulator", activeIngredient: "Flurprimidol"},
      {name: "Iron Chelate", type: "Iron Feed", activeIngredient: "Iron DTPA 11%"}
    ]
  },

  // CATEGORY 2: RANDOM/EXPERIMENTAL MIXES (Tests 11-25)
  {
    id: 11,
    name: "Random Mix 1",
    products: [
      {name: "2,4-D Amine", type: "Herbicide", activeIngredient: "2,4-D dimethylamine salt"},
      {name: "Urea", type: "Fertilizer", activeIngredient: "CO(NH₂)₂ - 46% N"},
      {name: "Copper Fungicide", type: "Fungicide", activeIngredient: "Copper oxychloride"}
    ]
  },
  {
    id: 12,
    name: "Random Mix 2",
    products: [
      {name: "Calcium Chloride", type: "Hardener", activeIngredient: "CaCl₂ - 94%"},
      {name: "Ammonium Nitrate", type: "Fertilizer", activeIngredient: "NH₄NO₃ - 34% N"},
      {name: "Sulfur", type: "Acidifier", activeIngredient: "Elemental sulfur 90%"}
    ]
  },
  {
    id: 13,
    name: "Random Mix 3",
    products: [
      {name: "Boron", type: "Micronutrient", activeIngredient: "Boric acid 17% B"},
      {name: "Manganese Sulphate", type: "Micronutrient", activeIngredient: "MnSO₄ - 32% Mn"},
      {name: "Zinc Sulphate", type: "Micronutrient", activeIngredient: "ZnSO₄ - 36% Zn"}
    ]
  },
  {
    id: 14,
    name: "Random Mix 4",
    products: [
      {name: "Humic Acid", type: "Soil Conditioner", activeIngredient: "Humate 85%"},
      {name: "Molasses", type: "Biostimulant", activeIngredient: "Sugar complex"},
      {name: "Yeast Extract", type: "Biostimulant", activeIngredient: "Amino acids"}
    ]
  },
  {
    id: 15,
    name: "Random Mix 5",
    products: [
      {name: "Lime Sulfur", type: "Fungicide", activeIngredient: "Calcium polysulfide"},
      {name: "Epsom Salt", type: "Magnesium Source", activeIngredient: "MgSO₄ - 16% Mg"},
      {name: "Kelp Meal", type: "Organic Feed", activeIngredient: "Ascophyllum nodosum"}
    ]
  },

  // CATEGORY 3: DANGEROUS/WRONG COMBINATIONS (Tests 16-30)
  {
    id: 16,
    name: "DANGEROUS: Total Weedkiller Mix",
    products: [
      {name: "Roundup Pro", type: "Total Weedkiller", activeIngredient: "Glyphosate 360g/L"},
      {name: "Primo Maxx II", type: "Growth Regulator", activeIngredient: "Trinexapac-ethyl"},
      {name: "Iron Sulphate", type: "Iron Feed", activeIngredient: "FeSO₄"}
    ]
  },
  {
    id: 17,
    name: "DANGEROUS: Bleach + Acid",
    products: [
      {name: "Sodium Hypochlorite", type: "Disinfectant", activeIngredient: "NaClO - 12%"},
      {name: "Phosphoric Acid", type: "Acidifier", activeIngredient: "H₃PO₄ - 75%"},
      {name: "Ammonium Sulphate", type: "Adjuvant", activeIngredient: "(NH₄)₂SO₄"}
    ]
  },
  {
    id: 18,
    name: "DANGEROUS: High Salt Concentration",
    products: [
      {name: "Sodium Chloride", type: "Salt", activeIngredient: "NaCl - 99%"},
      {name: "Ammonium Chloride", type: "Fertilizer", activeIngredient: "NH₄Cl - 25% N"},
      {name: "Potassium Chloride", type: "Fertilizer", activeIngredient: "KCl - 60% K"}
    ]
  },
  {
    id: 19,
    name: "DANGEROUS: Incompatible pH",
    products: [
      {name: "Lime", type: "pH Adjuster", activeIngredient: "CaCO₃ - 95%"},
      {name: "Aluminum Sulphate", type: "Acidifier", activeIngredient: "Al₂(SO₄)₃"},
      {name: "Iron Sulphate", type: "Iron Feed", activeIngredient: "FeSO₄ - 20% Fe"}
    ]
  },
  {
    id: 20,
    name: "DANGEROUS: Copper Overload",
    products: [
      {name: "Copper Sulphate", type: "Fungicide", activeIngredient: "CuSO₄ - 25% Cu"},
      {name: "Bordeaux Mixture", type: "Fungicide", activeIngredient: "Copper sulphate + lime"},
      {name: "Copper Oxychloride", type: "Fungicide", activeIngredient: "Cu₂Cl(OH)₃"}
    ]
  },

  // More tests continue...
  {
    id: 21,
    name: "WRONG: Grass Killer on Greens",
    products: [
      {name: "Glyphosate 480", type: "Total Herbicide", activeIngredient: "Glyphosate isopropylamine"},
      {name: "Cutless MEC", type: "Growth Regulator", activeIngredient: "Flurprimidol"},
      {name: "Urea", type: "Nitrogen Feed", activeIngredient: "CO(NH₂)₂"}
    ]
  },
  {
    id: 22,
    name: "WRONG: Excessive Iron",
    products: [
      {name: "Iron Sulphate", type: "Iron Feed", activeIngredient: "FeSO₄ - 20% Fe"},
      {name: "Iron Chelate", type: "Iron Feed", activeIngredient: "Iron EDTA 13%"},
      {name: "Ferrous Ammonium Sulphate", type: "Iron Feed", activeIngredient: "Fe(NH₄)₂(SO₄)₂"}
    ]
  }
];

// Function to test compatibility
async function testCompatibility(scenario) {
  try {
    const response = await fetch('http://localhost:5000/api/analyze-compatibility', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ products: scenario.products })
    });
    
    const result = await response.json();
    return {
      id: scenario.id,
      name: scenario.name,
      severity: result.warnings?.[0]?.severity || 'unknown',
      message: result.warnings?.[0]?.message || 'No warnings',
      considerations: result.warnings?.[0]?.considerations || []
    };
  } catch (error) {
    return {
      id: scenario.id,
      name: scenario.name,
      error: error.message
    };
  }
}

// Run all tests
async function runAllTests() {
  console.log('=== COMPREHENSIVE AI ADVISORY TESTING ===');
  console.log(`Testing ${testScenarios.length} scenarios for golf course safety\n`);
  
  for (const scenario of testScenarios) {
    const result = await testCompatibility(scenario);
    
    console.log(`Test ${result.id}: ${result.name}`);
    console.log(`Severity: ${result.severity.toUpperCase()}`);
    console.log(`Message: ${result.message}`);
    if (result.considerations?.length > 0) {
      console.log(`Key Considerations: ${result.considerations.slice(0, 2).join('; ')}`);
    }
    console.log('---');
    
    // Add delay to prevent rate limiting
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { testScenarios, testCompatibility };
} else {
  runAllTests().catch(console.error);
}