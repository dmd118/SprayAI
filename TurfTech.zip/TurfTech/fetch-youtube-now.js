// Direct YouTube content fetcher for greenkeeping videos
import { storage } from './server/storage.js';

const youtubeApiKey = process.env.YOUTUBE_API_KEY;

async function fetchYouTubeContent() {
  if (!youtubeApiKey) {
    console.log('No YouTube API key found');
    return;
  }

  console.log('Fetching professional greenkeeping content from YouTube...');

  const searches = [
    'BIGGA greenkeeping training',
    'STRI Group turf research',
    'golf course superintendent maintenance',
    'Rigby Taylor greenkeeping',
    'ICL Turf Landscape fertilizer',
    'professional greenkeeper techniques'
  ];

  let totalVideos = 0;

  for (const searchTerm of searches) {
    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(searchTerm)}&type=video&maxResults=3&order=relevance&key=${youtubeApiKey}`
      );

      if (!response.ok) {
        console.log(`YouTube API error for "${searchTerm}": ${response.status}`);
        continue;
      }

      const data = await response.json();

      if (data.items && data.items.length > 0) {
        for (const video of data.items) {
          try {
            const videoUrl = `https://www.youtube.com/watch?v=${video.id.videoId}`;
            const thumbnail = video.snippet.thumbnails?.medium?.url || video.snippet.thumbnails?.default?.url;

            const newsItem = {
              title: `[VIDEO] ${video.snippet.title}`,
              summary: video.snippet.description.substring(0, 200) + (video.snippet.description.length > 200 ? '...' : ''),
              content: `Professional greenkeeping video: ${video.snippet.description}`,
              category: "videos",
              source: `YouTube - ${video.snippet.channelTitle}`,
              sourceUrl: videoUrl,
              imageUrl: thumbnail,
              publishedDate: new Date(video.snippet.publishedAt),
              relevantProducts: [],
              tags: ["video", "youtube", "professional", "training"],
              priority: "normal"
            };

            await storage.createIndustryNews(newsItem);
            totalVideos++;
            console.log(`Added: ${video.snippet.title}`);

          } catch (error) {
            console.error(`Failed to add video: ${error}`);
          }
        }
      }
    } catch (error) {
      console.error(`Search failed for "${searchTerm}":`, error);
    }
  }

  console.log(`Successfully added ${totalVideos} professional greenkeeping videos`);
}

fetchYouTubeContent().catch(console.error);